<?php
// default database
$server = "mysql";
$hostname = "localhost";
$username = "tatartest_m";
$password = '.Q(RQHDl5!b6';
$database = "tatartest_m";
$cpanel_url = 'https: //server.smartservs.com:2083';
$mail_server = 'server.smartservs.com';
$mail_account = 'mailnew@tatartest.site';
$mail_password = 'p2H5JA1P)lc;';

if (!defined("DB_PREFIX")) {
    define("DB_PREFIX", "GAME_");
}
