<?php
require_once LIBRARY_DIR . 'gameEngine/BaseController.php';

class LiteController extends BaseController
{
    public function __construct()
    {
        parent::__construct();
    }
}

?>