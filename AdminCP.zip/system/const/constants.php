<?php

//-------------------------------------------------------------
//
//					 Controller
//
//-------------------------------------------------------------
define("CONTROLLER_EXTENSION", "php");
define("CONTROLLER_CLASS_NAME", "_Controller");
