<?php
define("LANGUI_NEWS_T1", "News");
define("LANGUI_NEWS_T2", "All News");
?>