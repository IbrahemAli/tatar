<?php

define('LANGUI_LOGOUT_T1', 'Been signed out successfully!');
define('LANGUI_LOGOUT_T2', 'Thank you for the visit');
define('LANGUI_LOGOUT_T3', 'in case of multiple users to the same computer, you should delete files from your network until you clear the user name and password to maintain the confidentiality of your information');
define('LANGUI_LOGOUT_T4', '»network scan of your system');
?>
