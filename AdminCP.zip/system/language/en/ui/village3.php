<?php

define('LANGUI_VIL3_T1', 'deserted valley');
define('LANGUI_VIL3_T2', 'land distribution');
define('LANGUI_VIL3_T3', 'Htabon');
define('LANGUI_VIL3_T4', 'mud holes');
define('LANGUI_VIL3_T5', 'iron mines');
define('LANGUI_VIL3_T6', 'wheat fields');
define('LANGUI_VIL3_T7', 'Options');
define('LANGUI_VIL3_T8', '»Center map');
define('LANGUI_VIL3_T9', '»building a new village');
define('LANGUI_VIL3_T10', '/ 3 settlers are available');
define('LANGUI_VIL3_T11', 'capital');
define('LANGUI_VIL3_T12', 'tribe');
define('LANGUI_VIL3_T13', 'Alliance');
define('LANGUI_VIL3_T14', 'Owner');
define('LANGUI_VIL3_T15', 'population');
define('LANGUI_VIL3_T16', 'Reports');
define('LANGUI_VIL3_T17', 'no information');
define('LANGUI_VIL3_T18', '»send troops (Forbidden)');
define('LANGUI_VIL3_T19', '»Send troops');
define('LANGUI_VIL3_T20', '»send troops (your building rally point)');
define('LANGUI_VIL3_T21', '»Send dealers (Forbidden)');
define('LANGUI_VIL3_T22', '»Send a traders');
define('LANGUI_VIL3_T23', '»Send dealers (build your market)');
define('LANGUI_VIL3_T24', 'Oasis owned');
define('LANGUI_VIL3_T25', 'loyalty');
define('LANGUI_VIL3_T26', 'increase');
define('LANGUI_VIL3_T27', 'at');
define('LANGUI_VIL3_T28', 'village');
define('LANGUI_VIL3_T29', 'Oasis is not occupied');
define('LANGUI_VIL3_T30', 'units');
define('LANGUI_VIL3_T31', 'none');
define('LANGUI_VIL3_T32', 'increase');
define('LANGUI_VIL3_T33', '»looted and abandoned oasis');
define('LANGUI_VIL3_T34', '»Oasis looted and abandoned (build your rally point)');
?>
