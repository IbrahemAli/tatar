<?php
define("LANGUI_VILS_1", "Statistics villages");
define("LANGUI_VILS_2", "Map of the village");
define("LANGUI_VILS_3", "Resources");
define("LANGUI_VILS_4", "Stores");
define("LANGUI_VILS_5", "Production");
define("LANGUI_VILS_6", "Forces");
define("LANGUI_VILS_7", "The village name");
define("LANGUI_VILS_8", "Population");
define("LANGUI_VILS_9", "worker");
define("LANGUI_VILS_10", "Reinforcements");
define("LANGUI_VILS_11", "Attacks");
define("LANGUI_VILS_12", "Traders");
define("LANGUI_VILS_13", "There building process");
define("LANGUI_VILS_14", "There are forces coming to help");
define("LANGUI_VILS_15", "These attacks on the village");
define("LANGUI_VILS_16", "Attacks of this village");
define("LANGUI_VILS_17", "Traders are coming");
define("LANGUI_VILS_18", "Villages");
define("LANGUI_VILS_19", "Traders");
define("LANGUI_VILS_20", "Total");
define("LANGUI_VILS_21", "View statistics of villages need to activate Plus Account");
?>
  