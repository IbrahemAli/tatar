<?php

define('LANGUI_RES_T1', 'resource allocation');
define('LANGUI_RES_T2', 'data the village');
define('LANGUI_RES_T3', 'name');
define('LANGUI_RES_T4', 'player');
define('LANGUI_RES_T5', 'resource');
define('LANGUI_RES_T6', 'capacity');
define('LANGUI_RES_T7', 'quantity');
?>
