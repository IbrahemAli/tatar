<?php

define('LANGUI_PROFILE_T1', 'Image');
define('LANGUI_PROFILE_T1', 'URL Web Site');
define('LANGUI_PROFILE_T1', 'URL youtube');
define('LANGUI_PROFILE_T2', 'News');
?>
