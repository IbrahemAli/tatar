<?php

define('LANGUI_ADV_T1', 'Advertising Management');
define('LANGUI_ADV_T2', 'Edit an ad');
define('LANGUI_ADV_T3', 'Add advertising');
define('LANGUI_ADV_T4', 'Add new');
define('LANGUI_ADV_T5', 'Name');
define('LANGUI_ADV_T6', 'Advertise');
define('LANGUI_ADV_T7', 'Add link ad \\ n image or flash file');
define('LANGUI_ADV_T8', 'link');
define('LANGUI_ADV_T9', 'Section');
define('LANGUI_ADV_T10', 'Home');
define('LANGUI_ADV_T11', 'Game');
define('LANGUI_ADV_T12', 'Advertising');
define('LANGUI_ADV_T13', 'Number');
define('LANGUI_ADV_T14', 'Hits');
define('LANGUI_ADV_T15', 'Show');
define('LANGUI_ADV_T16', 'Control');
define('LANGUI_ADV_T17', 'Show advertising ');
define('LANGUI_ADV_T18', 'Delete advertising');
define('LANGUI_ADV_T19', 'Edit advertising ');
define('LANGUI_ADV_T20', 'Ok');
define('LANGUI_ADV_T21', 'Guidance');
?>
