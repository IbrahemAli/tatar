<?php

define('LANGUI_LNKS_T1', 'Direct links');
define('LANGUI_LNKS_T2', 'Number');
define('LANGUI_LNKS_T3', 'Link title');
define('LANGUI_LNKS_T4', 'Target link');
?>
