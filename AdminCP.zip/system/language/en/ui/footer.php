<?php

define('LANGUI_FOOTER_MAIN', 'Home');
define('LANGUI_FOOTER_MANUAL', 'Help');
define('LANGUI_FOOTER_TRAINING', 'training');
?>
