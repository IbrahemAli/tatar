<?php

define('LANGUI_MAP_T1', 'Map');
define('LANGUI_MAP_T2', 'details');
define('LANGUI_MAP_T3', 'deserted valley');
define('LANGUI_MAP_T4', 'Oasis owned');
define('LANGUI_MAP_T5', 'Oasis is not occupied');
define('LANGUI_MAP_T6', 'North');
define('LANGUI_MAP_T7', 'Eastern');
define('LANGUI_MAP_T8', 'South');
define('LANGUI_MAP_T9', 'West');
define('LANGUI_MAP_T10', 'large map');
define('LANGUI_MAP_T11', 'Player');
define('LANGUI_MAP_T12', 'population');
define('LANGUI_MAP_T13', 'Alliance');
define('LANGUI_MAP_T14', 'Close the map');
define("LANGUI_MAP_T15", "Find the villages of 9 wheat fields");

?>
