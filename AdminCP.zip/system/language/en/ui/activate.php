<?php

define('LANGUI_ACTIVATE_T1', 'Did not receive a letter in the mail?');
define('LANGUI_ACTIVATE_T2', 'Tatars to play war you will need to e-mail address is valid. There are exceptional cases may not receive the activation mail');
define('LANGUI_ACTIVATE_T3', 'The causes can be the following');
define('LANGUI_ACTIVATE_T4', 'Typo in the e-mail address');
define('LANGUI_ACTIVATE_T5', 'Inbox full');
define('LANGUI_ACTIVATE_T6', 'E-mail is not true: for example, not only are aol.de @ aol.com @');
define('LANGUI_ACTIVATE_T7', 'You may find the message in the basket of unwanted mail (junk mails)');
define('LANGUI_ACTIVATE_T8', 'You can cancel your registration and use of <u> a different email address </ u>. And will send you a new activation code');
define('LANGUI_ACTIVATE_T9', 'User Name');
define('LANGUI_ACTIVATE_T10', 'Password');
define('LANGUI_ACTIVATE_T11', 'Delete');
define('LANGUI_ACTIVATE_T12', 'Member has been deleted successfully. You can create a new account');
define('LANGUI_ACTIVATE_T13', 'Registra');
define('LANGUI_ACTIVATE_T14', 'Activation has been successfully');
define('LANGUI_ACTIVATE_T15', 'Click here');
define('LANGUI_ACTIVATE_T16', 'Sign in');
define('LANGUI_ACTIVATE_T17', 'This account is enabled by');
?>
