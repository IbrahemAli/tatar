<?php

define('LANGUI_PWD_T1', 'new password');
define('LANGUI_PWD_T2', 'forgot password');
define('LANGUI_PWD_T3', 'Please enter your e-mail that you used to register the first time, even Nstia to send you a new password.
  <br> will receive a new password to your e-mail and password will not work until after the activation and confirm them. ');
define('LANGUI_PWD_T4', 'email');
define('LANGUI_PWD_T5', 'The e-mail address does not match the e-mail during registration.');
define('LANGUI_PWD_T6', 'new password has been sent to your email address. to activate the password prior to use Click on the link in the e-mail.');
define('LANGUI_PWD_T7', 'Password was changed successfully.');
define('LANGUI_PWD_T8', 'Password not changed.');
?>
