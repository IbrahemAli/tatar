<?php
define("LANGUI_CROP_1", "Find Aalghemhyat");
define("LANGUI_CROP_2", "location Start  :");
define("LANGUI_CROP_3", "Kind :");
define("LANGUI_CROP_4", " village from 9 wheat fields");
define("LANGUI_CROP_5", " village from 15 wheat fields");
define("LANGUI_CROP_6", "Non-occupied:");
define("LANGUI_CROP_7", " Show only non-occupied");
define("LANGUI_CROP_8", "Number");
define("LANGUI_CROP_9", "Coordinates");
define("LANGUI_CROP_10", "الKindنوع");
define("LANGUI_CROP_11", "Player");
define("LANGUI_CROP_12", "Occupied");
define("LANGUI_CROP_13", "Distance");
define("LANGUI_CROP_14", "Wheat villages");
define("LANGUI_CROP_15", "9 fields");
define("LANGUI_CROP_16", "15 fields");
define("LANGUI_CROP_17", "Non-occupied");
define("LANGUI_CROP_18", "Occupied");
?>  