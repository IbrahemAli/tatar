<?php
define("LANGUI_CON_T1", "Contact Us");
define("LANGUI_CON_T2", "Company Data");
define("LANGUI_CON_T3", "This game is managed by Techno Games Online Company with limited responsibilities subject to the law of the Arab Republic of Egypt");
define("LANGUI_CON_T4", "Company name: Techno Games Online");
define("LANGUI_CON_T5", "Commercial Registration No : 96623");
define("LANGUI_CON_T6", "Tax card number: 530-654-806");
define("LANGUI_CON_T7", "Address: 13 Saad Bin Abi Waqas St, El Haram, Giza, Egypt");
define("LANGUI_CON_T8", "Email: admin@xtatar.com ");
define("LANGUI_CON_T9", "Phone numper: 00201275545187");
define("LANGUI_CON_T10", "Firstname *");
define("LANGUI_CON_T11", "Lastname *");
define("LANGUI_CON_T12", "Email *");
define("LANGUI_CON_T13", "Phone *");
define("LANGUI_CON_T14", "Message *");
define("LANGUI_CON_T15", "Please enter your ");
define("LANGUI_CON_T16", "Send message");
define("LANGUI_CON_T17", "is required.");
?>