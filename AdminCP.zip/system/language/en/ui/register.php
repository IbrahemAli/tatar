<?php
define('LANGUI_REG_T1', 'Register to play');
define('LANGUI_REG_T2', 'Registration');
define('LANGUI_REG_T3', 'Before signing up, please read through the');
define('LANGUI_REG_T4', 'manual');
define('LANGUI_REG_T5', 'in order to gain a better understanding of the advantages and disadvantages of the three tribes.');
define('LANGUI_REG_T6', 'Nickname');
define('LANGUI_REG_T7', 'E-mail');
define('LANGUI_REG_T8', 'Password');
define('LANGUI_REG_T9', 'Choose tribe');
define('LANGUI_REG_T10', 'Starting position');
define('LANGUI_REG_T11', 'Random');
define('LANGUI_REG_T12', 'Northwest');
define('LANGUI_REG_T13', 'Northeast');
define('LANGUI_REG_T14', 'Southwest');
define('LANGUI_REG_T15', 'Southeast');
define('LANGUI_REG_T16', 'Registration');
define('LANGUI_REG_T17', 'Each player may have only one accoun');
define('LANGUI_REG_T18', 'Welcome');
define('LANGUI_REG_T19', 'your registration was successful. In the next few minutes, you should receive an e-mail with your user information and activation code. <br><br>The e-mail will be sent to the following address');
define("LANGUI_REG_T20", "Maximum 5 memberships same machine");
define("LANGUI_REG_T21", "User Data");
define("LANGUI_REG_T22", "Registration was closed in this server please pressure on the home page and then chose from servers available for registration sorry for the inconvenience");
?>
