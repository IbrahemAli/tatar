<?php

define('LANGUI_ALLIROL_T1', 'The distribution of positions');
define('LANGUI_ALLIROL_T2', 'Name');
define('LANGUI_ALLIROL_T3', 'Position');
define('LANGUI_ALLIROL_T4', 'give rights');
define('LANGUI_ALLIROL_T5', 'the distribution of positions');
define('LANGUI_ALLIROL_T6', 'remove the player');
define('LANGUI_ALLIROL_T7', 'change the description of the coalition');
define('LANGUI_ALLIROL_T8', 'alliance diplomacy');
define('LANGUI_ALLIROL_T9', 'send a message to all the Alliance');
define('LANGUI_ALLIROL_T10', 'invite players to the alliance');
?>
