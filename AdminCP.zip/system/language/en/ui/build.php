<?php

define('LANGUI_BUILD_T1', 'The building is not yet complete');
define('LANGUI_BUILD_T2', 'Updated');
define('LANGUI_BUILD_T3', 'Fully');
define('LANGUI_BUILD_T4', 'Updating');
define('LANGUI_BUILD_T5', 'Cost');
define('LANGUI_BUILD_T6', 'Rising to');
define('LANGUI_BUILD_T7', 'Wheat consumption');
define('LANGUI_BUILD_T8', 'Hide buildings that will be available soon');
define('LANGUI_BUILD_T9', 'Show buildings that will be available soon');
define('LANGUI_BUILD_T10', 'Construction of a new building');
define('LANGUI_BUILD_T11', 'Conditions');
?>
