<?php

define('LANGUI_OVER_T1', 'game over');
define('LANGUI_OVER_T2', 'miracle of the world');
define('LANGUI_OVER_T3', 'win a player');
define('LANGUI_OVER_T4', 'coalition');
?>
