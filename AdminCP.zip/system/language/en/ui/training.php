<?php

define('LANGUI_TRAINING_T1', 'is how you start ...');
define('LANGUI_TRAINING_T2', '... and so can be a village later.');
define('LANGUI_TRAINING_T3', 'At first you only build one building in the small village. <br> <br> and you will find how you can upgrade your village to become strong and prosperous in the next page.');
define('LANGUI_TRAINING_T4', 'back');
define('LANGUI_TRAINING_T5', 'forward');
define('LANGUI_TRAINING_T6', '1 - choose the field of raw resources. ');
define('LANGUI_TRAINING_T7', '2 - and then develop the field of raw resources. ');
define('LANGUI_TRAINING_T8', 'in the Tatar war, there are four types of resources: wood, clay, iron and wheat. <br> <br> before work to take care of buildings Baqratk you upgrade some of the raw resource fields.');
define('LANGUI_TRAINING_T9', '1. chose a building site. ');
define('LANGUI_TRAINING_T10', '2. then the construction of buildings. ');
define('LANGUI_TRAINING_T11', 'care after the production of raw resources, you can start in the development of your village. <br> <br> in the warehouse and store grain, you can store a larger amount of raw resources. bunker protects your resources from looting the enemies.');
define('LANGUI_TRAINING_T12', 'your village and your neighbors');
define('LANGUI_TRAINING_T13', 'Tatar War is a game on the Internet. You play in the network with thousands of players in the world of war Tatar. <br><br> Players of the neighborhood have particular importance. You can get a glimpse of them by a good map.');
define('LANGUI_TRAINING_T14', 'Navigation bar');
define('LANGUI_TRAINING_T15', '<b>Ocean:</b>Here you will find the map of the village and fields of your resources of raw');
define('LANGUI_TRAINING_T16', '<b>Center:</b>In the center of the village you can create buildings.');
define('LANGUI_TRAINING_T17', '<b>Map:</b>Your country and your neighbors here.');
define('LANGUI_TRAINING_T18', '<b>Statistics:</b>Your position and arrangement of all the players.');
define('LANGUI_TRAINING_T19', '<b>Reports:</b>Information on events in your village.');
define('LANGUI_TRAINING_T20', '<b>Messages:</b>Send and receive messages.');
define('LANGUI_TRAINING_T21', 'You know now the most important things about the war Tatars. you can start playing after registration.');
define('LANGUI_TRAINING_T22', 'Register');
define('LANGUI_TRAINING_T23', 'training');
define('LANGUI_TRAINING_T24', 'village');
define('LANGUI_TRAINING_T25', 'sources');
define('LANGUI_TRAINING_T26', 'buildings');
define('LANGUI_TRAINING_T27', 'neighbors');
define('LANGUI_TRAINING_T28', 'navigation');
?>
