<?php

define('LANGUI_VIL1_T1', 'loyalty');
define('LANGUI_VIL1_T2', 'Village Centre');
define('LANGUI_VIL1_T3', 'troop movements');
define('LANGUI_VIL1_T4', 'attacking forces coming');
define('LANGUI_VIL1_T5', 'attack');
define('LANGUI_VIL1_T6', 'collaborating forces next');
define('LANGUI_VIL1_T7', 'promote');
define('LANGUI_VIL1_T8', 'attacking my troops');
define('LANGUI_VIL1_T9', 'my troops cooperating');
define('LANGUI_VIL1_T10', 'attacking forces of the oases');
define('LANGUI_VIL1_T11', 'collaborating forces of the oases');
define('LANGUI_VIL1_T12', 'production');
define('LANGUI_VIL1_T13', 'per hour');
define('LANGUI_VIL1_T14', 'Units');
define('LANGUI_VIL1_T15', 'None');
define('LANGUI_VIL1_T16', 'construction');
define('LANGUI_VIL1_T17', 'cancel');
define('LANGUI_VIL1_T18', 'orders to complete construction and research in this village immediately
Cost 2 Gold ');
define("LANGUI_VIL1_T19", "The store will be filled after:");
define("LANGUI_VIL1_T20", "The store is full");
?>
