<?php

define('LANGUI_FORM_MAIN', 'Home');
define('LANGUI_FORM_HELP', 'Manual');
define("LANGUI_FORM_LOG", "Login");
define("LANGUI_FORM_MANUAL", "Rules of the game");
define('LANGUI_FORM_REG', 'Register');
define("LANGUI_FORM_TERM", "Terms");
define('LANGUI_FORM_NEWS', 'News');
define('LANGUI_FORM_GNAME', 'war of the Tatars');
define("LANGUI_USERS", "Players");
define("LANGUI_ACTIVE", "Active");
define("LANGUI_ONLINE", "Present");
define("LANGUI_FORM_ICO1", "Server 1");
define("LANGUI_FORM_ICO2", "Server 2");
define("LANGUI_FORM_ICO3", "Server 3");
define("LANGUI_FORM_ICO4", "Server 4");
define("LANGUI_FORM_ICO5", "Server 5");
define('LANGUI_INDX_T9', 'English');
define('LANGUI_INDX_T10', 'عربي');
define("LANGUI_FORM_1", "Welcome");
define("LANGUI_FORM_2", " We're loading the content, give us a second. This won't take long!");
define("LANGUI_FORM_3", "Close");
define("LANGUI_FORM_4", "Back to top");
define("LANGUI_FORM_5", "Let's get social");
define("LANGUI_FORM_6", "Facebook");
define("LANGUI_FORM_7", "Twitter");
define("LANGUI_FORM_8", "Google Plus");
define("LANGUI_FORM_9", "YouTube");
define("LANGUI_FORM_10", "Contact Us");
define("LANGUI_FORM_11", "Call Us");
define("LANGUI_FORM_12", "Text Us");
define("LANGUI_FORM_13", "Mail Us");
?>
