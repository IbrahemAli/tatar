<?php
define('LANGUI_RPT_T1', 'Reports');
define('LANGUI_RPT_T2', 'All');
define('LANGUI_RPT_T3', 'Trade');
define('LANGUI_RPT_T4', 'Reinforcements');
define('LANGUI_RPT_T5', 'Attacks');
define('LANGUI_RPT_T6', 'Last');
define('LANGUI_RPT_T7', 'Subject');
define('LANGUI_RPT_T8', 'Sent');
define('LANGUI_RPT_T9', '(not read)');
define('LANGUI_RPT_T10', 'no reports');
define('LANGUI_RPT_T11', 'Delete');
define('LANGUI_RPT_T12', 'The Village');
define('LANGUI_RPT_T13', 'Resources');
define('LANGUI_RPT_T14', 'military units');
define('LANGUI_RPT_T15', 'maintenance');
define('LANGUI_RPT_T16', 'every hour');
define('LANGUI_RPT_T17', 'forward');
define('LANGUI_RPT_T18', 'death');
define('LANGUI_RPT_T19', 'transport capacity');
define('LANGUI_RPT_T20', 'information');
define('LANGUI_RPT_T21', 'did not survive one of your soldiers');
define('LANGUI_RPT_T22', 'defender');
define('LANGUI_RPT_T23', 'sender');
define('LANGUI_RPT_T24', 'booty');
define("LANGUI_RPT_T25", "Found in");
define("LANGUI_RPT_T26", "Belonging to");
?>
