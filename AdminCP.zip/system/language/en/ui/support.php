<?php
define('LANGUI_SUPP_1', 'Messages');
define('LANGUI_SUPP_2', 'Closed Messages');
define('LANGUI_SUPP_3', 'A new message');
define('LANGUI_SUPP_4', 'Send a message to the technical support and administration');
define('LANGUI_SUPP_5', 'Technical support');
define('LANGUI_SUPP_6', 'Choose carefully Section');
define('LANGUI_SUPP_7', 'Department of General inquiries');
define('LANGUI_SUPP_8', 'Department complaints against players');
define('LANGUI_SUPP_9', 'Department of gold and methods of payment problems');
define('LANGUI_SUPP_10', 'Department of game problems and suggestions');
define('LANGUI_SUPP_11', 'Title');
define('LANGUI_SUPP_12', 'Content of the message');
define('LANGUI_SUPP_13', 'Answer Technical Support');
define('LANGUI_SUPP_14', 'Answer player');
define('LANGUI_SUPP_15', 'The answer to the letter');
define('LANGUI_SUPP_16', 'Send');
define('LANGUI_SUPP_17', 'A list of messages to your support');
define('LANGUI_SUPP_18', 'Title');
define('LANGUI_SUPP_19', 'Status');
define('LANGUI_SUPP_20', 'Time');
define('LANGUI_SUPP_21', 'If your application has been resolved. Click here to close the message');
define('LANGUI_SUPP_22', 'There are no messages for technical support');
define('LANGUI_SUPP_stat_0', 'New');
define('LANGUI_SUPP_stat_1', 'Has post');
define('LANGUI_SUPP_stat_2', 'answer player');
define('LANGUI_SUPP_stat_3', 'Closed');
?>