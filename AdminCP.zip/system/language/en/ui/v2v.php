<?php

define('LANGUI_V2V_T1', 'Send troops');
define('LANGUI_V2V_T2', 'support');
define('LANGUI_V2V_T3', 'village');
define('LANGUI_V2V_T4', 'Attack: Full');
define('LANGUI_V2V_T5', 'Attack: looted');
define('LANGUI_V2V_T6', 'target');
define('LANGUI_V2V_T7', 'player');
define('LANGUI_V2V_T8', 'units');
define('LANGUI_V2V_T9', 'resources');
define('LANGUI_V2V_T10', 'Options');
define('LANGUI_V2V_T11', 'spy on the resources and forces');
define('LANGUI_V2V_T12', 'spy on the fortifications and troops');
define('LANGUI_V2V_T13', 'random');
define('LANGUI_V2V_T14', 'will be attacking Palmqalie');
define('LANGUI_V2V_T15', 'second goal');
define('LANGUI_V2V_T16', 'access');
define('LANGUI_V2V_T17', 'hours');
define("LANGUI_V2V_T18", "يصل في ");
?>
