<?php

define('LANGUI_VIL2_T1', 'orders to complete construction and research in this village immediately
Cost 2 Gold ');
define('LANGUI_VIL2_T2', 'cancel');
define('LANGUI_VIL2_T3', 'construction');
?>
