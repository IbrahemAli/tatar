<?php
define('LANGUI_INDX_T1', 'User Name');
define('LANGUI_INDX_T2', 'Password');
define('LANGUI_INDX_T3', 'Log in to');
define('LANGUI_INDX_T4', 'home');
define('LANGUI_INDX_T5', 'Quick Guide');
define('LANGUI_INDX_T6', 'Log in');
define('LANGUI_INDX_T7', 'register');
define('LANGUI_INDX_T8', 'Login to the game');
define('LANGUI_INDX_T9', 'English');
define('LANGUI_INDX_T10', 'عربي');
define('LANGUI_INDX_T11', 'You activate definition files (cookies) to be able to log. If multiple users of this computer must press the log out every time you finish playing in order to preserve your data.');
define('LANGUI_INDX_T12', 'Site News');
define('LANGUI_INDX_T13', 'Help');
define('LANGUI_INDX_T14', 'Training course');
define('LANGUI_INDX_T16', 'Number of Players');
define('LANGUI_INDX_T17', 'Active players');
define('LANGUI_INDX_T18', 'Players online now');
define("LANGUI_INDX_T19", "server started since");
define("LANGUI_INDX_T20", "tatar comes after");
define("LANGUI_INDX_T21", "The descent of the Tartars");
define("LANGUI_INDX_T22", "End server and will be re-opened after ");
define("LANGUI_INDX_T23", "artifacts comes after");
define("LANGUI_INDX_T24", "The revelation of artifacts");
?>
