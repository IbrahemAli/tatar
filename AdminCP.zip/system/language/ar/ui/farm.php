<?php
define("LANGUI_FARM_T1", "قائمة المزارع");
define("LANGUI_FARM_T2", "الجيش");
define("LANGUI_FARM_T3", "حذف");
define("LANGUI_FARM_T4", "لم تقم باضافة اية مزرعة");
define("LANGUI_FARM_T5", "بدا النهب");
define("LANGUI_FARM_T6", "اضافة مزرعة");
define("LANGUI_FARM_T7", "اضافة");
define("LANGUI_FARM_T8", "الرجاء الانتظار بينما يتم الهجوم");
define('LANGUI_FARM_T15', 'الاحداثيات:');
define('LANGUI_FARM_T16', 'القرية');
define('LANGUI_FARM_T17', 'المسافة');
?>
