<?php
define("LANGUI_ALLIROL_T1", "توزيع المناصب");
define("LANGUI_ALLIROL_T2", "الاسم");
define("LANGUI_ALLIROL_T3", "منصب");
define("LANGUI_ALLIROL_T4", "اعطاء الحقوق");
define("LANGUI_ALLIROL_T5", "توزيع المناصب");
define("LANGUI_ALLIROL_T6", "إزالة اللاعب");
define("LANGUI_ALLIROL_T7", "تغيير وصف التحالف");
define("LANGUI_ALLIROL_T8", "دبلوماسية التحالف");
define("LANGUI_ALLIROL_T9", "إرسال رسالة إلى كل التحالف");
define("LANGUI_ALLIROL_T10", "دعوة لاعب إلى التحالف");
?>