<?php
define("LANGUI_VIL1_T1", "الولاء");
define("LANGUI_VIL1_T2", "مركز القرية");
define("LANGUI_VIL1_T3", "تحركات القوات");
define("LANGUI_VIL1_T4", "القوات المهاجمة القادمة");
define("LANGUI_VIL1_T5", "هجوم");
define("LANGUI_VIL1_T6", "القوات المتعاونة القادمة");
define("LANGUI_VIL1_T7", "تعزيز");
define("LANGUI_VIL1_T8", "قواتي المهاجمة");
define("LANGUI_VIL1_T9", "قواتي المتعاونة");
define("LANGUI_VIL1_T10", "القوات المهاجمة للواحات");
define("LANGUI_VIL1_T11", "القوات المتعاونة للواحات");
define("LANGUI_VIL1_T12", "الإنتاج");
define("LANGUI_VIL1_T13", "في الساعة");
define("LANGUI_VIL1_T14", "الوحدات");
define("LANGUI_VIL1_T15", "لا شيء");
define("LANGUI_VIL1_T16", "البناء");
define("LANGUI_VIL1_T17", "إلغاء");
define("LANGUI_VIL1_T18", "إستكمال أوامر البناء والبحث في هذه القرية فورا\r\nالتكلفة 2 ذهب");
define("LANGUI_VIL1_T19", "سيمتلئ المخزن بعد:");
define("LANGUI_VIL1_T20", "المخزن ممتلئ");
?>