<?php
define("LANGUI_REG_T1", "سجل للعب");
define("LANGUI_REG_T2", "تسجيل");
define("LANGUI_REG_T3", "قبل التسجيل يرجى قراءة");
define("LANGUI_REG_T4", "الدليل");
define("LANGUI_REG_T5", "لمعرفة مزايا ومساوئ القبائل");
define("LANGUI_REG_T6", "الاسم المستعار");
define("LANGUI_REG_T7", "البريد الالكتروني");
define("LANGUI_REG_T8", "كلمة السر");
define("LANGUI_REG_T9", "اختر القبيلة");
define("LANGUI_REG_T10", "مكان الابتداء");
define("LANGUI_REG_T11", "عشوائي");
define("LANGUI_REG_T12", "شمال غربي");
define("LANGUI_REG_T13", "شمال شرقي");
define("LANGUI_REG_T14", "جنوب غربي");
define("LANGUI_REG_T15", "جنوب شرقي");
define("LANGUI_REG_T16", "التسجيل");
define("LANGUI_REG_T17", "كل لاعب مسموح له بحساب واحد فقط");
define("LANGUI_REG_T18", "مرحباً");
define("LANGUI_REG_T19", "تم التسجيل بنجاح ويمكنك تسجيل الدخول بدون تفعيل.<br> سيتم خلال دقائق إرسال رسالة بمعلومات التفعيل إلي بريدك الإلكتروني ان لم تقم بتفعيل حسابك لن تحصل على الذهب المجانى طول السيرفر. <br><br> سيتم إرسال البريد إلى العنوان التالي");
define("LANGUI_REG_T20", "الحد الاقصى 5 عضويات من نفس الجهاز");
define("LANGUI_REG_T21", "بيانات المستخدم");
define("LANGUI_REG_T22", "تم اغلاق التسجيل في هذا السيرفر من فضلك الضغط على الصفحة الرئيسية ثم اختار من السيرفرات المتاحه للتسجيل ناسف للازعاج");
?>
