<?php
define("LANGUI_VIL2_T1", "إستكمال أوامر البناء والبحث في هذه القرية فورا\r\nالتكلفة 2 ذهب");
define("LANGUI_VIL2_T2", "الغاء");
define("LANGUI_VIL2_T3", "البناء");
?>