<?php
define("LANGUI_BUILD_T1", "المبنى لم يكتمل بعد");
define("LANGUI_BUILD_T2", "تم تحديث");
define("LANGUI_BUILD_T3", "بالكامل");
define("LANGUI_BUILD_T4", "جاري تحديث");
define("LANGUI_BUILD_T5", "تكلفة");
define("LANGUI_BUILD_T6", "الإرتقاء إلى مستوى");
define("LANGUI_BUILD_T7", "إستهلاك القمح");
define("LANGUI_BUILD_T8", "إخفاء المباني التي ستتوفر قريبا");
define("LANGUI_BUILD_T9", "أظهر المباني التي ستتوفر قريبا");
define("LANGUI_BUILD_T10", "تشييد مبنى جديد");
define("LANGUI_BUILD_T11", "الشروط");
?>