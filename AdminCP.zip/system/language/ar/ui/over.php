<?php
define("LANGUI_OVER_T1", "انتهت اللعبه");
define("LANGUI_OVER_T2", "معجزه العالم");
define("LANGUI_OVER_T3", "بفوز اللاعب");
define("LANGUI_OVER_T4", "من التحالف");
?>