<?php
define('LANGUI_INDX_T1', 'الاسم');
define('LANGUI_INDX_T2', 'كلمة المرور');
define('LANGUI_INDX_T3', 'دخول');
define('LANGUI_INDX_T4', 'الصفحة الرئيسية');
define('LANGUI_INDX_T5', 'الدليل السريع');
define('LANGUI_INDX_T6', 'تسجيل دخول');
define('LANGUI_INDX_T7', 'سجل الأن');
define('LANGUI_INDX_T8', 'تسجيل الدخول للعبة');
define('LANGUI_INDX_T11', 'عليك تفعيل ملفات التعريف (كوكيز) لتتمكن من تسجيل الدخول. و إذا تعدد مستخدموا هذا الحاسب يجب أن تضغط على تسجيل الخروج في كل مرة تنتهي من اللعب وذلك حفاظاً على بياناتك.');
define('LANGUI_INDX_T12', 'اخبار الموقع');
define('LANGUI_INDX_T13', 'تعليمات');
define('LANGUI_INDX_T14', 'دورة تدريبية');
define('LANGUI_INDX_T15', 'شراء سيرفر حرب التتار');
define('LANGUI_INDX_T16', 'عدد اللاعبين');
define('LANGUI_INDX_T17', 'اللاعبون النشطون');
define('LANGUI_INDX_T18', 'اللاعبون الموجودون حالياً');
define("LANGUI_INDX_T19", "بدا السيرفر منذ");
define("LANGUI_INDX_T20", "سيتم نزول التتار بعد");
define("LANGUI_INDX_T21", "التتار نزل");
define("LANGUI_INDX_T22", "انتهى السيرفر وسيتم اعادة افتتاحة بعد ");
define("LANGUI_INDX_T23", "سيتم نزول التحف بعد");
define("LANGUI_INDX_T24", "تم نزول التحف");
?>
