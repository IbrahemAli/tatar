<?php
define("LANGUI_WARSN_T1", "محاكي المعركة");
define("LANGUI_WARSN_T2", "مهاجم");
define("LANGUI_WARSN_T3", "الوحدات");
define("LANGUI_WARSN_T4", "الوفيات");
define("LANGUI_WARSN_T5", "مدافع");
define("LANGUI_WARSN_T6", "نوع المعركه");
define("LANGUI_WARSN_T7", "هجوم كامل");
define("LANGUI_WARSN_T8", "هجوم للنهب");
define("LANGUI_WARSN_T9", "عدد");
define("LANGUI_WARSN_T10", "مستوى أبحاث الاسلحة");
define("LANGUI_WARSN_T11", "أُخْرَيات");
define("LANGUI_WARSN_T12", "السكان");
define("LANGUI_WARSN_T13", "عدد السكان");
define("LANGUI_WARSN_T14", "مستوى المعصرة");
define("LANGUI_WARSN_T15", "مستوى أبحاث التسلح");
define("LANGUI_WARSN_T16", "سور المدينة");
define("LANGUI_WARSN_T17", "مستوى سور المدينة");
?>