<?php
define("LANGUI_MAP_T1", "خريطة");
define("LANGUI_MAP_T2", "التفاصيل");
define("LANGUI_MAP_T3", "وادي مهجور");
define("LANGUI_MAP_T4", "واحة مملوكة");
define("LANGUI_MAP_T5", "واحة غير محتلّة");
define("LANGUI_MAP_T6", "شمال");
define("LANGUI_MAP_T7", "شرق");
define("LANGUI_MAP_T8", "جنوب");
define("LANGUI_MAP_T9", "غرب");
define("LANGUI_MAP_T10", "خريطة كبيرة");
define("LANGUI_MAP_T11", "اللاعب");
define("LANGUI_MAP_T12", "السكان");
define("LANGUI_MAP_T13", "التحالف");
define("LANGUI_MAP_T14", "أغلق الخريطة");
define("LANGUI_MAP_T15", "البحث عن قمحية 9\15");
?>