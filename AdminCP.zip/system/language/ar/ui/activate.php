<?php
define("LANGUI_ACTIVATE_T1", "لم تحصل على رسالة في البريد الالكتروني؟");
define("LANGUI_ACTIVATE_T2", "للعب حرب التتار ستحتاج  لعنوان بريد الكتروني صالح. هنالك حالات استثنائية قد لا تستلم بريد تفعيل الحساب");
define("LANGUI_ACTIVATE_T3", "يمكن ان تكون الاسباب التالية");
define("LANGUI_ACTIVATE_T4", "الخطأ المطبعي في عنوان البريد الإلكتروني");
define("LANGUI_ACTIVATE_T5", "صندوق الواردات ممتلئ");
define("LANGUI_ACTIVATE_T6", "البريد الإلكتروني ليس صحيحا: فعلى سبيل المثال لا توجد aol.de@ فقط aol.com@");
define("LANGUI_ACTIVATE_T7", "ربما تجد الرسالة في سلة البريد الغير مرغوب به (junk mails)");
define("LANGUI_ACTIVATE_T8", "يمكنك  <u> تغيير بريدك الالكترونى </u>. وسيرسل لك كود تفعيل جديد");
define("LANGUI_ACTIVATE_T9", "الاسم المستعار");
define("LANGUI_ACTIVATE_T10", "كلمة السر");
define("LANGUI_ACTIVATE_T11", "تعديل");
define("LANGUI_ACTIVATE_T12", "تم تعديل البريد الالكتروني بنجاح وارسال رسالة تفعيل جديدة");
define("LANGUI_ACTIVATE_T13", "التسجيل");
define("LANGUI_ACTIVATE_T14", "تم التفعيل بنجاح");
define("LANGUI_ACTIVATE_T15", "أنقر هنا");
define("LANGUI_ACTIVATE_T16", "سجل الدخول");
define("LANGUI_ACTIVATE_T17", "هذا الحساب مفعل من قبل");
define("LANGUI_ACTIVATE_T18", "تم ارسال رسالة تفعيل جديدة من فضلك تحقك من البريد الخاص بك");
define("LANGUI_ACTIVATE_T19", "ارسال رسالة تفعيل مرة اخرى");
define("LANGUI_ACTIVATE_T20", "بريد الكتروني جديد");
?>