<?php
define("LANGUI_NEWS_T1", "الاخبار");
define("LANGUI_NEWS_T2", "قائمة الاخبار");
?>