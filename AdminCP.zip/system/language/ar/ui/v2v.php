<?php
define("LANGUI_V2V_T1", "إرسال قوات");
define("LANGUI_V2V_T2", "مساندة");
define("LANGUI_V2V_T3", "القرية");
define("LANGUI_V2V_T4", "هجوم: كامل");
define("LANGUI_V2V_T5", "هجوم: للنهب");
define("LANGUI_V2V_T6", "الهدف");
define("LANGUI_V2V_T7", "اللاعب");
define("LANGUI_V2V_T8", "الوحدات");
define("LANGUI_V2V_T9", "الموارد");
define("LANGUI_V2V_T10", "خيارات");
define("LANGUI_V2V_T11", "التجسس على الموارد والقوات");
define("LANGUI_V2V_T12", "التجسس على التحصينات والقوات");
define("LANGUI_V2V_T13", "عشوائي");
define("LANGUI_V2V_T14", "سيتم المهاجمة بالمقاليع");
define("LANGUI_V2V_T15", "الهدف الثاني");
define("LANGUI_V2V_T16", "وصول");
define("LANGUI_V2V_T17", "ساعات");
define("LANGUI_V2V_T18", "يصل في ");
?>