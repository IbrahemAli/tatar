<?php
define("LANGUI_VILS_1", "احصائيات القرى");
define("LANGUI_VILS_2", "خريطة القرية");
define("LANGUI_VILS_3", "الموارد");
define("LANGUI_VILS_4", "المخازن");
define("LANGUI_VILS_5", "الانتاج");
define("LANGUI_VILS_6", "القوات");
define("LANGUI_VILS_7", "اسم القرية");
define("LANGUI_VILS_8", "السكان");
define("LANGUI_VILS_9", "البناء");
define("LANGUI_VILS_10", "التعزيزات");
define("LANGUI_VILS_11", "الهجمات");
define("LANGUI_VILS_12", "التجار");
define("LANGUI_VILS_13", "هناك عمليات بناء");
define("LANGUI_VILS_14", "هناك قوات صديقة قادمة للمساعدة");
define("LANGUI_VILS_15", "هجمات على هذه القرية");
define("LANGUI_VILS_16", "هجمات من هذه القرية");
define("LANGUI_VILS_17", "هناك تجار قادمون");
define("LANGUI_VILS_18", "القرى");
define("LANGUI_VILS_19", "التجار");
define("LANGUI_VILS_20", "المجموع");
define("LANGUI_VILS_21", "لمشاهدة احصائيات القرى تحتاج الى تفعيل الى حساب بلاس");
?>
  