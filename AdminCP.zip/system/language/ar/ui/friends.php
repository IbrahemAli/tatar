<?php
define("LANGUI_F_T1", "قائمة الاصدقاء");
define("LANGUI_F_T2", "اصدقائك الحاليين");
define("LANGUI_F_T3", "طلبات الصداقة");
define("LANGUI_F_T4", "ارسال طلب صداقة");
define("LANGUI_F_T5", "اسم اللاعب");
define("LANGUI_F_T6", "تاريخ الصداقة");
define("LANGUI_F_T7", "الغاء");
define("LANGUI_F_T8", "لا يوجد لديك اي اصدقاء");
define("LANGUI_F_T9", "قبول");
define("LANGUI_F_T10", "ارسال طلب صداقة");
define("LANGUI_F_T11", "اسم اللاعب");
define("LANGUI_F_T12", "قائمة طلبات الصداقة المرسة");
?>