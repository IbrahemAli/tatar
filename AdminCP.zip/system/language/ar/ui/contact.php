<?php
define("LANGUI_CON_T1", "اتصل بنا");
define("LANGUI_CON_T2", "بيانات الشركة");
define("LANGUI_CON_T3", "تدار هذة اللعبه بواسطة شركة تكنو جيمز اون لاين شركة ذات مسؤوليات محدوده خاضعة لقانون جمهورية مصر العربية");
define("LANGUI_CON_T4", "اسم الشركة: تكنو جيمز اونلاين");
define("LANGUI_CON_T5", "سجل تجاري رقم: ٩٦٦٢٣");
define("LANGUI_CON_T6", "بطاقة ضريبية رقم: ٥٣٠-٦٥٤-٨٠٦");
define("LANGUI_CON_T7", "عنوان الشركة: ١٣ شارع سعد ابن ابي وقاص ، الهرم ، الجيزة ، مصر ");
define("LANGUI_CON_T8", "البريد الالكتروني: admin@xtatar.com");
define("LANGUI_CON_T9", "هاتف رقم: ٠٠٢٠١٢٧٥٥٤٥١٨٧");
define("LANGUI_CON_T10", "اسمك الاول *");
define("LANGUI_CON_T11", "اسمك الاخير *");
define("LANGUI_CON_T12", "البريد الالكتروني *");
define("LANGUI_CON_T13", "رقم الهاتف *");
define("LANGUI_CON_T14", "الرسالة *");
define("LANGUI_CON_T15", "من فضلك ادخل ");
define("LANGUI_CON_T16", "ارسل الرسالة");
define("LANGUI_CON_T17", "مطلوب ");
?>