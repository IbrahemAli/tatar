<?php
define("LANGUI_RPT_T1", "تقارير");
define("LANGUI_RPT_T2", "الجميع");
define("LANGUI_RPT_T3", "التجارة");
define("LANGUI_RPT_T4", "تعزيزات");
define("LANGUI_RPT_T5", "الهجمات");
define("LANGUI_RPT_T6", "آخر");
define("LANGUI_RPT_T7", "الموضوع");
define("LANGUI_RPT_T8", "أرسلت");
define("LANGUI_RPT_T9", "(لم تقرأ)");
define("LANGUI_RPT_T10", "لا يوجد تقارير");
define("LANGUI_RPT_T11", "حذف");
define("LANGUI_RPT_T12", "من القرية");
define("LANGUI_RPT_T13", "الموارد");
define("LANGUI_RPT_T14", "وحدات الجيش");
define("LANGUI_RPT_T15", "تكاليف الصيانة");
define("LANGUI_RPT_T16", "في كل ساعة");
define("LANGUI_RPT_T17", "مهاجم");
define("LANGUI_RPT_T18", "الوفيات");
define("LANGUI_RPT_T19", "قدرة النقل");
define("LANGUI_RPT_T20", "المعلومات");
define("LANGUI_RPT_T21", "لم ينجُ أحد من جنودك");
define("LANGUI_RPT_T22", "مدافع");
define("LANGUI_RPT_T23", "المرسل");
define("LANGUI_RPT_T24", "الغنائم");
define("LANGUI_RPT_T25", "موجودة في");
define("LANGUI_RPT_T26", "تابعة الي");
?>
