<?php
define("LANGUI_CROP_1", "البحث عن القمحيات");
define("LANGUI_CROP_2", "موقع البداية :");
define("LANGUI_CROP_3", "النوع :");
define("LANGUI_CROP_4", " قمحية 9 حقول");
define("LANGUI_CROP_5", " قمحية 15 حقل");
define("LANGUI_CROP_6", "الغير محتلة:");
define("LANGUI_CROP_7", " اظهار الغير محتلة فقط");
define("LANGUI_CROP_8", "الرقم");
define("LANGUI_CROP_9", "الاحداثيات");
define("LANGUI_CROP_10", "النوع");
define("LANGUI_CROP_11", "اللاعب");
define("LANGUI_CROP_12", "محتلة");
define("LANGUI_CROP_13", "المسافة");
define("LANGUI_CROP_14", "القرى القمحية");
define("LANGUI_CROP_15", "9 حقول");
define("LANGUI_CROP_16", "15 حقل");
define("LANGUI_CROP_17", "غير محتلة");
define("LANGUI_CROP_18", "محتلة");
define("LANGUI_CROP_19", "الواحات القمحية");
define("LANGUI_CROP_20", "واحة قمحية");
?>  