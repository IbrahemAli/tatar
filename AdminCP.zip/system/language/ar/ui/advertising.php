<?php
define("LANGUI_ADV_T1", "ادارة الاعلانات");
define("LANGUI_ADV_T2", "تعديل إعلان");
define("LANGUI_ADV_T3", "إضافة إعلان");
define("LANGUI_ADV_T4", "إضافة جديدة");
define("LANGUI_ADV_T5", "الاسم");
define("LANGUI_ADV_T6", "الاعلان");
define("LANGUI_ADV_T7", "اضف رابط الاعلان \\n صورة او فلاشة");
define("LANGUI_ADV_T8", "الرابط");
define("LANGUI_ADV_T9", "القسم");
define("LANGUI_ADV_T10", "الرئيسية");
define("LANGUI_ADV_T11", "اللعبة");
define("LANGUI_ADV_T12", "الاعلانات");
define("LANGUI_ADV_T13", "رقم");
define("LANGUI_ADV_T14", "الزيارات");
define("LANGUI_ADV_T15", "العرض");
define("LANGUI_ADV_T16", "التحكم");
define("LANGUI_ADV_T17", "عرض الاعلان");
define("LANGUI_ADV_T18", "حذف الاعلان");
define("LANGUI_ADV_T19", "تعديل الاعلان");
define("LANGUI_ADV_T20", "تمام");
define("LANGUI_ADV_T21", "إِرْشاد");
?>