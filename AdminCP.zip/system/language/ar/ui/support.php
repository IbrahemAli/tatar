<?php
define('LANGUI_SUPP_1', 'الرسائل');
define('LANGUI_SUPP_2', 'الرسائل المغلقة');
define('LANGUI_SUPP_3', 'رسالة جديدة');
define('LANGUI_SUPP_4', 'ارسال رسالة الى الدعم الفنى والادارة');
define('LANGUI_SUPP_5', 'الدعم الفنى');
define('LANGUI_SUPP_6', 'اختر القسم بعناية');
define('LANGUI_SUPP_7', 'قسم الاستفسارات العامة');
define('LANGUI_SUPP_8', 'قسم الشكاوى ضد اللاعبين');
define('LANGUI_SUPP_9', 'قسم مشاكل الذهب وطرق الدفع');
define('LANGUI_SUPP_10', 'قسم مشاكل اللعبه والاقتراحات');
define('LANGUI_SUPP_11', 'عنوان الرسالة');
define('LANGUI_SUPP_12', 'محتوى الرساله');
define('LANGUI_SUPP_13', 'رد الدعم الفني');
define('LANGUI_SUPP_14', 'رد اللاعب');
define('LANGUI_SUPP_15', 'الرد على الرساله');
define('LANGUI_SUPP_16', 'ارسال');
define('LANGUI_SUPP_17', 'قائمة بالرسائل الخاصه بك الى الدعم');
define('LANGUI_SUPP_18', 'العنوان');
define('LANGUI_SUPP_19', 'الحالة');
define('LANGUI_SUPP_20', 'الوقت');
define('LANGUI_SUPP_21', 'اذا تم حل طلبك اضغط هنا لاغلاق الرساله');
define('LANGUI_SUPP_22', 'لا يوجد رسائل للدعم الفني');
define('LANGUI_SUPP_23', 'محادثة شات مع الدعم');
define('LANGUI_SUPP_stat_0', 'جديدة');
define('LANGUI_SUPP_stat_1', 'مجاب عليها');
define('LANGUI_SUPP_stat_2', 'رد اللاعب');
define('LANGUI_SUPP_stat_3', 'مغلقة');
?>