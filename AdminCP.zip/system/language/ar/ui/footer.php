<?php
define("LANGUI_FOOTER_MAIN", "الصفحة الرئيسية");
define("LANGUI_FOOTER_MANUAL", "تعليمات");
define("LANGUI_FOOTER_TRAINING", "دورة تدريبية");
?>