<?php
define("LANGUI_MSG_T1", "رسائل");
define("LANGUI_MSG_T2", "صندوق الواردات");
define("LANGUI_MSG_T3", "أكتب");
define("LANGUI_MSG_T4", "المرسلة");
define("LANGUI_MSG_T5", "الموضوع");
define("LANGUI_MSG_T6", "المستلم");
define("LANGUI_MSG_T7", "المرسل");
define("LANGUI_MSG_T8", "أرسل");
define("LANGUI_MSG_T9", "(جديد)");
define("LANGUI_MSG_T10", "(لم تقرأ بعد)");
define("LANGUI_MSG_T11", "لا يوجد رسائل");
define("LANGUI_MSG_T12", "حذف");
define("LANGUI_MSG_T13", "دفتر العناوين");
define("LANGUI_MSG_T14", "الجواب");
define("LANGUI_MSG_T15", "إرسال");
define("LANGUI_MSG_T16", "أقفل دفتر العناوين");
define("LANGUI_MSG_T17", "لإرسال رسالة لأعضاء تحالفك أكتب في أسم المستلم <b>[ally]</b><br/>أيضا يجب أن تملك هذه السماحية");
?>