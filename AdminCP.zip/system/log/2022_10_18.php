2022_10_18 Apache <br/>
<br/><br/>

<a name=""></a>#1666041035 /index.php</pre><br/><br/>

<div class="ee">
Warning: PDOStatement::execute(): SQLSTATE[42S02]: Base table or view not found: 1146 Table 'tatartest_m.settings' doesn't exist in <b>/system/library/DB2.php</b> on line <b>47</b><br/><div class="ei">
-/system/library/DB2.php : 78<br/>
-/Applic/models/Servers.php : 22<br/>
-/Applic/bootstrap.php : 45<br/>
-/index.php : 22<br/>
</div></div><div class="ee">
Warning: PDOStatement::execute(): SQLSTATE[42S02]: Base table or view not found: 1146 Table 'tatartest_m.settings' doesn't exist in <b>/system/library/DB2.php</b> on line <b>47</b><br/><div class="ei">
-/system/library/DB2.php : 78<br/>
-/Applic/models/Servers.php : 22<br/>
-/Applic/bootstrap.php : 46<br/>
-/index.php : 22<br/>
</div></div><div class="ee">
Notice: Trying to access array offset on value of type null in <b>/system/library/ClientData.php</b> on line <b>13</b><br/><div class="ei">
-/index.php : 22<br/>
</div></div><div class="ee">
Notice: Trying to access array offset on value of type null in <b>/system/library/ClientData.php</b> on line <b>13</b><br/><div class="ei">
-/Applic/bootstrap.php : 51<br/>
-/index.php : 22<br/>
</div></div><div class="ee">
Notice: Trying to access array offset on value of type null in <b>/system/library/ClientData.php</b> on line <b>13</b><br/><div class="ei">
-/system/library/gameEngine/BaseController.php : 20<br/>
-/system/library/gameEngine/PublicController.php : 9<br/>
-/Applic/controllers/index.php : 8<br/>
-/system/library/Loader.php : 89<br/>
-/system/library/Loader.php : 59<br/>
-/Applic/bootstrap.php : 64<br/>
-/index.php : 22<br/>
</div></div><div class="ee">
Notice: Trying to access array offset on value of type null in <b>/system/library/ClientData.php</b> on line <b>13</b><br/><div class="ei">
-/system/library/gameEngine/BaseController.php : 21<br/>
-/system/library/gameEngine/PublicController.php : 9<br/>
-/Applic/controllers/index.php : 8<br/>
-/system/library/Loader.php : 89<br/>
-/system/library/Loader.php : 59<br/>
-/Applic/bootstrap.php : 64<br/>
-/index.php : 22<br/>
</div></div><div class="ee">
Notice: Trying to access array offset on value of type null in <b>/system/library/gameEngine/BaseController.php</b> on line <b>23</b><br/><div class="ei">
-/Applic/controllers/index.php : 8<br/>
-/system/library/Loader.php : 89<br/>
-/system/library/Loader.php : 59<br/>
-/Applic/bootstrap.php : 64<br/>
-/index.php : 22<br/>
</div></div><div class="ee">
Notice: Trying to access array offset on value of type null in <b>/system/library/gameEngine/BaseController.php</b> on line <b>24</b><br/><div class="ei">
-/Applic/controllers/index.php : 8<br/>
-/system/library/Loader.php : 89<br/>
-/system/library/Loader.php : 59<br/>
-/Applic/bootstrap.php : 64<br/>
-/index.php : 22<br/>
</div></div><div class="ee">
Warning: PDOStatement::execute(): SQLSTATE[42S02]: Base table or view not found: 1146 Table 'tatartest_m.servers' doesn't exist in <b>/system/library/DB2.php</b> on line <b>47</b><br/><div class="ei">
-/system/library/DB2.php : 111<br/>
-/Applic/models/Servers.php : 7<br/>
-/system/library/gameEngine/PublicController.php : 12<br/>
-/Applic/controllers/index.php : 8<br/>
-/system/library/Loader.php : 89<br/>
-/system/library/Loader.php : 59<br/>
-/Applic/bootstrap.php : 64<br/>
-/index.php : 22<br/>
</div></div><br/><br/>

<a name=""></a>#1666041036 /assets/indx/images/tatar_logo.png</pre><br/><br/>

<div class="ee">
Warning: PDOStatement::execute(): SQLSTATE[42S02]: Base table or view not found: 1146 Table 'tatartest_m.settings' doesn't exist in <b>/system/library/DB2.php</b> on line <b>47</b><br/><div class="ei">
-/system/library/DB2.php : 78<br/>
-/Applic/models/Servers.php : 22<br/>
-/Applic/bootstrap.php : 45<br/>
-/index.php : 22<br/>
</div></div><div class="ee">
Warning: PDOStatement::execute(): SQLSTATE[42S02]: Base table or view not found: 1146 Table 'tatartest_m.settings' doesn't exist in <b>/system/library/DB2.php</b> on line <b>47</b><br/><div class="ei">
-/system/library/DB2.php : 78<br/>
-/Applic/models/Servers.php : 22<br/>
-/Applic/bootstrap.php : 46<br/>
-/index.php : 22<br/>
</div></div><div class="ee">
Notice: Trying to access array offset on value of type null in <b>/system/library/ClientData.php</b> on line <b>13</b><br/><div class="ei">
-/index.php : 22<br/>
</div></div><div class="ee">
Notice: Trying to access array offset on value of type null in <b>/system/library/ClientData.php</b> on line <b>13</b><br/><div class="ei">
-/Applic/bootstrap.php : 51<br/>
-/index.php : 22<br/>
</div></div><br/><br/>

<a name=""></a>#1666041036 /assets/indx/css/index-.css</pre><br/><br/>

<div class="ee">
Warning: PDOStatement::execute(): SQLSTATE[42S02]: Base table or view not found: 1146 Table 'tatartest_m.settings' doesn't exist in <b>/system/library/DB2.php</b> on line <b>47</b><br/><div class="ei">
-/system/library/DB2.php : 78<br/>
-/Applic/models/Servers.php : 22<br/>
-/Applic/bootstrap.php : 45<br/>
-/index.php : 22<br/>
</div></div><div class="ee">
Warning: PDOStatement::execute(): SQLSTATE[42S02]: Base table or view not found: 1146 Table 'tatartest_m.settings' doesn't exist in <b>/system/library/DB2.php</b> on line <b>47</b><br/><div class="ei">
-/system/library/DB2.php : 78<br/>
-/Applic/models/Servers.php : 22<br/>
-/Applic/bootstrap.php : 46<br/>
-/index.php : 22<br/>
</div></div><div class="ee">
Notice: Trying to access array offset on value of type null in <b>/system/library/ClientData.php</b> on line <b>13</b><br/><div class="ei">
-/index.php : 22<br/>
</div></div><div class="ee">
Notice: Trying to access array offset on value of type null in <b>/system/library/ClientData.php</b> on line <b>13</b><br/><div class="ei">
-/Applic/bootstrap.php : 51<br/>
-/index.php : 22<br/>
</div></div><br/><br/>

<a name=""></a>#1666041036 /index.php</pre><br/><br/>

<div class="ee">
Warning: PDOStatement::execute(): SQLSTATE[42S02]: Base table or view not found: 1146 Table 'tatartest_m.settings' doesn't exist in <b>/system/library/DB2.php</b> on line <b>47</b><br/><div class="ei">
-/system/library/DB2.php : 78<br/>
-/Applic/models/Servers.php : 22<br/>
-/Applic/bootstrap.php : 45<br/>
-/index.php : 22<br/>
</div></div><div class="ee">
Warning: PDOStatement::execute(): SQLSTATE[42S02]: Base table or view not found: 1146 Table 'tatartest_m.settings' doesn't exist in <b>/system/library/DB2.php</b> on line <b>47</b><br/><div class="ei">
-/system/library/DB2.php : 78<br/>
-/Applic/models/Servers.php : 22<br/>
-/Applic/bootstrap.php : 46<br/>
-/index.php : 22<br/>
</div></div><div class="ee">
Notice: Trying to access array offset on value of type null in <b>/system/library/ClientData.php</b> on line <b>13</b><br/><div class="ei">
-/index.php : 22<br/>
</div></div><div class="ee">
Notice: Trying to access array offset on value of type null in <b>/system/library/ClientData.php</b> on line <b>13</b><br/><div class="ei">
-/Applic/bootstrap.php : 51<br/>
-/index.php : 22<br/>
</div></div><div class="ee">
Notice: Trying to access array offset on value of type null in <b>/system/library/ClientData.php</b> on line <b>13</b><br/><div class="ei">
-/system/library/gameEngine/BaseController.php : 20<br/>
-/system/library/gameEngine/PublicController.php : 9<br/>
-/Applic/controllers/index.php : 8<br/>
-/system/library/Loader.php : 89<br/>
-/system/library/Loader.php : 59<br/>
-/Applic/bootstrap.php : 64<br/>
-/index.php : 22<br/>
</div></div><div class="ee">
Notice: Trying to access array offset on value of type null in <b>/system/library/ClientData.php</b> on line <b>13</b><br/><div class="ei">
-/system/library/gameEngine/BaseController.php : 21<br/>
-/system/library/gameEngine/PublicController.php : 9<br/>
-/Applic/controllers/index.php : 8<br/>
-/system/library/Loader.php : 89<br/>
-/system/library/Loader.php : 59<br/>
-/Applic/bootstrap.php : 64<br/>
-/index.php : 22<br/>
</div></div><div class="ee">
Notice: Trying to access array offset on value of type null in <b>/system/library/gameEngine/BaseController.php</b> on line <b>23</b><br/><div class="ei">
-/Applic/controllers/index.php : 8<br/>
-/system/library/Loader.php : 89<br/>
-/system/library/Loader.php : 59<br/>
-/Applic/bootstrap.php : 64<br/>
-/index.php : 22<br/>
</div></div><div class="ee">
Notice: Trying to access array offset on value of type null in <b>/system/library/gameEngine/BaseController.php</b> on line <b>24</b><br/><div class="ei">
-/Applic/controllers/index.php : 8<br/>
-/system/library/Loader.php : 89<br/>
-/system/library/Loader.php : 59<br/>
-/Applic/bootstrap.php : 64<br/>
-/index.php : 22<br/>
</div></div><div class="ee">
Warning: PDOStatement::execute(): SQLSTATE[42S02]: Base table or view not found: 1146 Table 'tatartest_m.servers' doesn't exist in <b>/system/library/DB2.php</b> on line <b>47</b><br/><div class="ei">
-/system/library/DB2.php : 111<br/>
-/Applic/models/Servers.php : 7<br/>
-/system/library/gameEngine/PublicController.php : 12<br/>
-/Applic/controllers/index.php : 8<br/>
-/system/library/Loader.php : 89<br/>
-/system/library/Loader.php : 59<br/>
-/Applic/bootstrap.php : 64<br/>
-/index.php : 22<br/>
</div></div><br/><br/>

<a name=""></a>#1666041036 /assets/indx/js/text-effect.js</pre><br/><br/>

<div class="ee">
Warning: PDOStatement::execute(): SQLSTATE[42S02]: Base table or view not found: 1146 Table 'tatartest_m.settings' doesn't exist in <b>/system/library/DB2.php</b> on line <b>47</b><br/><div class="ei">
-/system/library/DB2.php : 78<br/>
-/Applic/models/Servers.php : 22<br/>
-/Applic/bootstrap.php : 45<br/>
-/index.php : 22<br/>
</div></div><div class="ee">
Warning: PDOStatement::execute(): SQLSTATE[42S02]: Base table or view not found: 1146 Table 'tatartest_m.settings' doesn't exist in <b>/system/library/DB2.php</b> on line <b>47</b><br/><div class="ei">
-/system/library/DB2.php : 78<br/>
-/Applic/models/Servers.php : 22<br/>
-/Applic/bootstrap.php : 46<br/>
-/index.php : 22<br/>
</div></div><div class="ee">
Notice: Trying to access array offset on value of type null in <b>/system/library/ClientData.php</b> on line <b>13</b><br/><div class="ei">
-/index.php : 22<br/>
</div></div><div class="ee">
Notice: Trying to access array offset on value of type null in <b>/system/library/ClientData.php</b> on line <b>13</b><br/><div class="ei">
-/Applic/bootstrap.php : 51<br/>
-/index.php : 22<br/>
</div></div><br/><br/>

<a name=""></a>#1666041036 /index.php</pre><br/><br/>

<div class="ee">
Warning: PDOStatement::execute(): SQLSTATE[42S02]: Base table or view not found: 1146 Table 'tatartest_m.settings' doesn't exist in <b>/system/library/DB2.php</b> on line <b>47</b><br/><div class="ei">
-/system/library/DB2.php : 78<br/>
-/Applic/models/Servers.php : 22<br/>
-/Applic/bootstrap.php : 45<br/>
-/index.php : 22<br/>
</div></div><div class="ee">
Warning: PDOStatement::execute(): SQLSTATE[42S02]: Base table or view not found: 1146 Table 'tatartest_m.settings' doesn't exist in <b>/system/library/DB2.php</b> on line <b>47</b><br/><div class="ei">
-/system/library/DB2.php : 78<br/>
-/Applic/models/Servers.php : 22<br/>
-/Applic/bootstrap.php : 46<br/>
-/index.php : 22<br/>
</div></div><div class="ee">
Notice: Trying to access array offset on value of type null in <b>/system/library/ClientData.php</b> on line <b>13</b><br/><div class="ei">
-/index.php : 22<br/>
</div></div><div class="ee">
Notice: Trying to access array offset on value of type null in <b>/system/library/ClientData.php</b> on line <b>13</b><br/><div class="ei">
-/Applic/bootstrap.php : 51<br/>
-/index.php : 22<br/>
</div></div><div class="ee">
Notice: Trying to access array offset on value of type null in <b>/system/library/ClientData.php</b> on line <b>13</b><br/><div class="ei">
-/system/library/gameEngine/BaseController.php : 20<br/>
-/system/library/gameEngine/PublicController.php : 9<br/>
-/Applic/controllers/index.php : 8<br/>
-/system/library/Loader.php : 89<br/>
-/system/library/Loader.php : 59<br/>
-/Applic/bootstrap.php : 64<br/>
-/index.php : 22<br/>
</div></div><div class="ee">
Notice: Trying to access array offset on value of type null in <b>/system/library/ClientData.php</b> on line <b>13</b><br/><div class="ei">
-/system/library/gameEngine/BaseController.php : 21<br/>
-/system/library/gameEngine/PublicController.php : 9<br/>
-/Applic/controllers/index.php : 8<br/>
-/system/library/Loader.php : 89<br/>
-/system/library/Loader.php : 59<br/>
-/Applic/bootstrap.php : 64<br/>
-/index.php : 22<br/>
</div></div><div class="ee">
Notice: Trying to access array offset on value of type null in <b>/system/library/gameEngine/BaseController.php</b> on line <b>23</b><br/><div class="ei">
-/Applic/controllers/index.php : 8<br/>
-/system/library/Loader.php : 89<br/>
-/system/library/Loader.php : 59<br/>
-/Applic/bootstrap.php : 64<br/>
-/index.php : 22<br/>
</div></div><div class="ee">
Notice: Trying to access array offset on value of type null in <b>/system/library/gameEngine/BaseController.php</b> on line <b>24</b><br/><div class="ei">
-/Applic/controllers/index.php : 8<br/>
-/system/library/Loader.php : 89<br/>
-/system/library/Loader.php : 59<br/>
-/Applic/bootstrap.php : 64<br/>
-/index.php : 22<br/>
</div></div><div class="ee">
Warning: PDOStatement::execute(): SQLSTATE[42S02]: Base table or view not found: 1146 Table 'tatartest_m.servers' doesn't exist in <b>/system/library/DB2.php</b> on line <b>47</b><br/><div class="ei">
-/system/library/DB2.php : 111<br/>
-/Applic/models/Servers.php : 7<br/>
-/system/library/gameEngine/PublicController.php : 12<br/>
-/Applic/controllers/index.php : 8<br/>
-/system/library/Loader.php : 89<br/>
-/system/library/Loader.php : 59<br/>
-/Applic/bootstrap.php : 64<br/>
-/index.php : 22<br/>
</div></div><br/><br/>

<a name=""></a>#1666041036 /index.php</pre><br/><br/>

<div class="ee">
Warning: PDOStatement::execute(): SQLSTATE[42S02]: Base table or view not found: 1146 Table 'tatartest_m.settings' doesn't exist in <b>/system/library/DB2.php</b> on line <b>47</b><br/><div class="ei">
-/system/library/DB2.php : 78<br/>
-/Applic/models/Servers.php : 22<br/>
-/Applic/bootstrap.php : 45<br/>
-/index.php : 22<br/>
</div></div><div class="ee">
Warning: PDOStatement::execute(): SQLSTATE[42S02]: Base table or view not found: 1146 Table 'tatartest_m.settings' doesn't exist in <b>/system/library/DB2.php</b> on line <b>47</b><br/><div class="ei">
-/system/library/DB2.php : 78<br/>
-/Applic/models/Servers.php : 22<br/>
-/Applic/bootstrap.php : 46<br/>
-/index.php : 22<br/>
</div></div><div class="ee">
Notice: Trying to access array offset on value of type null in <b>/system/library/ClientData.php</b> on line <b>13</b><br/><div class="ei">
-/index.php : 22<br/>
</div></div><div class="ee">
Notice: Trying to access array offset on value of type null in <b>/system/library/ClientData.php</b> on line <b>13</b><br/><div class="ei">
-/Applic/bootstrap.php : 51<br/>
-/index.php : 22<br/>
</div></div><div class="ee">
Notice: Trying to access array offset on value of type null in <b>/system/library/ClientData.php</b> on line <b>13</b><br/><div class="ei">
-/system/library/gameEngine/BaseController.php : 20<br/>
-/system/library/gameEngine/PublicController.php : 9<br/>
-/Applic/controllers/index.php : 8<br/>
-/system/library/Loader.php : 89<br/>
-/system/library/Loader.php : 59<br/>
-/Applic/bootstrap.php : 64<br/>
-/index.php : 22<br/>
</div></div><div class="ee">
Notice: Trying to access array offset on value of type null in <b>/system/library/ClientData.php</b> on line <b>13</b><br/><div class="ei">
-/system/library/gameEngine/BaseController.php : 21<br/>
-/system/library/gameEngine/PublicController.php : 9<br/>
-/Applic/controllers/index.php : 8<br/>
-/system/library/Loader.php : 89<br/>
-/system/library/Loader.php : 59<br/>
-/Applic/bootstrap.php : 64<br/>
-/index.php : 22<br/>
</div></div><div class="ee">
Notice: Trying to access array offset on value of type null in <b>/system/library/gameEngine/BaseController.php</b> on line <b>23</b><br/><div class="ei">
-/Applic/controllers/index.php : 8<br/>
-/system/library/Loader.php : 89<br/>
-/system/library/Loader.php : 59<br/>
-/Applic/bootstrap.php : 64<br/>
-/index.php : 22<br/>
</div></div><div class="ee">
Notice: Trying to access array offset on value of type null in <b>/system/library/gameEngine/BaseController.php</b> on line <b>24</b><br/><div class="ei">
-/Applic/controllers/index.php : 8<br/>
-/system/library/Loader.php : 89<br/>
-/system/library/Loader.php : 59<br/>
-/Applic/bootstrap.php : 64<br/>
-/index.php : 22<br/>
</div></div><div class="ee">
Warning: PDOStatement::execute(): SQLSTATE[42S02]: Base table or view not found: 1146 Table 'tatartest_m.servers' doesn't exist in <b>/system/library/DB2.php</b> on line <b>47</b><br/><div class="ei">
-/system/library/DB2.php : 111<br/>
-/Applic/models/Servers.php : 7<br/>
-/system/library/gameEngine/PublicController.php : 12<br/>
-/Applic/controllers/index.php : 8<br/>
-/system/library/Loader.php : 89<br/>
-/system/library/Loader.php : 59<br/>
-/Applic/bootstrap.php : 64<br/>
-/index.php : 22<br/>
</div></div><br/><br/>

<a name="1-الادارة"></a>#1666042187 /village1</pre><br/><br/>

<div class="ee">
Warning: PDOStatement::execute(): SQLSTATE[23000]: Integrity constraint violation: 1062 Duplicate entry 'servers@xtatar.com' for key 'NewIndex4' in <b>/system/library/DB2.php</b> on line <b>47</b><br/><div class="ei">
-/system/library/DB2.php : 65<br/>
-/Applic/models/Register.php : 164<br/>
-/Applic/models/Install.php : 438<br/>
-/Applic/models/Install.php : 22<br/>
-/Applic/models/Queuejob.php : 218<br/>
-/Applic/models/Queuejob.php : 50<br/>
-/Applic/models/Queuejob.php : 13<br/>
-/system/library/gameEngine/BaseController.php : 46<br/>
-/system/library/gameEngine/AuthController.php : 24<br/>
-/system/library/gameEngine/VillageController.php : 11<br/>
-/system/library/gameEngine/ProgressVillageController.php : 9<br/>
-/Applic/controllers/village1.php : 11<br/>
-/system/library/Loader.php : 89<br/>
-/system/library/Loader.php : 59<br/>
-/Applic/bootstrap.php : 64<br/>
-/index.php : 22<br/>
</div></div><br/><br/>

<a name="1-الادارة"></a>#1666042225 /loginPOST: <br/>
<pre>Array
(
    [name] => الادارة
    [password] => a234567
    [server] => 1
)
</pre><br/><br/>

<div class="ee">
Warning: array_merge(): Argument #2 is not an array in <b>/Applic/models/Login.php</b> on line <b>42</b><br/><div class="ei">
-/Applic/controllers/login.php : 49<br/>
-/Applic/controllers/login.php : 27<br/>
-/system/library/Loader.php : 103<br/>
-/system/library/Loader.php : 59<br/>
-/Applic/bootstrap.php : 64<br/>
-/index.php : 22<br/>
</div></div><br/><br/>

<a name="1-الادارة"></a>#1666042316 /loginPOST: <br/>
<pre>Array
(
    [name] => admin
    [password] =>  A111222
    [server] => 1
)
</pre><br/><br/>

<div class="ee">
Warning: PDOStatement::execute(): SQLSTATE[23000]: Integrity constraint violation: 1062 Duplicate entry 'servers@xtatar.com' for key 'NewIndex4' in <b>/system/library/DB2.php</b> on line <b>47</b><br/><div class="ei">
-/system/library/DB2.php : 65<br/>
-/Applic/models/Register.php : 164<br/>
-/Applic/models/Install.php : 438<br/>
-/Applic/models/Install.php : 22<br/>
-/Applic/models/Queuejob.php : 218<br/>
-/Applic/models/Queuejob.php : 50<br/>
-/Applic/models/Queuejob.php : 13<br/>
-/system/library/gameEngine/BaseController.php : 46<br/>
-/system/library/gameEngine/PublicController.php : 9<br/>
-/Applic/controllers/login.php : 14<br/>
-/system/library/Loader.php : 89<br/>
-/system/library/Loader.php : 59<br/>
-/Applic/bootstrap.php : 64<br/>
-/index.php : 22<br/>
</div></div><br/><br/>

<a name="1-الادارة"></a>#1666042376 /index.php</pre><br/><br/>

<div class="ee">
Warning: PDOStatement::execute(): SQLSTATE[23000]: Integrity constraint violation: 1062 Duplicate entry 'servers@xtatar.com' for key 'NewIndex4' in <b>/system/library/DB2.php</b> on line <b>47</b><br/><div class="ei">
-/system/library/DB2.php : 65<br/>
-/Applic/models/Register.php : 164<br/>
-/Applic/models/Install.php : 438<br/>
-/Applic/models/Install.php : 22<br/>
-/Applic/models/Queuejob.php : 218<br/>
-/Applic/models/Queuejob.php : 50<br/>
-/Applic/models/Queuejob.php : 13<br/>
-/system/library/gameEngine/BaseController.php : 46<br/>
-/system/library/gameEngine/PublicController.php : 9<br/>
-/Applic/controllers/index.php : 8<br/>
-/system/library/Loader.php : 89<br/>
-/system/library/Loader.php : 59<br/>
-/Applic/bootstrap.php : 64<br/>
-/index.php : 22<br/>
</div></div><br/><br/>

<a name=""></a>#1666084135 /news/wp-includes/wlwmanifest.xml</pre><br/><br/>

<div class="ee">
Warning: PDOStatement::execute(): SQLSTATE[42S02]: Base table or view not found: 1146 Table 'tatartest_m.news' doesn't exist in <b>/system/library/DB2.php</b> on line <b>47</b><br/><div class="ei">
-/system/library/DB2.php : 111<br/>
-/Applic/models/News.php : 8<br/>
-/Applic/controllers/news.php : 15<br/>
-/system/library/Loader.php : 103<br/>
-/system/library/Loader.php : 59<br/>
-/Applic/bootstrap.php : 64<br/>
-/index.php : 22<br/>
</div></div><div class="ee">
Notice: Undefined index: id in <b>/Applic/controllers/news.php</b> on line <b>16</b><br/><div class="ei">
-/system/library/Loader.php : 59<br/>
-/Applic/bootstrap.php : 64<br/>
-/index.php : 22<br/>
</div></div><br/><br/>

<a name=""></a>#1666096852 /news/wp-includes/wlwmanifest.xml</pre><br/><br/>

<div class="ee">
Warning: PDOStatement::execute(): SQLSTATE[42S02]: Base table or view not found: 1146 Table 'tatartest_m.news' doesn't exist in <b>/system/library/DB2.php</b> on line <b>47</b><br/><div class="ei">
-/system/library/DB2.php : 111<br/>
-/Applic/models/News.php : 8<br/>
-/Applic/controllers/news.php : 15<br/>
-/system/library/Loader.php : 103<br/>
-/system/library/Loader.php : 59<br/>
-/Applic/bootstrap.php : 64<br/>
-/index.php : 22<br/>
</div></div><div class="ee">
Notice: Undefined index: id in <b>/Applic/controllers/news.php</b> on line <b>16</b><br/><div class="ei">
-/system/library/Loader.php : 59<br/>
-/Applic/bootstrap.php : 64<br/>
-/index.php : 22<br/>
</div></div><br/><br/>

<a name=""></a>#1666102218 /news</pre><br/><br/>

<div class="ee">
Warning: PDOStatement::execute(): SQLSTATE[42S02]: Base table or view not found: 1146 Table 'tatartest_m.news' doesn't exist in <b>/system/library/DB2.php</b> on line <b>47</b><br/><div class="ei">
-/system/library/DB2.php : 111<br/>
-/Applic/models/News.php : 8<br/>
-/Applic/controllers/news.php : 15<br/>
-/system/library/Loader.php : 103<br/>
-/system/library/Loader.php : 59<br/>
-/Applic/bootstrap.php : 64<br/>
-/index.php : 22<br/>
</div></div><div class="ee">
Notice: Undefined index: id in <b>/Applic/controllers/news.php</b> on line <b>16</b><br/><div class="ei">
-/system/library/Loader.php : 59<br/>
-/Applic/bootstrap.php : 64<br/>
-/index.php : 22<br/>
</div></div><br/><br/>

<a name=""></a>#1666105867 /news</pre><br/><br/>

<div class="ee">
Warning: PDOStatement::execute(): SQLSTATE[42S02]: Base table or view not found: 1146 Table 'tatartest_m.news' doesn't exist in <b>/system/library/DB2.php</b> on line <b>47</b><br/><div class="ei">
-/system/library/DB2.php : 111<br/>
-/Applic/models/News.php : 8<br/>
-/Applic/controllers/news.php : 15<br/>
-/system/library/Loader.php : 103<br/>
-/system/library/Loader.php : 59<br/>
-/Applic/bootstrap.php : 64<br/>
-/index.php : 22<br/>
</div></div><div class="ee">
Notice: Undefined index: id in <b>/Applic/controllers/news.php</b> on line <b>16</b><br/><div class="ei">
-/system/library/Loader.php : 59<br/>
-/Applic/bootstrap.php : 64<br/>
-/index.php : 22<br/>
</div></div><br/><br/>

<a name=""></a>#1666112478 /news/wp-includes/wlwmanifest.xml</pre><br/><br/>

<div class="ee">
Warning: PDOStatement::execute(): SQLSTATE[42S02]: Base table or view not found: 1146 Table 'tatartest_m.news' doesn't exist in <b>/system/library/DB2.php</b> on line <b>47</b><br/><div class="ei">
-/system/library/DB2.php : 111<br/>
-/Applic/models/News.php : 8<br/>
-/Applic/controllers/news.php : 15<br/>
-/system/library/Loader.php : 103<br/>
-/system/library/Loader.php : 59<br/>
-/Applic/bootstrap.php : 64<br/>
-/index.php : 22<br/>
</div></div><div class="ee">
Notice: Undefined index: id in <b>/Applic/controllers/news.php</b> on line <b>16</b><br/><div class="ei">
-/system/library/Loader.php : 59<br/>
-/Applic/bootstrap.php : 64<br/>
-/index.php : 22<br/>
</div></div>