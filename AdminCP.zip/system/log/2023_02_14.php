2023_02_14 Apache <br/>
<br/><br/>

<a name=""></a>#1676322151 /news</pre><br/><br/>

<div class="ee">
Warning: PDOStatement::execute(): SQLSTATE[42S02]: Base table or view not found: 1146 Table 'tatartest_m.news' doesn't exist in <b>/system/library/DB2.php</b> on line <b>47</b><br/><div class="ei">
-/system/library/DB2.php : 111<br/>
-/Applic/models/News.php : 8<br/>
-/Applic/controllers/news.php : 15<br/>
-/system/library/Loader.php : 103<br/>
-/system/library/Loader.php : 59<br/>
-/Applic/bootstrap.php : 64<br/>
-/index.php : 22<br/>
</div></div><div class="ee">
Notice: Undefined index: id in <b>/Applic/controllers/news.php</b> on line <b>16</b><br/><div class="ei">
-/system/library/Loader.php : 59<br/>
-/Applic/bootstrap.php : 64<br/>
-/index.php : 22<br/>
</div></div><br/><br/>

<a name=""></a>#1676361233 /news</pre><br/><br/>

<div class="ee">
Warning: PDOStatement::execute(): SQLSTATE[42S02]: Base table or view not found: 1146 Table 'tatartest_m.news' doesn't exist in <b>/system/library/DB2.php</b> on line <b>47</b><br/><div class="ei">
-/system/library/DB2.php : 111<br/>
-/Applic/models/News.php : 8<br/>
-/Applic/controllers/news.php : 15<br/>
-/system/library/Loader.php : 103<br/>
-/system/library/Loader.php : 59<br/>
-/Applic/bootstrap.php : 64<br/>
-/index.php : 22<br/>
</div></div><div class="ee">
Notice: Undefined index: id in <b>/Applic/controllers/news.php</b> on line <b>16</b><br/><div class="ei">
-/system/library/Loader.php : 59<br/>
-/Applic/bootstrap.php : 64<br/>
-/index.php : 22<br/>
</div></div>