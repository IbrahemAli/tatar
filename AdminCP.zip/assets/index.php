<?php
echo "<META HTTP-EQUIV=\"refresh\" CONTENT=\"0; URL=http://www.xtatar.com/index.php\">";
?>