<?php if(!class_exists('raintpl')){exit;}?><!DOCTYPE html>

<html lang="ar">

<head>

    <meta charset="UTF-8">

    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

</head>

<body>
<?php echo load_lang('ui/friends'); ?>

    <h1>
        <p>
		    <b><?php  echo LANGUI_F_T1;?></b>
		</p>
	</h1>
	<div id="textmenu">
	    <a href="friends"<?php if( ($selectedTabIndex == 0) ){ ?> class="selected" <?php } ?>><?php  echo LANGUI_F_T2;?></a> |
		<a href="friends?t=1"<?php if( ($selectedTabIndex == 1) ){ ?> class="selected" <?php } ?>><?php  echo LANGUI_F_T3;?></a> |
		<a href="friends?t=2"<?php if( ($selectedTabIndex == 2) ){ ?> class="selected" <?php } ?>><?php  echo LANGUI_F_T4;?></a>
	</div>
<?php if( ($selectedTabIndex == 0) ){ ?>

<table id="brought_in" cellpadding="3" cellspacing="1">
	<thead>
		<tr>
			<th colspan="4"><?php  echo LANGUI_F_T1;?></th>
		</tr>
		<tr>
			<td>#</td>
			<td><?php  echo LANGUI_F_T5;?></td>
			<td><?php  echo LANGUI_F_T6;?></td>
			<td><?php  echo LANGUI_F_T7;?></td>
		</tr>
	</thead>
	<?php $counter1=-1; if( isset($dataList) && is_array($dataList) && sizeof($dataList) ) foreach( $dataList as $key1 => $value1 ){ $counter1++; ?>

	<tr>
		<td>
			<center><?php echo $key1;?></center>
		</td>
		<td>
			<center><a href="profile?uid=<?php echo $value1["id"];?>"><?php echo $value1["usernam"];?></a></center>
		</td>
		<td>
			<center><?php echo $value1["date"];?></center>
		</td>
		<td>
			<center><a href="friends?delete=<?php echo $value1["id"];?>"><img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="del" title="<?php  echo text_delete_lang;?>" alt="<?php  echo text_delete_lang;?>"></a></center>
		</td>
	</tr>
	<?php } ?><?php if( (!$found) ){ ?>

	<tr>
		<td class="none" colspan="4">
			<center><?php  echo LANGUI_F_T8;?></center>
		</td>
	</tr>
	<?php } ?>

</table>
<table cellpadding="1" cellspacing="1" id="search_navi">
	<tbody>
		<tr>
			<td>
				<div class="navi"><?php echo $getPreviousLink;?>|<?php echo $getNextLink;?></div>
			</td>
		</tr>
	</tbody>
</table>
<?php }elseif( ($selectedTabIndex == 1) ){ ?>

<table id="brought_in" cellpadding="3" cellspacing="1">
	<thead>
		<tr>
			<th colspan="5"><?php  echo LANGUI_F_T3;?></th>
		</tr>
		<tr>
			<td>#</td>
			<td><?php  echo LANGUI_F_T5;?></td>
			<td><?php  echo LANGUI_F_T6;?></td>
			<td><?php  echo LANGUI_F_T9;?></td>
			<td><?php  echo LANGUI_F_T7;?></td>
		</tr>
	</thead>
	<?php $counter1=-1; if( isset($dataList) && is_array($dataList) && sizeof($dataList) ) foreach( $dataList as $key1 => $value1 ){ $counter1++; ?>

	<tr>
		<td>
			<center><?php echo $key1;?></center>
		</td>
		<td>
			<center><a href="profile?uid=<?php echo $value1["id"];?>"><?php echo $value1["usernam"];?></a></center>
		</td>
		<td>
			<center><?php echo $value1["date"];?></center>
		</td>
        <td>
			<center><a href="friends?t=1&from=<?php echo $value1["id"];?>"><?php  echo LANGUI_F_T9;?></a></center>
		</td>
		<td>
			<center><a href="friends?t=1&defrom=<?php echo $value1["id"];?>"><img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="del" title="<?php  echo text_delete_lang;?>" alt="<?php  echo text_delete_lang;?>"></a></center>
		</td>
	</tr>
	<?php } ?><?php if( (!$found) ){ ?>

	<tr>
		<td class="none" colspan="5">
			<center><?php  echo LANGUI_F_T8;?></center>
		</td>
	</tr>
	<?php } ?>

</table>
<table cellpadding="1" cellspacing="1" id="search_navi">
	<tbody>
		<tr>
			<td>
				<div class="navi"><?php echo $getPreviousLink;?>|<?php echo $getNextLink;?></div>
			</td>
		</tr>
	</tbody>
</table>
<?php }elseif( ($selectedTabIndex == 2) ){ ?>

<form action="friends?t=2" method="post">
    <table class="rate_details lang_rtl lang_ar" cellpadding="1" cellspacing="1">
        <thead>
            <tr>
		        <th colspan="3"><?php  echo LANGUI_F_T10;?></th>
            </tr>
        </thead>
        <tbody>
            <tr class="top">
		        <td><?php  echo LANGUI_F_T11;?></td>
		        <td><input class="text" type="text" name="name" maxlength="20" value=""></td>
                <td><p class="btn"><center>
                        <input type="image" value="" name="s1" id="btn_send" class="dynamic_img" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>">
                    </center>
                    </p>
                </td>
            </tr>
        </tbody>
    </table>
</form>
<?php if( ( isset($error) and $error != NULL ) ){ ?>

    <p class="error"><?php echo $error;?></p>
<?php } ?>

<table id="brought_in" cellpadding="3" cellspacing="1">
	<thead>
		<tr>
			<th colspan="4"><?php  echo LANGUI_F_T12;?></th>
		</tr>
		<tr>
			<td>#</td>
			<td><?php  echo LANGUI_F_T5;?></td>
			<td><?php  echo LANGUI_F_T6;?></td>
			<td><?php  echo LANGUI_F_T7;?></td>
		</tr>
	</thead>
	<?php $counter1=-1; if( isset($dataList) && is_array($dataList) && sizeof($dataList) ) foreach( $dataList as $key1 => $value1 ){ $counter1++; ?>

	<tr>
		<td>
			<center><?php echo $key1;?></center>
		</td>
		<td>
			<center><a href="profile?uid=<?php echo $value1["id"];?>"><?php echo $value1["usernam"];?></a></center>
		</td>
		<td>
			<center><?php echo $value1["date"];?></center>
		</td>
		<td>
			<center><a href="friends?t=2&deto=<?php echo $value1["id"];?>"><img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="del" title="<?php  echo text_delete_lang;?>" alt="<?php  echo text_delete_lang;?>"></a></center>
		</td>
	</tr>
	<?php } ?><?php if( (!$found) ){ ?>

	<tr>
		<td class="none" colspan="4">
			<center><?php  echo LANGUI_F_T12;?></center>
		</td>
	</tr>
	<?php } ?>

</table>
<table cellpadding="1" cellspacing="1" id="search_navi">
	<tbody>
		<tr>
			<td>
				<div class="navi"><?php echo $getPreviousLink;?>|<?php echo $getNextLink;?></div>
			</td>
		</tr>
	</tbody>
</table>
<?php } ?>

</body>
</html>