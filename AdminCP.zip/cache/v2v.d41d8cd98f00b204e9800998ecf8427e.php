<?php if(!class_exists('raintpl')){exit;}?><!DOCTYPE html>

<html lang="ar">

<head>

    <meta charset="UTF-8">

    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

</head>

<body>
<?php echo load_lang('ui/v2v'); ?>


<?php if( ( $pageState == 1 ) ){ ?>

    <h1><?php  echo LANGUI_V2V_T1;?></h1>
    <form method="post" name="snd" action="v2v">
        <table id="troops" cellpadding="1" cellspacing="1">
            <tbody>
                <tr>
                    <td class="line-first column-first">
                        <img class="unit u<?php echo $troops["0"]["troopId"];?>" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" title="<?php echo constant('troop_'.$troops["0"]["troopId"] ); ?>" alt="<?php echo constant('troop_'.$troops["0"]["troopId"] ); ?>" <?php if( ( 0 < $troops["0"]['number'] ) ){ ?> onclick="_('t1').value=''; return false;" <?php } ?>>
                        <input type="text" class="text <?php if( ( $troops["0"]['number'] <= 0 ) ){ ?>disabled<?php } ?>" name="t[<?php echo $troops["0"]["troopId"];?>]" id="t1" value="" maxlength="9">
                        <?php if( ( $troops["0"]['number'] <= 0 ) ){ ?>

                            <span class="none">(0)</span>
                        <?php }else{ ?>

                    	    <a href="#" onclick="_('t1').value=<?php echo $troops["0"]["number"];?>; return false;">(<?php echo $troops["0"]["number"];?>)</a>
                        <?php } ?>

	               </td>
                   <td class="line-first">
                    <img class="unit u<?php echo $troops["3"]["troopId"];?>" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" title="<?php echo constant('troop_'.$troops["3"]["troopId"] ); ?>" alt="<?php echo constant('troop_'.$troops["3"]["troopId"] ); ?>" <?php if( ( 0 < $troops["3"]['number'] ) ){ ?> onclick="_('t4').value=''; return false;"<?php } ?> >
                    <input type="text" class="text  <?php if( ( $troops["3"]['number'] <= 0 ) ){ ?> disabled <?php } ?>" name="t[<?php echo $troops["3"]["troopId"];?>]" id="t4" value="" maxlength="9">
                    <?php if( ( $troops["3"]['number'] <= 0 ) ){ ?>

                        <span class="none">(0)</span>
                    <?php }else{ ?>

                        <a href="#" onclick="_('t4').value=<?php echo $troops["3"]["number"];?>; return false;">(<?php echo $troops["3"]["number"];?>)</a>
                    <?php } ?>

                  </td>
                  <td class="line-first">
                    <img class="unit u<?php echo $troops["6"]["troopId"];?>" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" title="<?php echo constant('troop_'.$troops["6"]['troopId'] ); ?>" alt="<?php echo constant('troop_'.$troops["6"]['troopId'] ); ?>"<?php if( ( 0 < $troops["6"]['number'] ) ){ ?>onclick="_('t7').value=''; return false;"<?php } ?>>
                    <input type="text" class="text <?php if( ( $troops["6"]['number'] <= 0 ) ){ ?>disabled<?php } ?>" name="t[<?php echo $troops["6"]["troopId"];?>]" id="t7" value="" maxlength="9">
                    <?php if( ( $troops["6"]['number'] <= 0 ) ){ ?>

                        <span class="none">(0)</span>
                    <?php }else{ ?>

                        <a href="#" onclick="_('t7').value=<?php echo $troops["6"]["number"];?>; return false;">(<?php echo $troops["6"]["number"];?>)</a><?php } ?>

                    </td>
                    <td class="line-first column-last">
                        <img class="unit u<?php echo $troops["8"]["troopId"];?>" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" title="<?php echo constant('troop_'.$troops["8"]['troopId'] ); ?>" alt="<?php echo constant('troop_'.$troops["8"]['troopId'] ); ?>"<?php if( ( 0 < $troops["8"]['number'] ) ){ ?>onclick="_('t9').value=''; return false;"<?php } ?>>
                        <input type="text" class="text <?php if( ( $troops["8"]['number'] <= 0 ) ){ ?>disabled<?php } ?>" name="t[<?php echo $troops["8"]["troopId"];?>]" id="t9" value="" maxlength="9">
                   <?php if( ( $troops["8"]['number'] <= 0 ) ){ ?>

                        <span class="none">(0)</span>
                    <?php }else{ ?>

                        <a href="#" onclick="_('t9').value=<?php echo $troops["8"]["number"];?>; return false;">(<?php echo $troops["8"]["number"];?>)</a>
                    <?php } ?>

                    </td>
                </tr>
                <tr>
                    <td class="column-first">
                        <img class="unit u<?php echo $troops["1"]["troopId"];?>" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" title="<?php echo constant('troop_'.$troops["1"]['troopId'] ); ?>" alt="<?php echo constant('troop_'.$troops["1"]['troopId'] ); ?>" <?php if( ( 0 < $troops["1"]['number'] ) ){ ?>onclick="_('t2').value=''; return false;"<?php } ?>>
                        <input type="text" class="text <?php if( ( $troops["1"]['number'] <= 0 ) ){ ?>disabled<?php } ?>" name="t[<?php echo $troops["1"]["troopId"];?>]" id="t2" value="" maxlength="9">
                    <?php if( ( $troops["1"]['number'] <= 0 ) ){ ?>

                        <span class="none">(0)</span>
                    <?php }else{ ?>

                        <a href="#" onclick="_('t2').value=<?php echo $troops["1"]["number"];?>; return false;">(<?php echo $troops["1"]["number"];?>)</a>
                    <?php } ?>

                    </td>
                    <td>
                        <img class="unit u<?php echo $troops["4"]["troopId"];?>" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" title="<?php echo constant('troop_'.$troops["4"]['troopId'] ); ?>" alt="<?php echo constant('troop_'.$troops["4"]['troopId'] ); ?>" <?php if( ( 0 < $troops["4"]['number'] ) ){ ?> onclick="_('t5').value=''; return false;"<?php } ?>>
                        <input type="text" class="text <?php if( ( $troops["4"]['number'] <= 0 ) ){ ?> disabled <?php } ?>" name="t[<?php echo $troops["4"]["troopId"];?>]" id="t5" value="" maxlength="9">
                        <?php if( ( $troops["4"]['number'] <= 0 ) ){ ?>

                            <span class="none">(0)</span>
                        <?php }else{ ?>

                            <a href="#" onclick="_('t5').value=<?php echo $troops["4"]["number"];?>; return false;">(<?php echo $troops["4"]["number"];?>)</a>
                        <?php } ?>

                    </td>
                    <td>
                        <img class="unit u<?php echo $troops["7"]["troopId"];?>" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" title="<?php echo constant('troop_'.$troops["7"]['troopId'] ); ?>" alt="<?php echo constant('troop_'.$troops["7"]['troopId'] ); ?>" <?php if( ( 0 < $troops["7"]['number'] ) ){ ?>onclick="_('t8').value=''; return false;"<?php } ?>>
                        <input type="text" class="text <?php if( ( $troops["7"]['number'] <= 0 ) ){ ?>disabled<?php } ?>" name="t[<?php echo $troops["7"]["troopId"];?>]" id="t8" value="" maxlength="9">
                        <?php if( ( $troops["7"]['number'] <= 0 ) ){ ?>

                            <span class="none">(0)</span>
                        <?php }else{ ?>

                            <a href="#" onclick="_('t8').value=<?php echo $troops["7"]["number"];?>; return false;">(<?php echo $troops["7"]["number"];?>)</a>
                        <?php } ?>

                    </td>
                    <td class="column-last">
                        <img class="unit u<?php echo $troops["9"]["troopId"];?>" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" title="<?php echo constant('troop_'.$troops["9"]['troopId'] ); ?>" alt="<?php echo constant('troop_'.$troops["9"]['troopId'] ); ?>" <?php if( ( 0 < $troops["9"]['number'] ) ){ ?> onclick="_('t10').value=''; return false;"<?php } ?>>
                        <input type="text" class="text <?php if( ( $troops["9"]['number'] <= 0 ) ){ ?>disabled<?php } ?>" name="t[<?php echo $troops["9"]["troopId"];?>]" id="t10" value="" maxlength="9">
                        <?php if( ( $troops["9"]['number'] <= 0 ) ){ ?>

                            <span class="none">(0)</span>
                        <?php }else{ ?>

                            <a href="#" onclick="_('t10').value=<?php echo $troops["9"]["number"];?>; return false;">(<?php echo $troops["9"]["number"];?>)</a>
                        <?php } ?>

                    </td>
                </tr>
                <tr>
                    <td class="line-last column-first">
                        <img class="unit u<?php echo $troops["2"]["troopId"];?>" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" title="<?php echo constant('troop_'.$troops["2"]['troopId'] ); ?>" alt="<?php echo constant('troop_'.$troops["2"]['troopId'] ); ?>" <?php if( ( 0 < $troops["2"]['number'] ) ){ ?> onclick="_('t3').value=''; return false;"<?php } ?>>
                        <input type="text" class="text <?php if( ( $troops["2"]['number'] <= 0 ) ){ ?>disabled<?php } ?>" name="t[<?php echo $troops["2"]["troopId"];?>]" id="t3" value="" maxlength="9">
                        <?php if( ( $troops["2"]['number'] <= 0 ) ){ ?>

                            <span class="none">(0)</span>
                        <?php }else{ ?>

                            <a href="#" onclick="_('t3').value=<?php echo $troops["2"]["number"];?>; return false;">(<?php echo $troops["2"]["number"];?>)</a>
                        <?php } ?>

                    </td>
                    <td class="line-last">
                        <img class="unit u<?php echo $troops["5"]["troopId"];?>" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" title="<?php echo constant('troop_'.$troops["5"]['troopId'] ); ?>" alt="<?php echo constant('troop_'.$troops["5"]['troopId'] ); ?>" <?php if( ( 0 < $troops["5"]['number'] ) ){ ?> onclick="_('t6').value=''; return false;"<?php } ?> >
                        <input type="text" class="text <?php if( ( $troops["5"]['number'] <= 0 ) ){ ?>disabled<?php } ?>" name="t[<?php echo $troops["5"]["troopId"];?>]" id="t6" value="" maxlength="9">
                        <?php if( ( $troops["5"]["number"] <= 0 ) ){ ?>

                            <span class="none">(0)</span>
                        <?php }else{ ?>

                            <a href="#" onclick="_('t6').value=<?php echo $troops["5"]["number"];?>; return false;">(<?php echo $troops["5"]["number"];?>)</a>
                        <?php } ?>

                    </td>
                    <td class="line-last"></td>
                    <td class="line-last column-last">
                        <?php if( ( $hasHero ) ){ ?>

                            <img class="unit uhero" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" title="<?php  echo troop_hero;?>" onclick="_('_t').value=''; return false;" alt="<?php  echo troop_hero;?>">
                            <input type="text" class="text" id="_t" name="_t" value="" maxlength="1">
                            <a href="#" onclick="_('_t').value=1; return false;">(1)</a>
                        <?php } ?>

                    </td>
                </tr>
            </tbody>
        </table>
        <table id="coords" cellpadding="1" cellspacing="1">
            <tbody>
                <tr>
                    <td class="sel">
                        <label>
                            <input type="radio" class="radio" name="c" value="2" <?php if( ( $disableFirstTwoAttack ) ){ ?> disabled="disabled" <?php }elseif( ( $transferType == 2 ) ){ ?> checked="" <?php } ?> >
                            <?php  echo LANGUI_V2V_T2;?>

                        </label>
                    </td>
                    <td class="vil">
                        <span><?php  echo LANGUI_V2V_T3;?></span>
                        <input type="text" class="text" name="dname" value="" maxlength="20">
                    </td>
                </tr>
                <tr>
                    <td class="sel">
                        <label>
                            <input type="radio" class="radio" name="c" value="3" <?php if( ( $disableFirstTwoAttack ) ){ ?>disabled="disabled"<?php }elseif( ( $transferType == 3 ) ){ ?>checked=""<?php } ?>>
                            <?php  echo LANGUI_V2V_T4;?>

                        </label>
                    </td>
                    <td class="or"><?php  echo text_or_lang;?></td>
                </tr>
                <tr>
                    <td class="sel">
                        <label>
                            <input type="radio" class="radio" name="c" value="4" <?php if( ( $disableFirstTwoAttack ) ){ ?> checked=""<?php }elseif( ( $transferType == 4 ) ){ ?> checked="" <?php } ?>>
                            <?php  echo LANGUI_V2V_T5;?>

                        </label>
                    </td>
                    <td class="target">
                        <span>X:</span>
                        <input type="text" class="text" name="x" value="<?php if( ( $targetVillage['x'] !== NULL ) ){ ?><?php echo $targetVillage["x"];?><?php } ?>" maxlength="4">
                        <span>Y:</span>
                        <input type="text" class="text" name="y" value="<?php if( ( $targetVillage['y'] !== NULL ) ){ ?><?php echo $targetVillage["y"];?><?php } ?>" maxlength="4">
                    </td>
                </tr>
            </tbody>
        </table>
        <input type="image" value="ok" name="s1" id="btn_ok" class="dynamic_img" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo text_okdone_lang;?>">
    </form>
    <?php if( ( $errorTable != NULL ) ){ ?>

        <p class="error">
        <?php echo $errorTable;?>

        </p>
    <?php } ?>


<?php }elseif( ( $pageState == 2 ) ){ ?>


    <?php $text = rand(1,50);?>

    <?php $vercod = $_SESSION["vercode"] = $text;?>


    <h1><p><?php echo $targetVillage["transferType"];?></p></h1>
    <form method="post" name="snd" action="v2v">
        <table id="short_info" cellpadding="1" cellspacing="1">
            <tbody>
                <tr>
                    <th><?php  echo LANGUI_V2V_T6;?>:</th>
                    <td>
                        <a href="village3?id=<?php echo $targetVillage["villageId"];?>"><?php echo $targetVillage["villageName"];?></a>
                    </td>
                </tr>
                <?php if( ( trim( $targetVillage['playerName'] ) != '' ) ){ ?>

                    <tr>
                        <th><?php  echo LANGUI_V2V_T7;?>:</th>
                        <td>
                            <?php if( ( $targetVillage['playerId'] == 0 ) ){ ?>

                                <?php echo $targetVillage["playerName"];?>

                            <?php }else{ ?>

                                <a href="profile?uid=<?php echo $targetVillage["playerId"];?>"><?php echo $targetVillage["playerName"];?></a>
                            <?php } ?>

                        </td>
                    </tr>
                <?php } ?>

            </tbody>
        </table>
        <table class="troop_details" cellpadding="1" cellspacing="1">
            <thead>
                <tr>
                    <td><?php echo $data["village_name"];?></td>
                    <td colspan="11">
                        <p class="custDir"><?php echo $targetVillage["transferType"];?> <?php echo $targetVillage["playerName"];?></p>
                    </td>
                </tr>
            </thead>
            <tbody class="units">
                <tr>
                    <td></td>
                    <?php $counter1=-1; if( isset($targetVillage['troops']) && is_array($targetVillage['troops']) && sizeof($targetVillage['troops']) ) foreach( $targetVillage['troops'] as $key1 => $value1 ){ $counter1++; ?>

                    <td>
                        <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="unit u<?php echo $key1;?>" title="<?php echo constant('troop_'.$key1 ); ?>" alt="<?php echo constant('troop_'.$key1 ); ?>">
                    </td>
                    <?php } ?>


                    <?php if( ( $targetVillage['hasHero'] ) ){ ?>

                        <td>
                            <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="unit uhero" title="<?php  echo troop_hero;?>" alt="<?php  echo troop_hero;?>">
                        </td>
                    <?php } ?>

                </tr>
                <tr>
                    <th><?php  echo LANGUI_V2V_T8;?></th>
                    <?php $counter1=-1; if( isset($targetVillage['troops']) && is_array($targetVillage['troops']) && sizeof($targetVillage['troops']) ) foreach( $targetVillage['troops'] as $key1 => $value1 ){ $counter1++; ?>

                        <?php if( ( $value1 <= 0 ) ){ ?>

                            <td class="none">0</td>
                        <?php }else{ ?>

                            <td><?php echo $value1;?></td>
                        <?php } ?>


                    <?php } ?>


                    <?php if( ( $targetVillage['hasHero'] ) ){ ?>

                        <td>1</td>
                    <?php } ?>

                </tr>
            </tbody>
            <?php if( $transferType == 1 ){ ?>


            <tbody class="options">
                <tr>
                    <th><?php  echo LANGUI_V2V_T9;?></th>
                    <td colspan="11">
                        <img class="r1" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo item_title_1;?>" title="<?php  echo item_title_1;?>">
                            <?php echo $newVillageResources["1"];?> |
                        <img class="r2" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo item_title_2;?>" title="<?php  echo item_title_2;?>">
                            <?php echo $newVillageResources["2"];?> |
                        <img class="r3" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo item_title_3;?>" title="<?php  echo item_title_3;?>">
                            <?php echo $newVillageResources["3"];?> |
                        <img class="r4" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo item_title_4;?>" title="<?php  echo item_title_4;?>">
                            <?php echo $newVillageResources["4"];?>

                    </td>
                </tr>
            </tbody>
            <?php }elseif( $targetVillage['spy'] ){ ?>

            <tbody class="options">
                <tr>
                    <th><?php  echo LANGUI_V2V_T10;?></th>
                    <td colspan="11">
                        <input class="radio" type="radio" name="spy" value="1" checked="">
                        <?php  echo LANGUI_V2V_T11;?>

                        <br />
                        <?php if( ( !$onlyOneSpyAction ) ){ ?>

                            <input class="radio" type="radio" name="spy" value="2">
                            <?php  echo LANGUI_V2V_T12;?>

                        <?php } ?>

                        </td>
                    </tr>
                </tbody>
            <?php }elseif( $attackWithCatapult ){ ?>

                <tbody class="options">
                    <tr>
                        <th><?php  echo LANGUI_V2V_T6;?></th>
                        <td colspan="11">
                            <select name="dtg" class="dropdown">
                                <option value="99"><?php  echo LANGUI_V2V_T13;?></option>
                                    <?php echo $availableCatapultTargetsString;?>

                            </select>
                            <span class="info">(<?php  echo LANGUI_V2V_T14;?>)</span>
                        </td>
                    </tr>
                </tbody>
                <?php if( ( $rallyPointLevel == 20 && 2000 <= $totalCatapultTroopsCount ) ){ ?>

                    <tbody class="options">
                        <tr>
                            <th><?php  echo LANGUI_V2V_T15;?></th>
                            <td colspan="11">
                                <select name="dtg1" class="dropdown">
                                    <option value="99"><?php  echo LANGUI_V2V_T13;?></option>
                                    <?php echo $availableCatapultTargetsString;?>

                                </select>
                                <span class="info">(<?php  echo LANGUI_V2V_T14;?>)</span>
                            </td>
                        </tr>
                    </tbody>
                <?php } ?>

            <?php } ?>

            <tbody class="infos">
                <tr>
                    <th><?php  echo LANGUI_V2V_T16;?></th>
                    <td colspan="11">
                        <?php  echo text_in_lang;?>

                        <?php echo secondstostring( $targetVillage["needed_time"] );?>

                        <?php  echo LANGUI_V2V_T17;?>

                    </td>
                </tr>
            </tbody>
        </table>
        <input type="hidden" name="id" value="<?php echo $targetVillage["villageId"];?>">
        <input type="hidden" name="c" value="<?php if( is_post('c') ){ ?><?php echo post('c'); ?><?php }else{ ?>4<?php } ?>">

        <?php $counter1=-1; if( isset($targetVillage['troops']) && is_array($targetVillage['troops']) && sizeof($targetVillage['troops']) ) foreach( $targetVillage['troops'] as $key1 => $value1 ){ $counter1++; ?>

            <input type="hidden" name="t[<?php echo $key1;?>]" value="<?php echo $value1;?>">
        <?php } ?>

        <?php if( ( $targetVillage['hasHero'] ) ){ ?>

            <input type="hidden" name="_t" value="1">
        <?php } ?>


    <input name="captcha"  type="hidden" value="<?php echo $vercod;?>" />
    <p class="btn">
    <input type="image" value="ok" name="s1" id="btn_ok" class="dynamic_img" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo text_okdone_lang;?>" onclick="if (this.disabled==false) {document.getElementsByTagName('form')[0].submit();} this.disabled=true;" onLoad="this.disabled=false;">
    </p>
    </form>


<?php }elseif( ( $pageState == 3 ) ){ ?>


    <?php $text = rand(1,50);?>

    <?php $vercod = $_SESSION["vercode"] = $text;?>

    <?php $colspan = $backTroopsProperty['backTroops']['hasHero'] ? 11 : 10;?>


    <h1><?php echo $backTroopsProperty["headerText"];?></h1>
    <form method="POST" id="v2v" action="v2v?<?php echo $backTroopsProperty["queryString"];?>">
        <table class="troop_details" cellpadding="1" cellspacing="1">
            <thead>
                <tr>
                    <td lass="role"><?php echo $backTroopsProperty["action1"];?></td>
                    <td colspan="<?php echo $colspan;?>"><?php echo $backTroopsProperty["action2"];?></td>
                </tr>
            </thead>
            <tbody class="units">
                <tr>
                    <th>&nbsp;</th>
                    <?php $counter1=-1; if( isset($backTroopsProperty['backTroops']['troops']) && is_array($backTroopsProperty['backTroops']['troops']) && sizeof($backTroopsProperty['backTroops']['troops']) ) foreach( $backTroopsProperty['backTroops']['troops'] as $key1 => $value1 ){ $counter1++; ?>

                    <td>
                        <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="unit u<?php echo $key1;?>" title="<?php echo constant('troop_'.$key1 ); ?>" alt="<?php echo constant('troop_'.$key1 ); ?>">
                    </td>
                    <?php } ?>


                    <?php if( ( $backTroopsProperty['backTroops']['hasHero'] ) ){ ?>

                        <td>
                            <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="unit uhero" title="<?php  echo troop_hero;?>" alt="<?php  echo troop_hero;?>">
                        </td>
                    <?php } ?>

                </tr>
                <tr>
                    <th><?php  echo LANGUI_V2V_T8;?></th>
                    <?php $counter1=-1; if( isset($backTroopsProperty['backTroops']['troops']) && is_array($backTroopsProperty['backTroops']['troops']) && sizeof($backTroopsProperty['backTroops']['troops']) ) foreach( $backTroopsProperty['backTroops']['troops'] as $key1 => $value1 ){ $counter1++; ?>

                        <?php if( ( $value1 <= 0 ) ){ ?>

                            <td class="none">0</td>
                        <?php }else{ ?>

                            <td>
                                <input type="text" name="t[<?php echo $key1;?>]" class="text" value="<?php echo $value1;?>" maxlength="9">
                            </td>
                        <?php } ?>

                    <?php } ?>


                    <?php if( ( $backTroopsProperty['backTroops']['hasHero'] ) ){ ?>

                        <td><input type="text" name="_t" class="text" value="1" maxlength="9"></td>
                    <?php } ?>

                </tr>
            </tbody>
            <tbody class="infos">
                <tr>
                    <th><?php  echo LANGUI_V2V_T16;?></th>
                    <td colspan="<?php echo $colspan;?>">
                        <div class="in"> <?php  echo LANGUI_V2V_T18;?> <?php echo secondstostring( $backTroopsProperty["time"] );?>


                        <?php $arrival_in = !isset($targetVillage['needed_time']) ? date('G:i:s',time()) : date('G:i:s',time()+$targetVillage['needed_time']) ;?>

                          <span id="timer2"> <?php echo $arrival_in;?> </span>
                        <?php  echo LANGUI_V2V_T17;?>

                        </div>
                    </td>
                    </tr>
                    </tbody>
                    </table>
                <input name="captcha"  type="hidden" value="<?php echo $vercod;?>" />
                <p class="btn">
                    <input type="image" value="ok" name="s1" id="btn_ok" class="dynamic_img" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo text_okdone_lang;?>">
                </p>
            </form>
    <?php } ?>

</body>
</html>