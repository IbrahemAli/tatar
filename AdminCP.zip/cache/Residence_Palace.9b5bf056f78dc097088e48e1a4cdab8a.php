<?php if(!class_exists('raintpl')){exit;}?><!DOCTYPE html>

<html lang="ar">

<head>

    <meta charset="UTF-8">

    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

</head>

<body>
<?php echo load_lang('ui/custbuilds'); ?>

<div id="textmenu">
  <a href="build?id=<?php echo $buildingIndex;?>" <?php if( ($selectedTabIndex == 0) ){ ?> class="selected" <?php } ?>>
      <?php  echo LANGUI_CUSTBU_RPLC_p1;?>

  </a>
  |
  <a href="build?id=<?php echo $buildingIndex;?>&t=1" <?php if( ($selectedTabIndex == 1) ){ ?> class="selected" <?php } ?>>
      <?php  echo LANGUI_CUSTBU_RPLC_p2;?>

  </a>
  |
  <a href="build?id=<?php echo $buildingIndex;?>&t=2" <?php if( ($selectedTabIndex == 2) ){ ?> class="selected" <?php } ?>>
      <?php  echo LANGUI_CUSTBU_RPLC_p3;?>

  </a>
  |
  <a href="build?id=<?php echo $buildingIndex;?>&t=3" <?php if( ($selectedTabIndex == 3) ){ ?> class="selected" <?php } ?>>
  <?php  echo LANGUI_CUSTBU_RPLC_p4;?>

  </a>
</div>

<?php if( ($selectedTabIndex == 0) ){ ?>

    <?php if( ($showBuildingForm) ){ ?>

<form method="post" name="snd" action="build?id=<?php echo $buildingIndex;?>">
  <table cellpadding="1" cellspacing="1" class="build_details">
    <thead>
      <tr>
        <td><?php  echo LANGUI_CUSTBU_RPLC_p1_t1;?></td>
        <td><?php  echo LANGUI_CUSTBU_RPLC_p1_t2;?></td>
        <td><?php  echo LANGUI_CUSTBU_RPLC_p1_t3;?></td>
      </tr>
    </thead>
    <tbody>

      <?php $counter1=-1; if( isset($troopsUpgrade) && is_array($troopsUpgrade) && sizeof($troopsUpgrade) ) foreach( $troopsUpgrade as $key1 => $value1 ){ $counter1++; ?>

      <tr>
        <td class="desc">
          <div class="tit">
            <img class="unit u<?php echo $value1["tid"];?>" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php echo constant('troop_' . $value1["tid"]); ?>" title="<?php echo constant('troop_' . $value1["tid"]); ?>">
            <a href="#" onclick="return showManual(3,<?php echo $value1["tid"];?>);"><?php echo constant('troop_' . $value1["tid"]); ?></a>
            <span class="info">
              ( <?php  echo LANGUI_CUSTBU_RPLC_p1_t4;?> : <?php echo $value1["troop"];?> )
            </span>
          </div>
          <div class="details">
            <img class="r1" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo item_title_1;?>" title="<?php  echo item_title_1;?>">
            <span class="little_res">
              <?php echo $value1["training_resources_1"];?>

            </span>
            |
            <img class="r2" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo item_title_2;?>" title="<?php  echo item_title_2;?>">
            <span class="little_res">
              <?php echo $value1["training_resources_2"];?>

            </span>
            |
            <img class="r3" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo item_title_3;?>" title="<?php  echo item_title_3;?>">
            <span class="little_res">
              <?php echo $value1["training_resources_3"];?>

            </span>
            |
            <img class="r4" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo item_title_4;?>" title="<?php  echo item_title_4;?>">
            <span class="little_res">
              <?php echo $value1["training_resources_4"];?>

            </span>
            |
            <img class="clock" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo text_period_lang;?>" title="<?php  echo text_period_lang;?>">
              <?php echo secondstostring( $value1["lvlTime"] );?>

              <?php echo $value1["getResourceGoldExchange"];?>

          </div>
        </td>
        <td class="val">
          <input type="text" class="text" id="_tf<?php echo $value1["tid"];?>" name="tf[<?php echo $value1["tid"];?>]" value="0" maxlength="4"></td>
        <td class="max">
          <a href="#" onclick="_('_tf<?php echo $value1["tid"];?>').value=<?php echo $value1["maxNumber"];?>; return false;">
            ( <?php echo $value1["maxNumber"];?> )
          </a>
        </td>
      </tr>
      <?php } ?>

    </tbody>
  </table>
  <p>
    <input type="image" id="btn_train" class="dynamic_img" value="ok" name="s1" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo LANGUI_CUSTBU_RPLC_p1_t5;?>">
  </p>
</form>
<?php }else{ ?>

  <?php if( (3 <= $childVillagesCount && $data['is_capital'] || 2 <= $childVillagesCount && !$data['is_capital']) ){ ?>

    <div class="c">
      <?php  echo LANGUI_CUSTBU_RPLC_p1_t6;?> .
    </div>
    <?php }elseif( ($childVillagesCount == 1) ){ ?>


        <?php if( $check_build_exists ){ ?>

          <div class="c">
            <?php  echo LANGUI_CUSTBU_RPLC_p1_t7;?>

            <?php if( $data['is_capital'] ){ ?>15<?php }else{ ?>20<?php } ?> .
          </div>
          <?php }else{ ?>

          <div class="c">
            <?php  echo LANGUI_CUSTBU_RPLC_p1_t8;?> .
          </div>
          <?php } ?>

        <?php }else{ ?>


        <?php if( ($childVillagesCount == 2 && $data['is_capital']) ){ ?>

          <?php if( ($building_level_20) ){ ?>

        <div class="c">
          <?php  echo LANGUI_CUSTBU_RPLC_p1_t7;?> 20.
        </div>
        <?php }else{ ?>

        <div class="c">
          <?php  echo LANGUI_CUSTBU_RPLC_p1_t8;?> .
        </div>
        <?php } ?>

        <?php }else{ ?>

        <?php if( ($building_level_10) ){ ?>

        <div class="c">
          <?php  echo LANGUI_CUSTBU_RPLC_p1_t9;?> .
        </div>
        <?php }else{ ?>

        <div class="c">
          <?php  echo LANGUI_CUSTBU_RPLC_p1_t8;?> .
        </div>
        <?php } ?>

      <?php } ?>

    <?php } ?>

  <?php } ?>


    <?php if( $tasksInQueue_building_upgrade ){ ?>

    <table cellpadding="1" cellspacing="1" class="under_progress">
      <?php if( (!$data['is_special_village'] && $gameMetadata['plusTable'][7]['cost'] <= $data['gold_num']) ){ ?>

        <thead>
          <tr>
            <th colspan="2">
              <?php $costTip = sprintf(LANGUI_CUSTBU_TRP_t15, $gameMetadata['plusTable'][7]['cost']);?>

              <?php  echo LANGUI_CUSTBU_TRP_t16;?> :
              <a href="?id=<?php echo $_GET['id'];?>&bfs=7&k=<?php echo $data["update_key"];?>" title="<?php echo $costTip;?>">
                <img class="clock" alt="<?php echo $costTip;?>" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>"></a>
            </th>
          </tr>
        </thead>
        <?php } ?>

        <thead>
          <tr>
            <td><?php  echo LANGUI_CUSTBU_RPLC_p1_t10;?></td>
            <td><?php  echo text_period_lang;?></td>
          </tr>
        </thead>
        <tbody>
          <?php $counter1=-1; if( isset($qts) && is_array($qts) && sizeof($qts) ) foreach( $qts as $key1 => $value1 ){ $counter1++; ?>

          <tr>
            <td class="desc">
              <img class="unit u<?php echo $value1["tid"];?>" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php echo constant('troop_' . $value1["tid"]); ?>" title="<?php echo constant('troop_' . $value1["tid"]); ?>">
              <?php echo $value1["threads"];?>

              <?php echo constant('troop_' . $value1["tid"]); ?>

            </td>
            <td class="dur">
              <span id="timer1"><?php echo $value1["remainingSeconds"];?></span>
            </td>
          </tr>
          <?php } ?>

          <tr class="next">
            <td colspan="2">
              <?php  echo LANGUI_CUSTBU_RPLC_p1_t11;?>

              <span id="timer1"><?php echo secondstostring( $nextTroopTime );?></span>
            </td>
          </tr>
        </tbody>
    </table>
    <?php } ?>


      <?php if( $if_building_id_26 ){ ?>

          <?php if( ($VillageData['is_capital']) ){ ?>

          <p class="none"><?php  echo LANGUI_CUSTBU_RPLC_p1_t12;?></p>
          <?php }elseif( (!$data['is_special_village']) ){ ?>

          <p>
            <a href="build?id=<?php echo $buildingIndex;?>&mc">
              <?php  echo LANGUI_CUSTBU_RPLC_p1_t13;?>

            </a>
          </p>
          <?php } ?>

      <?php } ?>

      <?php }elseif( ($selectedTabIndex == 1) ){ ?>

          <p>
            <p>
              <?php  echo LANGUI_CUSTBU_RPLC_p2_t1;?> .
            </p>
          </p>
          <table cellpadding="1" cellspacing="1" id="build_value">
            <tr>
              <th>
                <?php  echo LANGUI_CUSTBU_RPLC_p2_t2;?> :
              </th>
              <td> <b><?php echo $cpRate;?></b>
                <?php  echo LANGUI_CUSTBU_RPLC_p2_t3;?>

              </td>
            </tr>
            <tr>
              <th>
                <?php  echo LANGUI_CUSTBU_RPLC_p2_t4;?> :
              </th>
              <td> <b><?php echo $totalCpRate;?></b>
                <?php  echo LANGUI_CUSTBU_RPLC_p2_t3;?>

              </td>
            </tr>
          </table>
          <p>
            <p>
              <?php  echo LANGUI_CUSTBU_RPLC_p2_t5;?>

              <b><?php echo $totalCpValue;?></b>
              <?php  echo LANGUI_CUSTBU_RPLC_p2_t6;?> .
              <br/>
              <?php  echo LANGUI_CUSTBU_RPLC_p2_t7;?>

              <b><?php echo $neededCpValue;?></b>
              <?php  echo LANGUI_CUSTBU_RPLC_p2_t8;?> .
            </p>
          </p>
          <br/>
          <?php }elseif( ($selectedTabIndex == 2) ){ ?>

          <p>
            <?php  echo LANGUI_CUSTBU_RPLC_p3_t1;?> .
            <br/>
            <br/>
            <?php  echo LANGUI_CUSTBU_RPLC_p3_t2;?>

            <b><?php echo $data["allegiance_percent"];?></b>
            %.
          </p>
          <br/>
          <?php }elseif( ($selectedTabIndex == 3) ){ ?>

          <table cellpadding="1" cellspacing="1" id="expansion">
            <thead>
              <tr>
                <th colspan="4">
                  <a name="h2"></a>
                  <?php  echo LANGUI_CUSTBU_RPLC_p4_t1;?>

                </th>
              </tr>
              <tr>
                <td><?php  echo LANGUI_CUSTBU_RPLC_p4_t2;?></td>
                <td><?php  echo LANGUI_CUSTBU_RPLC_p4_t3;?></td>
                <td><?php  echo LANGUI_CUSTBU_RPLC_p4_t4;?></td>
                <td><?php  echo LANGUI_CUSTBU_RPLC_p4_t5;?></td>
              </tr>
            </thead>
            <tbody>
              <?php $counter1=-1; if( isset($childVillages) && is_array($childVillages) && sizeof($childVillages) ) foreach( $childVillages as $key1 => $value1 ){ $counter1++; ?>

              <tr>
                <td class="nam">
                  <a href="village3?id=<?php echo $value1["id"];?>"><?php echo $value1["village_name"];?></a>
                </td>
                <td class="zp"><?php echo $value1["people_count"];?></td>
                <td class="aligned_coords">
                  <div class="cox">
                    ( <?php echo $value1["rel_x"];?>

                  </div>
                  <div class="pi">|</div>
                  <div class="coy">
                    <?php echo $value1["rel_y"];?>

                    )
                  </div>
                </td>
                <td class="res"><?php echo $value1["creation_date"];?></td>
              </tr>
              <?php } ?>


            <?php if( ($counter1 == -1) ){ ?>

              <tr>
                <td colspan="4" class="none">
                  <?php  echo LANGUI_CUSTBU_RPLC_p4_t6;?> .
                </td>
              </tr>
              <?php } ?>

            </tbody>
          </table>
          <br />
          <br />
          <?php } ?>

		  </body>
</html>