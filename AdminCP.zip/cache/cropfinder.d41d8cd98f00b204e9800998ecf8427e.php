<?php if(!class_exists('raintpl')){exit;}?><!DOCTYPE html>

<html lang="ar">

<head>

    <meta charset="UTF-8">

    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

</head>

<body>
<?php echo load_lang('ui/cropfinder'); ?>

<form id="cropfinder_form" action="cropfinder" method="post">
    <table id="croplist" cellpadding="1" cellspacing="1">
        <thead>
            <tr>
		        <th colspan="2"><?php  echo LANGUI_CROP_1;?></th>
            </tr>
        </thead>
        <tbody>
		    <tr class="top">
			    <td><?php  echo LANGUI_CROP_2;?></td>
	    	    <td>
				    Y<input class="text" maxlength="4" value="<?php if( (is_post('myp')) ){ ?><?php echo $myp;?><?php }else{ ?><?php echo $rely;?><?php } ?>" name="myp">
			        X<input class="text" maxlength="4" value="<?php if( (is_post('mxp')) ){ ?><?php echo $mxp;?><?php }else{ ?><?php echo $relx;?><?php } ?>" name="mxp">
				</td>
		    </tr>
	        <tr>
			    <td><?php  echo LANGUI_CROP_3;?></td>
	    	    <td>
					&nbsp;<input type="radio" value="1" name="type" class="radio"<?php if( (!is_post('type') || (is_post('type') and post('type') == 1)) ){ ?> checked="checked" <?php } ?>><?php  echo LANGUI_CROP_4;?>

			        &nbsp;<input type="radio" value="6" name="type" class="radio"<?php if( (is_post('type') and post('type') == 6) ){ ?> checked="checked" <?php } ?> ><?php  echo LANGUI_CROP_5;?>

			        &nbsp;<input type="radio" value="12" name="type" class="radio"<?php if( (is_post('type') and post('type') == 12) ){ ?> checked="checked" <?php } ?> > <?php  echo LANGUI_CROP_19;?>

			    </td>
	        </tr>
		    <tr class="btm">
	    	    <td><?php  echo LANGUI_CROP_6;?></td>
	    	    <td>
				    <input type="checkbox" value="1" name="only_free" class="check"<?php if( (is_post('only_free') and post('only_free') == 1) ){ ?> checked="checked" <?php } ?>><?php  echo LANGUI_CROP_7;?>

				</td>
	        </tr>
        </tbody>
    </table>
	<p class="btn">
	    <input type="image" value="search" id="btn_search" class="dynamic_img " name="suchen" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>">
    </p>
</form>

<?php if( (is_post('type')) ){ ?>

	<table id="croplist" cellspacing="1" cellpadding="1">
	    <thead>
		    <tr>
			   <th colspan="7"><?php if( $_POST['type'] == 12 ){ ?><?php  echo LANGUI_CROP_19;?><?php }else{ ?><?php  echo LANGUI_CROP_14;?><?php } ?></th>
		    </tr>
		    <tr>
		       <td></td>
			   <td><?php  echo LANGUI_CROP_9;?></td>
			   <td><?php  echo LANGUI_CROP_10;?></td>
			   <td><?php  echo LANGUI_CROP_11;?></td>
			   <td><?php  echo LANGUI_CROP_12;?></td>
			   <td><?php  echo LANGUI_CROP_13;?></td>
		    </tr>
	    </thead>
	    <tbody>
	    <?php $_c = 0;?>

		<?php $counter1=-1; if( isset($cropdata) && is_array($cropdata) && sizeof($cropdata) ) foreach( $cropdata as $key1 => $value1 ){ $counter1++; ?>

		<?php $_c = $_c + 1;?>

	        <tr>
	            <td><?php echo $_c;?></td>
			    <td class="aligned_coords center">
				    <a href="village3?id=<?php echo $value1["id"];?>">
					    <div class="cox">(<?php echo $value1["rel_x"];?></div>
						<div class="pi">|</div>
						<div class="coy"><?php echo $value1["rel_y"];?>)</div>
					</a>
				</td>
			    <td class="dist center"><?php if( ($value1["field_maps"] == 1) ){ ?> <?php  echo LANGUI_CROP_15;?> <?php }elseif( $_POST['type'] == 12 ){ ?><?php  echo LANGUI_CROP_20;?> <?php }else{ ?> <?php  echo LANGUI_CROP_16;?> <?php } ?></td>
			    <td class="owned"><?php if( ($value1["player_name"]) ){ ?> <?php echo $value1["player_name"];?> <?php }else{ ?> - <?php } ?></td>
			    <td class="dist center">
				    <b  <?php if( ($value1["player_name"]) ){ ?> style="color:red;"><?php  echo LANGUI_CROP_18;?> <?php }else{ ?> style="color:green;"><?php  echo LANGUI_CROP_17;?>  <?php } ?></b>
				</td>
			    <td class="dist center"><?php echo $key1;?></td>
		    </tr>
	    <?php } ?>

	    </tbody>
    </table>
<?php } ?>

</body>
</html>