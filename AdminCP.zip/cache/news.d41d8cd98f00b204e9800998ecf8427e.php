<?php if(!class_exists('raintpl')){exit;}?><!DOCTYPE html>

<html lang="ar">

<head>

    <meta charset="UTF-8">

    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

</head>

<body>
<?php echo load_lang('ui/news'); ?>

<!--Content-->
<div class="wrapper-contact">
    <img src="<?php echo add_style('background-land.jpg', ASSETS_DIR.'indx/images/'); ?>" /></a></li>

</div>

<div class="container-fluid section2 contact-content-container">

    <article class="caption-block">
        <h1 class="caption-heading"><?php  echo LANGUI_NEWS_T1;?></h1>
        <div class="box-info about-desciption contact-block-2">

            <div class="container">

                <h1 class="all-news-title text-center">
                    <?php  echo LANGUI_NEWS_T2;?>

                </h1>
                    <table class="table table-striped table-hover table-bordered">
                    <thead>
                        <tr>
                            <td>#</td>
                            <td>العنوان</td>
                            <td>التاريخ</td>
                        </tr>
                    </thead>
                    <tbody>
                    <?php $counter1=-1; if( isset($all) && is_array($all) && sizeof($all) ) foreach( $all as $key1 => $value1 ){ $counter1++; ?>

                        <tr>
                          <td><?php echo $key1+1;?></td>
                          <td>
                              <a href="profile?uid="><?php echo $value1["subject"];?></a>
                          </td>
                          <td><?php echo $value1["date"];?></td>
                        </tr>
                    <?php } ?>

                    </tbody>
                </table>

            </div>

        </div>


    </article>
</div>


<!--News Modal-->
<div class="modal fade" id="news"  tabindex="-1" role="dialog"  aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h2 class="modal-title single-news-title" id="myModalLabel">
                    <span class="news-date ">
                    1.30.2017
                </span>

                </h2>
            </div>
            <div class="modal-body">
                <p class="news-text-block">




                </p>

            </div>
        </div>
    </div>
</div>
</body>
</html>