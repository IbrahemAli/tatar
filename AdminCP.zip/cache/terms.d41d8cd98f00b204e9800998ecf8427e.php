<?php if(!class_exists('raintpl')){exit;}?><!DOCTYPE html>

<html lang="ar">

<head>

    <meta charset="UTF-8">

    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

</head>

<body>
<?php echo load_lang('ui/terms'); ?>

<!--Content-->
<div class="wrapper-contact">
    <img src="<?php echo add_style('background-land.jpg', ASSETS_DIR.'indx/images/'); ?>" /></a></li>

</div>

<div class="container-fluid section2 contact-content-container">

    <article class="caption-block">
        <h1 class="caption-heading"><?php  echo BIGHEAD;?></h1>
        <div class="box-info about-desciption contact-block-2">
            <div class="full-terms-info">
                <h2><?php  echo MIDDLEHEAD_1;?></h2>
                <p><?php  echo TEXT_1;?></p>
                <h2><?php  echo MIDDLEHEAD_2;?></h2>
                <p><?php  echo TEXT_2;?></p>
                <h2><?php  echo MIDDLEHEAD_3;?></h2>
                <p><?php  echo TEXT_3;?></p>
                <h2><?php  echo MIDDLEHEAD_4;?></h2>
                <p><?php  echo TEXT_4;?></p>
                <h2><?php  echo MIDDLEHEAD_5;?></h2>
                <p><?php  echo TEXT_5;?></p>
                <h2><?php  echo MIDDLEHEAD_6;?></h2>
                <p><?php  echo TEXT_6;?></p>
                <h2><?php  echo MIDDLEHEAD_7;?></h2>
                <p><?php  echo TEXT_7;?></p>
                <h2><?php  echo MIDDLEHEAD_8;?></h2>
                <p><?php  echo TEXT_8;?></p>
                <h2><?php  echo MIDDLEHEAD_9;?></h2>
                <p><?php  echo TEXT_9;?></p>
                <h2><?php  echo MIDDLEHEAD_10;?></h2>
                <p><?php  echo TEXT_10;?></p>
                <h2><?php  echo MIDDLEHEAD_11;?></h2>
                <p><?php  echo TEXT_11;?></p>
                <h2><?php  echo MIDDLEHEAD_12;?></h2>
                <p><?php  echo TEXT_12;?></p>
                <h2><?php  echo MIDDLEHEAD_13;?></h2>
                <p><?php  echo TEXT_13;?></p>
                <h2><?php  echo MIDDLEHEAD_14;?></h2>
                <p><?php  echo TEXT_14;?></p>
                <h2><?php  echo MIDDLEHEAD_15;?></h2>
                <p><?php  echo TEXT_15;?></p>
                <h2><?php  echo MIDDLEHEAD_16;?></h2>
                <p><?php  echo TEXT_16;?></p>
                <h2><?php  echo MIDDLEHEAD_17;?></h2>
                <p><?php  echo TEXT_17;?></p>
                <h2><?php  echo MIDDLEHEAD_18;?></h2>
                <p><?php  echo TEXT_18;?></p>
                <h2><?php  echo MIDDLEHEAD_19;?></h2>
                <p><?php  echo TEXT_19;?></p>
            </div>
        </div>


    </article>
</div>
</body>
</html>