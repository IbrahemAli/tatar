<?php if(!class_exists('raintpl')){exit;}?><!DOCTYPE html>

<html lang="ar">

<head>

    <meta charset="UTF-8">

    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

</head>

<body>
<?php echo load_lang('ui/statistics'); ?>

<h1><?php  echo LANGUI_STAT_T1;?></h1>
    <div id="textmenu">
	     <a href="analytics"<?php if( ($selectedTabIndex == 0 || $selectedTabIndex == 5 || $selectedTabIndex == 6 || $selectedTabIndex == 7) ){ ?> class="selected" <?php } ?>><?php  echo LANGUI_STAT_T2;?></a> |
		 <a href="analytics?t=1"<?php if( ($selectedTabIndex == 1 || $selectedTabIndex == 8 || $selectedTabIndex == 9 || $selectedTabIndex == 10) ){ ?> class="selected"<?php } ?>><?php  echo LANGUI_STAT_T3;?></a> |
		 <a href="analytics?t=2"<?php if( ($selectedTabIndex == 2) ){ ?> class="selected"<?php } ?>><?php  echo LANGUI_STAT_T4;?></a> |
		 <a href="analytics?t=3"<?php if( ($selectedTabIndex == 3) ){ ?> class="selected"<?php } ?>><?php  echo LANGUI_STAT_T5;?></a>
    <?php if( ($tatarRaised) ){ ?>

      | <a href="analytics?t=11"<?php if( ($selectedTabIndex == 11) ){ ?> class="selected"<?php } ?>><?php  echo LANGUI_STAT_T6;?></a>
    <?php } ?>

      | <a href="analytics?t=4"<?php if( ($selectedTabIndex == 4) ){ ?> class="selected"<?php } ?>><?php  echo LANGUI_STAT_T7;?></a>
	</div>
<?php if( ($selectedTabIndex == 0) ){ ?>

    <table cellpadding="1" cellspacing="1" id="player" class="row_table_data">
	    <thead>
		    <tr>
			    <th colspan="<?php if( ($isAdmin) ){ ?>7<?php }else{ ?>6<?php } ?>"><?php  echo LANGUI_STAT_T9;?> <?php if( (0 < $_tb) ){ ?><?php echo constant('tribe_'.$_tb); ?><?php } ?>

                <div id="submenu">
				    <a title="<?php  echo LANGUI_STAT_T10;?>" href="analytics?t=5">
					    <img class="btn_top10" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo LANGUI_STAT_T10;?>">
					</a>
					<a title="<?php  echo LANGUI_STAT_T11;?>" href="analytics?t=6">
					    <img class="btn_def" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo LANGUI_STAT_T11;?>">
					</a>
					<a title="<?php  echo LANGUI_STAT_T12;?>" href="analytics?t=7">
					    <img class="btn_off" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo LANGUI_STAT_T12;?>">
					</a>
				</div>
				<div id="submenu2">
					<a title="<?php  echo tribe_7;?>" href="<?php if( ($_tb != 7) ){ ?>?tb=7<?php } ?>">
					    <img class="<?php if( ($_tb == 7) ){ ?>active <?php } ?>btn_v7" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo LANGUI_STAT_T12;?>">
					</a>
					<a title="<?php  echo tribe_1;?>" href="<?php if( ($_tb != 1) ){ ?>?tb=1<?php } ?>">
					    <img class="<?php if( ($_tb == 1) ){ ?>active <?php } ?>btn_v1" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo LANGUI_STAT_T12;?>">
					</a>
					<a title="<?php  echo tribe_2;?>" href="<?php if( ($_tb != 2) ){ ?>?tb=2<?php } ?>">
					    <img class="<?php if( ($_tb == 2) ){ ?>active <?php } ?>btn_v2" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo LANGUI_STAT_T12;?>">
					</a>
					<a title="<?php  echo tribe_3;?>" href="<?php if( ($_tb != 3) ){ ?>?tb=3<?php } ?>">
					    <img class="<?php if( ($_tb == 3) ){ ?>active <?php } ?>btn_v3" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo LANGUI_STAT_T12;?>">
					</a>
				</div>
			    </th>
			</tr>
			<tr>
			    <td></td>
				<td><?php  echo LANGUI_STAT_T2;?></td>
				<td><?php  echo LANGUI_STAT_T13;?></td>
				<td><?php  echo LANGUI_STAT_T14;?></td>
				<td><?php  echo LANGUI_STAT_T4;?></td>
				<td><?php  echo LANGUI_STAT_T53;?></td>
            <?php if( ( $isAdmin ) ){ ?>

				<td></td>
            <?php } ?>

            </tr>
            <?php if( ($adminActionMessage != '') ){ ?>

            <tr>
			    <td colspan="7">
				    <div class="error">
					    <b><?php echo $adminActionMessage;?></b>
					</div>
				</td>
			<tr>
            <?php } ?>

        </thead>
		<tbody>
    <?php $rowIndex = 0;?>

    <?php $counter1=-1; if( isset($dataList) && is_array($dataList) && sizeof($dataList) ) foreach( $dataList as $key1 => $value1 ){ $counter1++; ?>

        <?php $rowIndex = $rowIndex + 1;?>

        <?php $rank = $rowIndex + $pageIndex * $pageSize;?>

        <tr<?php if( ($selectedRank == $rank) ){ ?> class="hl"<?php } ?>>
		    <td class="ra"><?php echo $rank;?></td>
			<td class="pla">
			    <a href="profile?uid=<?php echo $value1["id"];?>">
				<?php if( ($value1["player_type"] == PLAYERTYPE_ADMIN) ){ ?><span style="color:#0000ff;" title="<?php  echo LANGUI_STAT_T17;?>" alt="<?php  echo LANGUI_STAT_T17;?>"><?php } ?>

				<?php if( ($value1["player_type"] == PLAYERTYPE_HUNTER) ){ ?><span style="color:#FF66FF;" title="<?php  echo LANGUI_STAT_BB1;?>" alt="<?php  echo LANGUI_STAT_BB1;?>"><?php } ?>

				<?php if( ($value1["player_type"] == PLAYERTYPE_ONE) ){ ?><span style="color:#666633;" title="<?php  echo LANGUI_STAT_BB2;?>" alt="<?php  echo LANGUI_STAT_BB2;?>"><?php } ?>

				<?php if( ($value1["player_type"] == PLAYERTYPE_WIN) ){ ?><span style="color:#CC0000;" title="<?php  echo LANGUI_STAT_BB3;?>" alt="<?php  echo LANGUI_STAT_BB3;?>"><?php } ?>

				<?php if( ($value1["player_type"] == PLAYERTYPE_WINWEEK) ){ ?><span style="color:#660000;" title="<?php  echo LANGUI_STAT_BB4;?>" alt="<?php  echo LANGUI_STAT_BB4;?>"><?php } ?>

				<?php if( ($value1["player_type"] == PLAYERTYPE_WINTATAR) ){ ?><span style="color:#000000;" title="<?php  echo LANGUI_STAT_BB5;?>" alt="<?php  echo LANGUI_STAT_BB5;?>"><?php } ?>

                <?php echo $value1["name"];?>

                <?php if( ($value1["player_type"] == PLAYERTYPE_ADMIN) ){ ?></span><?php } ?>

				<?php if( ($value1["player_type"] == PLAYERTYPE_HUNTER) ){ ?></span><?php } ?>

				<?php if( ($value1["player_type"] == PLAYERTYPE_ONE) ){ ?></span><?php } ?>

				<?php if( ($value1["player_type"] == PLAYERTYPE_WIN) ){ ?></span><?php } ?>

				<?php if( ($value1["player_type"] == PLAYERTYPE_WINWEEK) ){ ?></span><?php } ?>

				<?php if( ($value1["player_type"] == PLAYERTYPE_WINTATAR) ){ ?></span><?php } ?>

				</a>
			</td>
			<td class="al">
			<?php if( (0 < intval($value1["alliance_id"])) ){ ?>

			    <a href="alliance?id=<?php echo $value1["alliance_id"];?>"><?php echo $value1["alliance_name"];?></a>
            <?php } ?>

			</td>
			<td class="pop"><?php echo $value1["total_people_count"];?></td>
			<td class="vil"><?php echo $value1["villages_count"];?></td>
            <td>
                <a href="message?uid=<?php echo $value1["id"];?>">
                    <img src="<?php echo add_style('msg.png', ASSETS_DIR.'/default/img/a/'); ?>" />
                </a>
			</td>
        <?php if( ($isAdmin) ){ ?>

            <td>
            <?php if( ($value1["player_type"] == PLAYERTYPE_NORMAL) ){ ?>

                <a href="analytics?_jsdue=<?php echo $value1["id"];?><?php if( ( 0 < $_tb) ){ ?>&tb=<?php echo $_tb;?><?php } ?><?php if( ( 0 < $pageIndex) ){ ?>&p=<?php echo $pageIndex;?><?php } ?>">
				    <img class="online<?php if( ($value1["is_blocked"]) ){ ?>4<?php }else{ ?>2<?php } ?>" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php if( ($value1["is_blocked"]) ){ ?><?php  echo LANGUI_STAT_T51;?><?php }else{ ?><?php  echo LANGUI_STAT_T52;?><?php } ?>" title="<?php if( ($value1["is_blocked"]) ){ ?><?php  echo LANGUI_STAT_T51;?><?php }else{ ?><?php  echo LANGUI_STAT_T52;?><?php } ?>">
				</a>
            <?php } ?>

            </td>
        <?php } ?>

        </tr>
    <?php } ?>

        </tbody>
	</table>
	<table cellpadding="1" cellspacing="1" id="search_navi">
	    <tbody>
		    <tr>
			    <td>
				    <form method="post" action="analytics<?php if( (0 < $selectedTabIndex) ){ ?>?t=<?php echo $selectedTabIndex;?><?php }elseif( (0 < $_tb) ){ ?>?tb=<?php echo $_tb;?><?php } ?>">
					<div class="search">
                        <span><?php  echo LANGUI_STAT_T20;?>:
                            <input type="text" class="text ra" maxlength="5" name="rank" value="<?php if( (0 < $selectedRank) ){ ?><?php echo $selectedRank;?><?php } ?>">
						</span>
                        <span class="or"><?php  echo text_or_lang;?></span>
                        <span><?php  echo LANGUI_STAT_T21;?>

                            <input type="text" class="text name" maxlength="20" name="name" value="">
						</span>
						<input type="image" value="submit" name="submit" id="btn_ok" class="dynamic_img" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo text_okdone_lang;?>">
					</div>
					</form>
					<div class="navi"><?php echo $getPreviousLink;?>|<?php echo $getNextLink;?></div>
				</td>
			</tr>
		</tbody>
	</table>
<?php }elseif( ($selectedTabIndex == 1) ){ ?>

    <table cellpadding="1" cellspacing="1" id="alliance" class="row_table_data">
	    <thead>
		    <tr>
			    <th colspan="5"><?php  echo LANGUI_STAT_T22;?>

                    <div id="submenu">
					    <a title="<?php  echo LANGUI_STAT_T10;?>" href="analytics?t=8">
						    <img class="btn_top10" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo LANGUI_STAT_T10;?>">
						</a>
						<a title="<?php  echo LANGUI_STAT_T11;?>" href="analytics?t=9">
						    <img class="btn_def" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo LANGUI_STAT_T11;?>">
						</a>
						<a title="<?php  echo LANGUI_STAT_T12;?>" href="analytics?t=10">
						    <img class="btn_off" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo LANGUI_STAT_T12;?>">
						</a>
					</div>
				</th>
			</tr>
			<tr>
			    <td></td>
				<td><?php  echo LANGUI_STAT_T13;?></td>
				<td><?php  echo LANGUI_STAT_T2;?></td>
                <td>&Oslash;</td>
				<td><?php  echo LANGUI_STAT_T23;?></td>
			</tr>
		</thead>
		<tbody>
    <?php $rowIndex = 0;?>

    <?php $counter1=-1; if( isset($dataList) && is_array($dataList) && sizeof($dataList) ) foreach( $dataList as $key1 => $value1 ){ $counter1++; ?>

        <?php $rowIndex = $rowIndex + 1;?>

        <?php $rank = $rowIndex + $pageIndex * $pageSize;?>

        <tr<?php if( ($selectedRank == $rank) ){ ?> class="hl"<?php } ?>>
		    <td class="ra"><?php echo $rank;?></td>
			<td class="al">
				<a href="alliance?id=<?php echo $value1["id"];?>"><?php echo $value1["name"];?></a>
			</td>
			<td class="pla"><?php echo $value1["player_count"];?></td>
            <td class="po"><?php echo round($value1["average"]); ?></td>
			<td class="po"><?php echo $value1["points"];?></td>
		</tr>
    <?php } ?>

        </tbody>
	</table>
	<table cellpadding="1" cellspacing="1" id="search_navi">
	    <tbody>
		    <tr>
			    <td>
				    <form method="post" action="analytics<?php if( (0 < $selectedTabIndex) ){ ?>?t=<?php echo $selectedTabIndex;?><?php } ?>">
					    <div class="search">
                            <span><?php  echo LANGUI_STAT_T20;?>:<input type="text" class="text ra" maxlength="5" name="rank" value="<?php if( (0 < $selectedRank) ){ ?><?php echo $selectedRank;?><?php } ?>"></span>
                            <span class="or"><?php  echo text_or_lang;?></span>
                            <span><?php  echo LANGUI_STAT_T21;?><input type="text" class="text name" maxlength="20" name="name" value=""></span>
							<input type="image" value="submit" name="submit" id="btn_ok" class="dynamic_img" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo text_okdone_lang;?>">
						</div>
					</form>
				    <div class="navi"><?php echo $getPreviousLink;?>|<?php echo $getNextLink;?></div>
				</td>
			</tr>
		</tbody>
	</table>
<?php }elseif( ($selectedTabIndex == 2) ){ ?>

    <table cellpadding="1" cellspacing="1" id="villages" class="row_table_data">
	    <thead>
		    <tr>
			    <th colspan="5"><?php  echo LANGUI_STAT_T24;?></th>
			</tr>
			<tr>
			    <td></td>
				<td><?php  echo LANGUI_STAT_T25;?></td>
				<td><?php  echo LANGUI_STAT_T2;?></td>
				<td><?php  echo LANGUI_STAT_T14;?></td>
				<td><?php  echo LANGUI_STAT_T26;?></td>
            </tr>
		</thead>
		<tbody>
    <?php $rowIndex = 0;?>

    <?php $counter1=-1; if( isset($dataList) && is_array($dataList) && sizeof($dataList) ) foreach( $dataList as $key1 => $value1 ){ $counter1++; ?>

        <?php $rowIndex = $rowIndex + 1;?>

        <?php $rank = $rowIndex + $pageIndex * $pageSize;?>

        <tr<?php if( ($selectedRank == $rank) ){ ?> class="hl"<?php } ?>>
		    <td class="ra"><?php echo $rank;?></td>
			<td class="vil">
			    <a href="village3?id=<?php echo $value1["id"];?>"><?php echo $value1["village_name"];?></a>
			</td>
			<td class="pla">
			    <a href="profile?uid=<?php echo $value1["player_id"];?>"><?php echo $value1["player_name"];?></a>
			</td>
			<td class="hab"><?php echo $value1["people_count"];?></td>
			<td class="aligned_coords ">
			    <div class="cox">(<?php echo $value1["rel_x"];?></div>
				<div class="pi">|</div>
				<div class="coy"><?php echo $value1["rel_y"];?>)</div>
			</td>
        </tr>
    <?php } ?>

        </tbody>
	</table>
	<table cellpadding="1" cellspacing="1" id="search_navi">
	    <tbody>
		    <tr>
			    <td>
				    <form method="post" action="analytics<?php if( (0 < $selectedTabIndex) ){ ?>?t=<?php echo $selectedTabIndex;?><?php } ?>">
					    <div class="search">
                            <span><?php  echo LANGUI_STAT_T20;?>:<input type="text" class="text ra" maxlength="5" name="rank" value="<?php if( (0 < $selectedRank) ){ ?><?php echo $selectedRank;?><?php } ?>"></span>
                            <span class="or"><?php  echo text_or_lang;?></span>
                            <span><?php  echo LANGUI_STAT_T21;?><input type="text" class="text name" maxlength="20" name="name" value=""></span>
							<input type="image" value="submit" name="submit" id="btn_ok" class="dynamic_img" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo text_okdone_lang;?>">
						</div>
					</form>
				    <div class="navi"><?php echo $getPreviousLink;?>|<?php echo $getNextLink;?></div>
				</td>
			</tr>
		</tbody>
	</table>
<?php }elseif( ($selectedTabIndex == 3) ){ ?>

    <table cellpadding="1" cellspacing="1" id="heroes" class="row_table_data">
	    <thead>
		    <tr>
			    <th colspan="5"><?php  echo LANGUI_STAT_T28;?></th>
			</tr>
			<tr>
			    <td></td>
				<td><?php  echo LANGUI_STAT_T29;?></td>
				<td><?php  echo LANGUI_STAT_T2;?></td>
				<td><?php  echo level_lang2;?></td>
				<td><?php  echo LANGUI_STAT_T30;?></td>
			</tr>
		</thead>
		<tbody>
    <?php $rowIndex = 0;?>

    <?php $counter1=-1; if( isset($dataList) && is_array($dataList) && sizeof($dataList) ) foreach( $dataList as $key1 => $value1 ){ $counter1++; ?>

        <?php $rowIndex = $rowIndex + 1;?>

        <?php $rank = $rowIndex + $pageIndex * $pageSize;?>

        <tr<?php if( ($selectedRank == $rank) ){ ?> class="hl"<?php } ?>>
		    <td class="ra"><?php echo $rank;?></td>
			<td class="hero">
			    <img class="unit u<?php echo $value1["hero_troop_id"];?>" alt="<?php echo constant('troop_' . $value1["hero_troop_id"]); ?>" title="<?php echo constant('troop_' . $value1["hero_troop_id"]); ?>" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>"> &nbsp;<?php echo $value1["hero_name"];?>

			</td>
			<td class="pla">
			    <a href="profile?uid=<?php echo $value1["id"];?>"><?php echo $value1["name"];?></a>
			</td>
		    <td class="lev"><?php echo $value1["hero_level"];?></td>
			<td class="xp"><?php echo $value1["hero_points"];?></td>
		</tr>
    <?php } ?>

        </tbody>
	</table>
	<table cellpadding="1" cellspacing="1" id="search_navi">
	    <tbody>
		    <tr>
			    <td>
				    <form method="post" action="analytics<?php if( (0 < $selectedTabIndex) ){ ?>?t=<?php echo $selectedTabIndex;?><?php } ?>">
					    <div class="search">
                            <span><?php  echo LANGUI_STAT_T20;?>:<input type="text" class="text ra" maxlength="5" name="rank" value="<?php if( (0 < $selectedRank) ){ ?><?php echo $selectedRank;?><?php } ?>"></span>
                            <span class="or"><?php  echo text_or_lang;?></span>
                            <span><?php  echo LANGUI_STAT_T21;?><input type="text" class="text name" maxlength="20" name="name" value=""></span>
							<input type="image" value="submit" name="submit" id="btn_ok" class="dynamic_img" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo text_okdone_lang;?>">
						</div>
					</form>
				    <div class="navi"><?php echo $getPreviousLink;?>|<?php echo $getNextLink;?></div>
				</td>
			</tr>
		</tbody>
	</table>
<?php }elseif( ($selectedTabIndex == 11) ){ ?>

    <table cellpadding="1" cellspacing="1" id="villages" class="row_table_data">
	    <thead>
		    <tr>
			    <th colspan="5"><?php  echo LANGUI_STAT_T24;?></th>
			</tr>
			<tr>
			    <td></td>
			    <td><?php  echo LANGUI_STAT_T2;?></td>
			    <td><?php  echo LANGUI_STAT_T25;?></td>
			    <td><?php  echo LANGUI_STAT_T13;?></td>
			    <td><?php  echo level_lang;?></td>
			</tr>
		</thead>
		<tbody>
    <?php $rowIndex = 0;?>

    <?php $counter1=-1; if( isset($dataList) && is_array($dataList) && sizeof($dataList) ) foreach( $dataList as $key1 => $value1 ){ $counter1++; ?>

        <?php $rowIndex = $rowIndex + 1;?>

        <tr>
		    <td class="ra"><?php echo $rowIndex;?></td>
			<td class="pla">
			    <a href="profile?uid=<?php echo $value1["player_id"];?>"><?php echo $value1["player_name"];?></a>
			</td>
			<td class="vil">
			    <a href="village3?id=<?php echo $value1["id"];?>"><?php echo $value1["village_name"];?></a>
			</td>
			<td class="vil">
			<?php if( (0 < intval($value1["alliance_id"])) ){ ?>

                <a href="alliance?id=<?php echo $value1["alliance_id"];?>"><?php echo $value1["alliance_name"];?></a>
            <?php } ?>

			</td>
			<td class="ra" style="text-align:center;"><?php echo $value1["buildings"];?></td>
		</tr>
    <?php } ?>

        </tbody>
	</table>
<?php }elseif( ($selectedTabIndex == 4) ){ ?>

    <table cellpadding="1" cellspacing="1" id="world_player" class="world">
	    <thead>
		    <tr>
			    <th colspan="2"><?php  echo LANGUI_STAT_T54;?></th>
			</tr>
		</thead>
		<tbody>
        <?php if( $GameOver ){ ?>

            <tr>
                <td>
                    <strong><?php  echo LANGUI_STAT_T60;?>:</strong>
                </td>
                <td><span id="timer1"><?php echo $siteReset;?></span> <?php  echo time_hour_lang;?></td>
            </tr>
            <?php }else{ ?>

            <tr>
                <td>
                    <strong><?php  echo LANGUI_STAT_T55;?>:</strong>
                </td>
                <td><span id="timer2"><?php echo $starttime;?></span> <?php  echo time_hour_lang;?></td>
            </tr>
            <tr>
                <td>
                  <strong><?php  echo LANGUI_STAT_T56;?>:</strong>
                </td>
                <td><?php if( $tatardate > 0 ){ ?><span id="timer1"><?php echo $tatartime;?></span> <?php  echo time_hour_lang;?><?php }else{ ?><?php  echo LANGUI_STAT_T57;?><?php } ?></td>
            </tr>
            <tr>
                <td>
                    <strong><?php  echo LANGUI_STAT_T58;?>:</strong>
                </td>
                <td><?php if( $Artdate > 0 ){ ?><span id="timer1"><?php echo $Arttime;?></span> <?php  echo time_hour_lang;?><?php }else{ ?><?php  echo LANGUI_STAT_T59;?><?php } ?></td>
            </tr>
        <?php } ?>

		</tbody>
	</table>
	<table cellpadding="1" cellspacing="1" id="player" class="row_table_data">
	    <thead>
		    <tr>
			    <th colspan="4"><?php  echo LANGUI_STAT_T34;?></th>
			</tr>
		</thead>
		<tbody>
			<tr>
			    <td class="pla"><?php  echo LANGUI_STAT_T31;?></td>
				<td class="pop"><?php echo $generalData["players_count"];?></td>
				<td class="pla"><?php  echo LANGUI_STAT_T66;?></td>
                <td class="pop"><?php echo $settings["over"];?></td>
			</tr>
			<tr>
			    <td class="pla"><?php  echo LANGUI_STAT_T32;?></td>
				<td class="pop"><?php echo $settings["speed"];?></td>
			    <td class="pla"><?php  echo LANGUI_STAT_T63;?></td>
				<td class="pop"><?php echo $settings["protection"];?></td>
			</tr>
			<tr>
			    <td class="pla"><?php  echo LANGUI_STAT_T61;?></td>
				<td class="pop"><?php echo $settings["attack"];?></td>
                <td class="pla"><?php  echo LANGUI_STAT_T64;?></td>
                <td class="pop"><?php echo $settings["wingold"];?></td>
			</tr>
			<tr>
				<td class="pla"><?php  echo LANGUI_STAT_T33;?></td>
                <td class="pop"><?php echo $settings["speed"] * $settings["moared"];?></td>
				<td class="pla"><?php  echo LANGUI_STAT_T65;?></td>
				<td class="pop"><?php if( $settings["Crop"] > 10 ){ ?><?php  echo LANGUI_STAT_T69;?><?php }else{ ?><?php  echo LANGUI_STAT_T68;?><?php } ?></td>
			</tr>
            <tr>
				<td class="pla"><?php  echo LANGUI_STAT_T62;?></td>
                <td class="pop"><?php echo $settings["capacity"];?></td>
				<td class="pla"><?php  echo LANGUI_STAT_T67;?></td>
                <td class="pop"><?php if( $settings["buytroop"] == 0 ){ ?><?php  echo LANGUI_STAT_T69;?><?php }else{ ?><?php  echo LANGUI_STAT_T68;?><?php } ?></td>
			</tr>
		</tbody>
	</table>
<?php }elseif( ($selectedTabIndex == 6 || $selectedTabIndex == 7) ){ ?>

    <table cellpadding="1" cellspacing="1" id="player_off" class="row_table_data">
	    <thead>
		    <tr>
			    <th colspan="5"><?php if( ($selectedTabIndex == 6) ){ ?><?php  echo LANGUI_STAT_T37;?><?php }else{ ?><?php  echo LANGUI_STAT_T38;?><?php } ?>

                <div id="submenu">
				    <a title="<?php  echo LANGUI_STAT_T10;?>" href="analytics?t=5">
					    <img class="btn_top10" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo LANGUI_STAT_T10;?>">
					</a>
					<a title="<?php  echo LANGUI_STAT_T11;?>" href="analytics<?php if( ($selectedTabIndex == 6) ){ ?><?php }else{ ?>?t=6<?php } ?>">
					    <img class="<?php if( ($selectedTabIndex == 6) ){ ?>active btn_def<?php }else{ ?>btn_def<?php } ?>" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo LANGUI_STAT_T11;?>">
					</a>
					<a title="<?php  echo LANGUI_STAT_T12;?>" href="analytics<?php if( ($selectedTabIndex == 7) ){ ?><?php }else{ ?>?t=7<?php } ?>">
					    <img class="<?php if( ($selectedTabIndex == 7) ){ ?>active btn_off<?php }else{ ?>btn_off<?php } ?>" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo LANGUI_STAT_T12;?>">
					</a>
				</div>
				<div id="submenu2">
					<a title="<?php  echo tribe_7;?>" href="<?php if( ($_tb != 7) ){ ?>?tb=7<?php } ?>">
					    <img class="<?php if( ($_tb == 7) ){ ?>active <?php } ?>btn_v7" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo LANGUI_STAT_T12;?>">
					</a>
					<a title="<?php  echo tribe_1;?>" href="<?php if( ($_tb != 1) ){ ?>?tb=1<?php } ?>">
					    <img class="<?php if( ($_tb == 1) ){ ?>active <?php } ?>btn_v1" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo LANGUI_STAT_T12;?>">
					</a>
					<a title="<?php  echo tribe_2;?>" href="<?php if( ($_tb != 2) ){ ?>?tb=2<?php } ?>">
					    <img class="<?php if( ($_tb == 2) ){ ?>active <?php } ?>btn_v2" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo LANGUI_STAT_T12;?>">
					</a>
					<a title="<?php  echo tribe_3;?>" href="<?php if( ($_tb != 3) ){ ?>?tb=3<?php } ?>">
					    <img class="<?php if( ($_tb == 3) ){ ?>active <?php } ?>btn_v3" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo LANGUI_STAT_T12;?>">
					</a>
				</div>
				</th>
			</tr>
			<tr>
			    <td></td>
				<td><?php  echo LANGUI_STAT_T2;?></td>
				<td><?php  echo LANGUI_STAT_T14;?></td>
				<td><?php  echo LANGUI_STAT_T4;?></td>
				<td><?php  echo LANGUI_STAT_T23;?></td>
			</tr>
		</thead>
		<tbody>
    <?php $rowIndex = 0;?>

    <?php $counter1=-1; if( isset($dataList) && is_array($dataList) && sizeof($dataList) ) foreach( $dataList as $key1 => $value1 ){ $counter1++; ?>

        <?php $rowIndex = $rowIndex + 1;?>

        <?php $rank = $rowIndex + $pageIndex * $pageSize;?>

        <tr<?php if( ($selectedRank == $rank) ){ ?> class="hl"<?php } ?>>
		    <td class="ra"><?php echo $rank;?></td>
			<td class="pla">
			    <a href="profile?uid=<?php echo $value1["id"];?>"><?php echo $value1["name"];?></a>
			</td>
			<td class="pop"><?php echo $value1["total_people_count"];?></td>
			<td class="vil"><?php echo $value1["villages_count"];?></td>
			<td class="po"><?php echo $value1["points"];?></td>
		</tr>
    <?php } ?>

        </tbody>
	</table>
	<table cellpadding="1" cellspacing="1" id="search_navi">
	    <tbody>
		    <tr>
			    <td>
				    <form method="post" action="analytics<?php if( (0 < $selectedTabIndex) ){ ?>?t=<?php echo $selectedTabIndex;?><?php } ?>">
					    <div class="search">
                            <span><?php  echo LANGUI_STAT_T20;?>:<input type="text" class="text ra" maxlength="5" name="rank" value="<?php if( (0 < $selectedRank) ){ ?><?php echo $selectedRank;?><?php } ?>"></span>
                            <span class="or"><?php  echo text_or_lang;?></span>
                            <span><?php  echo LANGUI_STAT_T21;?><input type="text" class="text name" maxlength="20" name="name" value=""></span>
							<input type="image" value="submit" name="submit" id="btn_ok" class="dynamic_img" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo text_okdone_lang;?>">
						</div>
					</form>
				    <div class="navi"><?php echo $getPreviousLink;?>|<?php echo $getNextLink;?></div>
				</td>
			</tr>
		</tbody>
	</table>
<?php }elseif( ($selectedTabIndex == 9 || $selectedTabIndex == 10 ) ){ ?>

    <table cellpadding="1" cellspacing="1" id="alliance" class="row_table_data">
	    <thead>
		    <tr>
			    <th colspan="4"><?php if( ($selectedTabIndex == 9) ){ ?><?php  echo LANGUI_STAT_T39;?><?php }else{ ?><?php  echo LANGUI_STAT_T40;?><?php } ?>

                    <div id="submenu">
					    <a title="<?php  echo LANGUI_STAT_T10;?>" href="analytics?t=8">
						    <img class="btn_top10" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo LANGUI_STAT_T10;?>">
						</a>
						<a title="<?php  echo LANGUI_STAT_T11;?>" href="analytics?<?php if( ($selectedTabIndex == 9) ){ ?>t=1<?php }else{ ?>t=9<?php } ?>">
						    <img class="<?php if( ($selectedTabIndex == 9) ){ ?>active <?php } ?>btn_def" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo LANGUI_STAT_T11;?>">
						</a>
						<a title="<?php  echo LANGUI_STAT_T12;?>" href="analytics?<?php if( ($selectedTabIndex == 10) ){ ?>t=1<?php }else{ ?>t=10<?php } ?>">
						    <img class="<?php if( ($selectedTabIndex == 10) ){ ?>active <?php } ?>btn_off" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo LANGUI_STAT_T12;?>">
						</a>
					</div>
				</th>
			</tr>
			<tr>
			    <td></td>
				<td><?php  echo LANGUI_STAT_T13;?></td>
				<td><?php  echo LANGUI_STAT_T2;?></td>
				<td><?php  echo LANGUI_STAT_T23;?></td>
			</tr>
		</thead>
		<tbody>
    <?php $rowIndex = 0;?>

    <?php $counter1=-1; if( isset($dataList) && is_array($dataList) && sizeof($dataList) ) foreach( $dataList as $key1 => $value1 ){ $counter1++; ?>

        <?php $rowIndex = $rowIndex + 1;?>

        <?php $rank = $rowIndex + $pageIndex * $pageSize;?>

        <tr<?php if( ($selectedRank == $rank) ){ ?> class="hl"<?php } ?>>
		    <td class="ra"><?php echo $rank;?></td>
		    <td class="al">
			    <a href="alliance?id=<?php echo $value1["id"];?>"><?php echo $value1["name"];?></a>
			</td>
			<td class="pla"><?php echo $value1["player_count"];?></td>
			<td class="po"><?php echo $value1["points"];?></td>
		</tr>
    <?php } ?>

        </tbody>
	</table>
	<table cellpadding="1" cellspacing="1" id="search_navi">
	    <tbody>
		    <tr>
			    <td>
				    <form method="post" action="analytics<?php if( (0 < $selectedTabIndex) ){ ?>?t=<?php echo $selectedTabIndex;?><?php } ?>">
					    <div class="search">
                            <span><?php  echo LANGUI_STAT_T20;?>:<input type="text" class="text ra" maxlength="5" name="rank" value="<?php if( (0 < $selectedRank) ){ ?><?php echo $selectedRank;?><?php } ?>"></span>
                            <span class="or"><?php  echo text_or_lang;?></span>
                            <span><?php  echo LANGUI_STAT_T21;?><input type="text" class="text name" maxlength="20" name="name" value=""></span>
							<input type="image" value="submit" name="submit" id="btn_ok" class="dynamic_img" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo text_okdone_lang;?>">
						</div>
					</form>
				    <div class="navi"><?php echo $getPreviousLink;?>|<?php echo $getNextLink;?></div>
				</td>
			</tr>
		</tbody>
	</table>
<?php }elseif( ($selectedTabIndex == 5 || $selectedTabIndex == 8) ){ ?>

<?php $showManualID = $selectedTabIndex == 5 ? 0: 1 ;?>

    <table cellpadding="1" cellspacing="1">
	    <thead>
		    <tr>
			    <th><?php if( ($selectedTabIndex == 5) ){ ?><?php  echo LANGUI_STAT_T41;?><?php }else{ ?><?php  echo LANGUI_STAT_T42;?><?php } ?>

                    <div id="submenu">
					    <a title="<?php  echo LANGUI_STAT_T10;?>" href="analytics<?php if( ($selectedTabIndex == 5) ){ ?><?php }else{ ?>t=1<?php } ?>">
						    <img class="active btn_top10" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo LANGUI_STAT_T10;?>">
						</a>
						<a title="<?php  echo LANGUI_STAT_T11;?>" href="analytics?t=<?php if( ($selectedTabIndex == 5) ){ ?>6<?php }else{ ?>9<?php } ?>">
						    <img class="btn_def" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo LANGUI_STAT_T11;?>">
						</a>
						<a title="<?php  echo LANGUI_STAT_T12;?>" href="analytics?t=<?php if( ($selectedTabIndex == 5) ){ ?>7<?php }else{ ?>10<?php } ?>">
						    <img class="btn_off" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo LANGUI_STAT_T12;?>">
						</a>
					</div>
				<?php if( ($selectedTabIndex == 5) ){ ?>

                    <div id="submenu2">
						<a title="<?php  echo tribe_7;?>" href="<?php if( ($_tb != 7) ){ ?>?tb=7<?php } ?>">
						    <img class="<?php if( ($_tb == 7) ){ ?>active <?php } ?>btn_v7" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo LANGUI_STAT_T12;?>">
						</a>
						<a title="<?php  echo tribe_1;?>" href="<?php if( ($_tb != 1) ){ ?>?tb=1<?php } ?>">
						    <img class="<?php if( ($_tb == 1) ){ ?>active <?php } ?>btn_v1" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo LANGUI_STAT_T12;?>">
						</a>
						<a title="<?php  echo tribe_2;?>" href="<?php if( ($_tb != 2) ){ ?>?tb=2<?php } ?>">
						    <img class="<?php if( ($_tb == 2) ){ ?>active <?php } ?>btn_v2" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo LANGUI_STAT_T12;?>">
						</a>
						<a title="<?php  echo tribe_3;?>" href="<?php if( ($_tb != 3) ){ ?>?tb=3<?php } ?>">
						    <img class="<?php if( ($_tb == 3) ){ ?>active <?php } ?>btn_v3" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo LANGUI_STAT_T12;?>">
						</a>
					</div>
                <?php } ?>

                </th>
			</tr>
		</thead>
	</table>
	<table cellpadding="1" cellspacing="1" id="top10_offs" class="top10 row_table_data">
	    <thead>
		    <tr>
			    <th>
				    <a href="#" onclick="return showManual(6,<?php echo $showManualID;?>);">
					    <img class="help" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo LANGUI_STAT_T43;?>" title="<?php  echo LANGUI_STAT_T43;?>">
					</a>
				</th>
				<th colspan="2"><?php  echo LANGUI_STAT_T44;?></th>
			</tr>
			<tr>
			    <td><?php  echo LANGUI_STAT_T20;?></td>
				<td><?php if( ($selectedTabIndex == 5) ){ ?><?php  echo LANGUI_STAT_T2;?><?php }else{ ?><?php  echo LANGUI_STAT_T13;?><?php } ?></td>
				<td><?php  echo LANGUI_STAT_T23;?></td>
			</tr>
		</thead>
	    <tbody>
	    <?php $_c = 0;?>

	    <?php $counter1=-1; if( isset($top10Result["ATTACK"]) && is_array($top10Result["ATTACK"]) && sizeof($top10Result["ATTACK"]) ) foreach( $top10Result["ATTACK"] as $key1 => $value1 ){ $counter1++; ?>

        <?php $_c = $_c + 1;?>

        <tr<?php if( ($top10Result["TARGETID"] == $value1['id']) ){ ?> class="hl"<?php } ?>>
		    <td class="ra fc"><?php echo $_c;?>&nbsp;</td>
			<td class="pla">
			    <a href="<?php echo $top10Result["URL"];?><?php echo $value1["id"];?>"><?php echo $value1["name"];?></a>
			</td>
			<td class="val lc"><?php echo $value1["points"];?></td>
		</tr>
   		 <?php } ?>

        <tr>
		    <td colspan="3" class="empty"></td>
		</tr>
		<tr class="own hl">
		    <td class="ra fc">?</td>
		    <td class="pla">
		       <a href="<?php echo $top10Result["URL"];?><?php echo $top10Result["TARGETID"];?>"><?php echo $top10Result["TARGETNAME"];?></a>
		    </td>
		    <td class="val lc"><?php echo $top10Result["TARGEPOINT_ATTACK"];?></td>
		</tr>
		</tbody>
	</table>
	<table cellpadding="1" cellspacing="1" id="top10_defs" class="top10 row_table_data">
	    <thead>
		    <tr>
			    <th>
				    <a href="#" onclick="return showManual(6,<?php echo $showManualID;?>);">
					    <img class="help" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo LANGUI_STAT_T43;?>" title="<?php  echo LANGUI_STAT_T43;?>">
					</a>
				</th>
				<th colspan="2"><?php  echo LANGUI_STAT_T45;?></th>
			</tr>
			<tr>
			    <td><?php  echo LANGUI_STAT_T20;?></td>
				<td><?php if( ($selectedTabIndex == 5) ){ ?><?php  echo LANGUI_STAT_T2;?><?php }else{ ?><?php  echo LANGUI_STAT_T13;?><?php } ?></td>
				<td><?php  echo LANGUI_STAT_T23;?></td>
			</tr>
		</thead>
	    <tbody>
	    <?php $_c = 0;?>

	    <?php $counter1=-1; if( isset($top10Result["DEFENSE"]) && is_array($top10Result["DEFENSE"]) && sizeof($top10Result["DEFENSE"]) ) foreach( $top10Result["DEFENSE"] as $key1 => $value1 ){ $counter1++; ?>

	    <?php $_c = $_c + 1;?>

        <tr<?php if( ($top10Result["TARGETID"] == $value1['id']) ){ ?> class="hl"<?php } ?>>
		    <td class="ra fc"><?php echo $_c;?>&nbsp;</td>
			<td class="pla">
			    <a href="<?php echo $top10Result["URL"];?><?php echo $value1["id"];?>"><?php echo $value1["name"];?></a>
			</td>
			<td class="val lc"><?php echo $value1["points"];?></td>
		</tr>
    	<?php } ?>

	    <tr>
		    <td colspan="3" class="empty"></td>
		</tr>
		<tr class="own hl">
		    <td class="ra fc">?</td>
		    <td class="pla">
		       <a href="<?php echo $top10Result["URL"];?><?php echo $top10Result["TARGETID"];?>"><?php echo $top10Result["TARGETNAME"];?></a>
		    </td>
		    <td class="val lc"><?php echo $top10Result["TARGEPOINT_DEFENSE"];?></td>
		</tr>
		</tbody>
	</table>
    <div class="clear"></div>
	<table cellpadding="1" cellspacing="1" id="top10_climbers" class="top10 row_table_data">
	    <thead>
		    <tr>
			    <th>
				    <a href="#" onclick="return showManual(6,<?php echo $showManualID;?>);">
					    <img class="help" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo LANGUI_STAT_T43;?>" title="<?php  echo LANGUI_STAT_T43;?>">
					</a>
				</th>
				<th colspan="2"><?php  echo LANGUI_STAT_T46;?></th>
			</tr>
			<tr>
			    <td><?php  echo LANGUI_STAT_T20;?></td>
				<td><?php if( ($selectedTabIndex == 5) ){ ?><?php  echo LANGUI_STAT_T2;?><?php }else{ ?><?php  echo LANGUI_STAT_T13;?><?php } ?></td>
				<td><?php  echo LANGUI_STAT_T23;?></td>
			</tr>
		</thead>
	    <tbody>
	    <?php $_c = 0;?>

	    <?php $counter1=-1; if( isset($top10Result["DEV"]) && is_array($top10Result["DEV"]) && sizeof($top10Result["DEV"]) ) foreach( $top10Result["DEV"] as $key1 => $value1 ){ $counter1++; ?>

	    <?php $_c = $_c + 1;?>

        <tr<?php if( ($top10Result["TARGETID"] == $value1['id']) ){ ?> class="hl"<?php } ?>>
		    <td class="ra fc"><?php echo $_c;?>&nbsp;</td>
			<td class="pla">
			    <a href="<?php echo $top10Result["URL"];?><?php echo $value1["id"];?>"><?php echo $value1["name"];?></a>
			</td>
			<td class="val lc"><?php echo $value1["points"];?></td>
		</tr>
    	<?php } ?>

	    <tr>
		    <td colspan="3" class="empty"></td>
		</tr>
		<tr class="own hl">
		    <td class="ra fc">?</td>
		    <td class="pla">
		       <a href="<?php echo $top10Result["URL"];?><?php echo $top10Result["TARGETID"];?>"><?php echo $top10Result["TARGETNAME"];?></a>
		    </td>
		    <td class="val lc"><?php echo $top10Result["TARGEPOINT_DEV"];?></td>
		</tr>
		</tbody>
	</table>
	<table cellpadding="1" cellspacing="1" id="top10_raiders" class="top10 row_table_data">
	    <thead>
		    <tr>
			    <th>
				    <a href="#" onclick="return showManual(6,<?php echo $showManualID;?>);">
					    <img class="help" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo LANGUI_STAT_T43;?>" title="<?php  echo LANGUI_STAT_T43;?>">
					</a>
				</th>
				<th colspan="2"><?php  echo LANGUI_STAT_T47;?></th>
			</tr>
			<tr>
			    <td><?php  echo LANGUI_STAT_T20;?></td>
				<td><?php if( ($selectedTabIndex == 5) ){ ?><?php  echo LANGUI_STAT_T2;?><?php }else{ ?><?php  echo LANGUI_STAT_T13;?><?php } ?></td>
				<td><?php  echo LANGUI_STAT_T23;?></td>
			</tr>
		</thead>
	    <tbody>
	    <?php $_c = 0;?>

	    <?php $counter1=-1; if( isset($top10Result["THIEF"]) && is_array($top10Result["THIEF"]) && sizeof($top10Result["THIEF"]) ) foreach( $top10Result["THIEF"] as $key1 => $value1 ){ $counter1++; ?>

	    <?php $_c = $_c + 1;?>

        <tr<?php if( ($top10Result["TARGETID"] == $value1['id']) ){ ?> class="hl"<?php } ?>>
		    <td class="ra fc"><?php echo $_c;?>&nbsp;</td>
			<td class="pla">
			    <a href="<?php echo $top10Result["URL"];?><?php echo $value1["id"];?>"><?php echo $value1["name"];?></a>
			</td>
			<td class="val lc"><?php echo $value1["points"];?></td>
		</tr>
    	<?php } ?>

	    <tr>
		    <td colspan="3" class="empty"></td>
		</tr>
		<tr class="own hl">
		    <td class="ra fc">?</td>
		    <td class="pla">
		       <a href="<?php echo $top10Result["URL"];?><?php echo $top10Result["TARGETID"];?>"><?php echo $top10Result["TARGETNAME"];?></a>
		    </td>
		    <td class="val lc"><?php echo $top10Result["TARGEPOINT_THIEF"];?></td>
		</tr>
		</tbody>
	</table>
<?php } ?>

</body>
</html>