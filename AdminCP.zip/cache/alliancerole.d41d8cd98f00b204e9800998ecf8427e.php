<?php if(!class_exists('raintpl')){exit;}?><!DOCTYPE html>

<html lang="ar">

<head>

    <meta charset="UTF-8">

    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

</head>

<body>
<?php echo load_lang('ui/alliancerole'); ?>

    <h1>
        <img class="point" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="" title=""><?php  echo LANGUI_ALLIROL_T1;?>

	</h1>
	<p></p>
	<form method="post" action="alliancerole?uid=<?php echo get('uid'); ?>">
	    <table cellpadding="1" cellspacing="1" id="position" class="small_option">
		    <thead>
			    <tr>
				    <th colspan="2"><?php  echo LANGUI_ALLIROL_T1;?></th>
				</tr>
			</thead>
			<tbody>
			    <tr>
				    <th><?php  echo LANGUI_ALLIROL_T2;?>:</th>
					<td><?php echo $playerName;?></td>
				</tr>
				<tr>
				    <th><?php  echo LANGUI_ALLIROL_T3;?></th>
				    <td>
				        <input class="name text" type="text" name="a_titel" value="<?php echo $playerRoles["name"];?>" maxlength="20">
				    </td>
			    </tr>
			</tbody>
		</table>
		<p></p>
		<table cellpadding="1" cellspacing="1" id="rights" class="small_option">
		    <thead>
			    <tr>
				    <th colspan="2"><?php  echo LANGUI_ALLIROL_T4;?></th>
				</tr>
			</thead>
			<tbody>
			    <tr>
				    <td class="sel">
					    <input class="check" type="checkbox" name="e1" <?php echo $e1;?>>
					</td>
					<td><?php  echo LANGUI_ALLIROL_T5;?></td>
				</tr>
				<tr>
				    <td class="sel">
					    <input class="check" type="checkbox" name="e2" <?php echo $e2;?>>
					</td>
				    <td><?php  echo LANGUI_ALLIROL_T6;?></td>
				</tr>
				<tr>
				    <td class="sel">
					    <input class="check" type="checkbox" name="e3" <?php echo $e3;?>>
					</td>
					<td><?php  echo LANGUI_ALLIROL_T7;?></td>
				</tr>
				<tr>
				    <td class="sel">
					    <input class="check" type="checkbox" name="e4" <?php echo $e4;?>>
					</td>
					<td><?php  echo LANGUI_ALLIROL_T8;?></td>
				</tr>
				<tr>
				    <td class="sel">
					    <input class="check" type="checkbox" name="e5" <?php echo $e5;?>>
					</td>
				    <td><?php  echo LANGUI_ALLIROL_T9;?></td>
				</tr>
			    <tr>
				    <td class="sel">
					    <input class="check" type="checkbox" name="e6"  <?php echo $e6;?>>
					</td>
					<td><?php  echo LANGUI_ALLIROL_T10;?></td>
				</tr>
			</tbody>
		</table>
		<p>
		    <input type="image" value="ok" name="s1" id="btn_save" class="dynamic_img" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo text_save_lang;?>">
		</p>
	</form>
<?php if( is_post('a_titel') ){ ?>

     <p class="error"><?php  echo text_newssaved_lang;?></p>
<?php } ?>

</body>
</html>