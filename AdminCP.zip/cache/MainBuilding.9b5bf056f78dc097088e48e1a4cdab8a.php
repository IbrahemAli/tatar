<?php if(!class_exists('raintpl')){exit;}?><!DOCTYPE html>

<html lang="ar">

<head>

    <meta charset="UTF-8">

    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

</head>

<body>
<?php echo load_lang('ui/custbuilds'); ?>

  <h2><?php  echo LANGUI_CUSTBU_M_DROP;?>:</h2>
  <p> <?php  echo LANGUI_CUSTBU_M_DROPDESC;?> .</p>

  <?php if( $if_QS_BUILD_DROP ){ ?>

      <table cellpadding="1" cellspacing="1" id="demolish">
        <tbody>
          <tr>
            <td>
              <a href="build?id=<?php echo $buildingIndex;?>&d&qid=<?php echo $qtask["id"];?>&k=<?php echo $data["update_key"];?>">
              <img class="del" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" title="<?php  echo LANGUI_CUSTBU_M_CANCEL;?>" alt="<?php  echo LANGUI_CUSTBU_M_CANCEL;?>">
            </a>
          </td>
          <td>
              <?php echo constant('item_' . $qtask['building_id']); ?>

              ( <?php  echo level_lang;?> <?php echo $proc_params_level;?> )
        </td>
      <td>
      <?php  echo time_remain_lang;?>

      <span id="timer1"><?php echo secondstostring( $qtask["remainingSeconds"] );?></span> 
      <?php  echo time_hour_lang;?>

      </td>
    </tr>
  </tbody>
</table>
  <?php }else{ ?>

      <div id="contract">
        <form class="demolish_building" action="build?id=<?php echo $buildingIndex;?>" method="post" style="display:inline">
      <select name="drbid" class="dropdown">
        <?php $counter1=-1; if( isset($buildings_array) && is_array($buildings_array) && sizeof($buildings_array) ) foreach( $buildings_array as $key1 => $value1 ){ $counter1++; ?>

            <option value="<?php echo $key1;?>"><?php echo $key1;?> <?php if( !$value1 ){ ?><?php  echo LANGUI_CUSTBU_M_EMPTY;?><?php }else{ ?><?php echo $value1;?><?php } ?></option> 
        <?php } ?>

      </select>
	  <input class="check" name="full" value="0" type="checkbox"><b class="none"> ذهبة لكل مستوى <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="gold" alt="<?php  echo text_gold_lang;?>" title="<?php  echo text_gold_lang;?>">كامل</b>
      <input id="btn_demolish" name="ok" class="dynamic_img" type="image" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo LANGUI_CUSTBU_M_DROPBTN;?>">
    </form>
  </div>
<?php if( is_post('full') ){ ?><script>document.location.reload();</script><?php } ?>

  <?php } ?>

</body>
</html>