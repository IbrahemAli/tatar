<?php if(!class_exists('raintpl')){exit;}?><!DOCTYPE html>

<html lang="ar">

<head>

    <meta charset="UTF-8">

    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

</head>

<body>
<?php echo load_lang('ui/village3'); ?>

  
  <?php if( ($pageState == 1) ){ ?>

      <h1>
      <?php  echo LANGUI_VIL3_T1;?>

       (<?php echo $mapItemData["rel_x"];?>|<?php echo $mapItemData["rel_y"];?>)</h1>
      <?php $mdist      = $setupMetadata['field_maps_summary'][$mapItemData['field_maps_id']];?>

      <?php $mdistArray = explode("-", $mdist);?>

      <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" id="detailed_map" class="f<?php echo $mapItemData["field_maps_id"];?>" alt="<?php echo $mdist;?>" title="<?php echo $mdist;?>">
      <div id="map_details">
        <table cellpadding="1" cellspacing="1" id="distribution" class="tableNone">
          <thead>
            <tr>
              <th colspan="3"><?php  echo LANGUI_VIL3_T2;?>:</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td class="ico">
                <img class="r1" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo item_title_1;?>" title="<?php  echo item_title_1;?>">
              </td>
              <td class="val"><?php echo $mdistArray["0"];?></td>
              <td class="desc"><?php  echo LANGUI_VIL3_T3;?></td>
            </tr>
            <tr>
              <td class="ico">
                <img class="r2" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo item_title_2;?>" title="<?php  echo item_title_2;?>">
              </td>
              <td class="val"><?php echo $mdistArray["1"];?></td>
              <td class="desc"><?php  echo LANGUI_VIL3_T4;?></td>
            </tr>
            <tr>
              <td class="ico">
                <img class="r3" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo item_title_3;?>" title="<?php  echo item_title_3;?>">
              </td>
              <td class="val"><?php echo $mdistArray["2"];?></td>
              <td class="desc"><?php  echo LANGUI_VIL3_T5;?></td>
            </tr>
            <tr>
              <td class="ico">
                <img class="r4" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo item_title_4;?>" title="<?php  echo item_title_4;?>">
              </td>
              <td class="val"><?php echo $mdistArray["3"];?></td>
              <td class="desc"><?php  echo LANGUI_VIL3_T6;?></td>
            </tr>
          </tbody>
        </table>
      </div>
      <table cellpadding="1" cellspacing="1" id="options" class="tableNone">
        <thead>
          <tr>
            <th><?php  echo LANGUI_VIL3_T7;?>:</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>
              <a href="map?id=<?php echo $mapItemData["id"];?>"><?php  echo LANGUI_VIL3_T8;?></a>
            </td>
          </tr>

      <?php if( !$builderTroopId ){ ?>

          <tr>
            <td><a href="v2v?id=<?php echo $mapItemData["id"];?>"><?php  echo LANGUI_VIL3_T9;?></a></td>
          </tr>
      <?php }else{ ?>

          <tr>
            <td class="none"><?php  echo LANGUI_VIL3_T9;?> (<?php echo $builderTroopId;?> <?php  echo LANGUI_VIL3_T10;?>)</td>
        </tr>
      <?php } ?>

	     <tr>
            <td>
              <a href="farm?t=1&x=<?php echo $mapItemData["rel_x"];?>&y=<?php echo $mapItemData["rel_y"];?>" <?php if( !$active_plus_account ){ ?> onclick="return showManual(5,0);"<?php } ?>><?php  echo LANGUI_VIL3_T35;?></a>
            </td>
          </tr>
      </tbody>
    </table>
  <?php }elseif( ($pageState == 2) ){ ?>

      <h1>
        <div><?php echo $mapItemData["village_name"];?></div>&nbsp;
        (<?php echo $mapItemData["rel_x"];?> |<?php echo $mapItemData["rel_y"];?>)</h1>
        
        <?php if( ($mapItemData['is_capital']) ){ ?>

            <div id="dmain">(<?php  echo LANGUI_VIL3_T11;?>)</div>
        <?php } ?>

      <?php $mdist      = $setupMetadata['field_maps_summary'][$mapItemData['field_maps_id']];?>

      <?php $mdistArray = explode("-", $mdist);?>

      <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" id="detailed_map" class="f<?php echo $mapItemData["field_maps_id"];?>" alt="<?php echo $mdist;?>" title="<?php echo $mdist;?>">
      <div id="map_details">
        <table cellpadding="1" cellspacing="1" id="village_info" class="tableNone">
        <tbody>
          <tr>
            <th><?php  echo LANGUI_VIL3_T12;?>:</th>
            <td><?php echo constant('tribe_' . $mapItemData['tribe_id']); ?></td>
          </tr>
          <tr>
            <th><?php  echo LANGUI_VIL3_T13;?>:</th>
            <td>
            <?php if( (0 < intval($mapItemData['alliance_id'])) ){ ?>

                <a href="alliance?id=<?php echo $mapItemData["alliance_id"];?>"><?php echo $mapItemData["alliance_name"];?></a>
            <?php } ?>

            </td>
          </tr>
          <tr>
            <th><?php  echo LANGUI_VIL3_T14;?>:</th>
            <td>
              <a href="profile?uid=<?php echo $mapItemData["player_id"];?>"><?php echo $mapItemData["player_name"];?></a>
            </td>
          </tr>
          <tr>
            <th><?php  echo LANGUI_VIL3_T15;?>:</th>
            <td><?php echo $mapItemData["people_count"];?></td>
          </tr>
        </tbody>
      </table>
      <table cellpadding="1" cellspacing="1" id="troop_info" class="tableNone rep">
        <thead>
          <tr>
            <th><?php  echo LANGUI_VIL3_T16;?>:</th>
          </tr>
        </thead>
        <tbody>
                <?php $counter1=-1; if( isset($lastReport) && is_array($lastReport) && sizeof($lastReport) ) foreach( $lastReport as $key1 => $value1 ){ $counter1++; ?>

                  <?php $isAttack          = $value1['isAttack'];?>

                  <?php $rptRelativeResult = ReportHelper::getreportresultrelative($value1['rpt_result'], $isAttack);?>

                  <?php $btext             = ReportHelper::getreportresulttext($rptRelativeResult);?>

                  <?php $_rptResultCss     = $rptRelativeResult == 100 ? 10 : $rptRelativeResult;?>

                  <tr>
                    <td>
                      <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="iReport iReport<?php echo $_rptResultCss;?>" alt="<?php echo $btext;?>" title="<?php echo $btext;?>">  
                      <a href="report?id=<?php echo $value1["id"];?>" title="<?php echo $value1["mtime"];?>"><?php echo $value1["mdate"];?></a>
                    </td>
                  </tr>
                <?php } ?>

                <?php if( ($counter1 == -1) ){ ?>

                <tr>
                  <td><?php  echo LANGUI_VIL3_T17;?></td>
                </tr>
                <?php } ?>

      </tbody>
    </table>
  </div>
  <table cellpadding="1" cellspacing="1" id="options" class="tableNone">
    <thead>
      <tr>
        <th>
          <?php  echo LANGUI_VIL3_T7;?> :
        </th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>
          <a href="map?id=<?php echo $mapItemData["id"];?>"><?php  echo LANGUI_VIL3_T8;?></a>
        </td>
      </tr>
  <?php if( ($mapItemData['id'] != $data['selected_village_id']) ){ ?>

          
      <?php if( ($hasRallyPoint) ){ ?>

      <tr>
        <?php if( ($mapItemData['playerType'] == PLAYERTYPE_ADMIN) ){ ?>

        <td class="none">
          <?php  echo LANGUI_VIL3_T18;?>

              <?php }else{ ?>

          <td>
            <a href="v2v?id=<?php echo $mapItemData["id"];?>"><?php  echo LANGUI_VIL3_T19;?></a>
            <?php } ?>

          </td>
        </tr>
        <?php }else{ ?>

        <tr>
          <td class="none"><?php  echo LANGUI_VIL3_T20;?></td>
        </tr>
        <?php } ?>

          
        <?php if( ($hasMarketplace) ){ ?>

        <tr>
          <?php if( ($mapItemData['playerType'] == PLAYERTYPE_ADMIN) ){ ?>

          <td class="none">
            <?php  echo LANGUI_VIL3_T21;?>

              <?php }else{ ?>

            <td>
              <a class="" href="build?bid=17&vid2=<?php echo $mapItemData["id"];?>"><?php  echo LANGUI_VIL3_T22;?></a>
              <?php } ?>

            </td>
          </tr>
          <?php }else{ ?>

          <tr>
            <td class="none"><?php  echo LANGUI_VIL3_T23;?></td>
          </tr>
          <?php } ?>

      <?php } ?>

	  <tr>
            <td>
              <a href="farm?t=1&x=<?php echo $mapItemData["rel_x"];?>&y=<?php echo $mapItemData["rel_y"];?>" <?php if( !$active_plus_account ){ ?> onclick="return showManual(5,0);"<?php } ?>><?php  echo LANGUI_VIL3_T35;?></a>
            </td>
          </tr>
        </tbody>
      </table>
  <?php }elseif( ($pageState == 3) ){ ?>

      <h1>
          <?php  echo LANGUI_VIL3_T24;?>

         (<?php echo $mapItemData["rel_x"];?>|<?php echo $mapItemData["rel_y"];?>)
        
        <?php if( ($mapItemData['player_id'] == $player->playerId && $mapItemData['allegiance_percent'] < 100) ){ ?>

            <div id="loyality" class="<?php if( $mapItemData['allegiance_percent'] <= 60  ){ ?> re <?php }else{ ?> gr <?php } ?>">
              <?php  echo LANGUI_VIL3_T25;?> <?php echo $mapItemData["allegiance_percent"];?> %
            </div>
        <?php } ?>

      </h1>
      <?php $oid = $setupMetadata['oasis'][$mapItemData['image_num']];?>

      <?php $str = "";?>

      <?php $counter1=-1; if( isset($oid) && is_array($oid) && sizeof($oid) ) foreach( $oid as $key1 => $value1 ){ $counter1++; ?>

          <?php if( ($str != '') ){ ?>

              <?php $str = $str .  PHP_EOL . ' ' . text_and_lang ;?> 
          <?php } ?>

          <?php $str = $str .  LANGUI_VIL3_T26 . ' ' . constant('item_title_' . $key1) . ' ' . $value1 . '%';?>

      <?php } ?>

      <?php $str = $str . '' . LANGUI_VIL3_T27;?>

      <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" id="detailed_map" class="w<?php echo $mapItemData["image_num"];?>" alt="<?php echo $str;?>" title="<?php echo $str;?>">
        <div id="map_details">
          <table cellpadding="1" cellspacing="1" id="village_info" class="tableNone">
            <tbody>
              <tr>
                <th>
                  <?php  echo LANGUI_VIL3_T12;?> :
                </th>
                <td><?php echo constant('tribe_' . $mapItemData['tribe_id']); ?></td>
              </tr>
              <tr>
                <th>
                  <?php  echo LANGUI_VIL3_T13;?> :
                </th>
                <td>
                  <?php if( (0 < intval($mapItemData['alliance_id'])) ){ ?>

                    <a href="alliance?id=<?php echo $mapItemData["alliance_id"];?>">
                        <?php echo $mapItemData["alliance_name"];?>

                    </a>
                  <?php } ?>

                  </td>
                </tr>
                <tr>
                  <th>
                    <?php  echo LANGUI_VIL3_T14;?> :
                  </th>
                  <td>
                    <a href="profile?uid=<?php echo $mapItemData["player_id"];?>"><?php echo $mapItemData["player_name"];?></a>
                  </td>
                </tr>
                <tr>
                  <th>
                    <?php  echo LANGUI_VIL3_T28;?> :
                  </th>
                  <td>
                    <a href="village3?id=<?php echo $mapItemData["parent_id"];?>">
                        <?php echo $mapItemData["village_name"];?>

                    </a>
                  </td>
                </tr>
              </tbody>
            </table>
            <table cellpadding="1" cellspacing="1" id="troop_info" class="tableNone rep">
              <thead>
                <tr>
                  <th>
                    <?php  echo LANGUI_VIL3_T16;?> :
                  </th>
                </tr>
              </thead>
              <tbody>
                <?php $counter1=-1; if( isset($lastReport) && is_array($lastReport) && sizeof($lastReport) ) foreach( $lastReport as $key1 => $value1 ){ $counter1++; ?>

                  <?php $isAttack          = $value1['isAttack'];?>

                  <?php $rptRelativeResult = ReportHelper::getreportresultrelative($value1['rpt_result'], $isAttack);?>

                  <?php $btext             = ReportHelper::getreportresulttext($rptRelativeResult);?>

                  <?php $_rptResultCss     = $rptRelativeResult == 100 ? 10 : $rptRelativeResult;?>

                  <tr>
                    <td>
                      <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="iReport iReport<?php echo $_rptResultCss;?>" alt="<?php echo $btext;?>" title="<?php echo $btext;?>">  
                      <a href="report?id=<?php echo $value1["id"];?>" title="<?php echo $value1["mtime"];?>"><?php echo $value1["mdate"];?></a>
                    </td>
                  </tr>
                <?php } ?>

                <?php if( ($counter1 == -1) ){ ?>

                <tr>
                  <td><?php  echo LANGUI_VIL3_T17;?></td>
                </tr>
                <?php } ?>

              </tbody>
            </table>
          </div>
          <table cellpadding="1" cellspacing="1" id="options" class="tableNone">
            <thead>
              <tr>
                <th>
                  <?php  echo LANGUI_VIL3_T7;?> :
                </th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>
                  <a href="map?id=<?php echo $mapItemData["id"];?>"><?php  echo LANGUI_VIL3_T8;?></a>
                </td>
              </tr>
              
              <?php if( ($hasRallyPoint) ){ ?>

              <tr>
                <?php if( ($mapItemData['playerType'] == PLAYERTYPE_ADMIN) ){ ?>

                <td class="none">
                  <?php  echo LANGUI_VIL3_T18;?>

                <?php }else{ ?>

                  <td>
                    <a href="v2v?id=<?php echo $mapItemData["id"];?>"><?php  echo LANGUI_VIL3_T19;?></a>
                <?php } ?>

                  </td>
                </tr>
              <?php }else{ ?>

                <tr>
                  <td class="none"><?php  echo LANGUI_VIL3_T20;?></td>
                </tr>
                <?php } ?>

				<tr>
                    <td>
                    <a href="farm?t=1&x=<?php echo $mapItemData["rel_x"];?>&y=<?php echo $mapItemData["rel_y"];?>" <?php if( !$active_plus_account ){ ?> onclick="return showManual(5,0);"<?php } ?>><?php  echo LANGUI_VIL3_T35;?></a>
                    </td>
                </tr>
              </tbody>
            </table>

        <?php }elseif( ($pageState == 4) ){ ?>

            <h1><?php  echo LANGUI_VIL3_T29;?> (<?php echo $mapItemData["rel_x"];?>|<?php echo $mapItemData["rel_y"];?>)</h1>
            
            <?php $oid            = $setupMetadata['oasis'][$mapItemData['image_num']];?>

            <?php $str            = '';?>

            <?php $formatedString = '';?>

            <?php $counter1=-1; if( isset($oid) && is_array($oid) && sizeof($oid) ) foreach( $oid as $key1 => $value1 ){ $counter1++; ?>

                <?php if( ($str != '') ){ ?>

                    <?php $str = $str .  PHP_EOL . ' ' . text_and_lang;?>

                <?php } ?>

                <?php $curString = LANGUI_VIL3_T26 . ' ' . constant('item_title_' . $key1) . ' ' . $value1 . '%';?>

                <?php $str = $str . $curString;?>

                <?php $formatedString = $formatedString . '<li>' . $curString . ' ' . LANGUI_VIL3_T27 . '</li>';?>

              <?php } ?>

            <?php $str = $str . ' ' . LANGUI_VIL3_T27;?>

            <?php $formatedString = '<ul>' . $formatedString . '</ul>';?>

            <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" id="detailed_map" class="w<?php echo $mapItemData["image_num"];?>" alt="<?php echo $str;?>" title="<?php echo $str;?>">
                  <div id="map_details">
                    <table cellpadding="1" cellspacing="1" id="troop_info" class="tableNone">
                      <thead>
                        <tr>
                          <th colspan="3">
                            <?php  echo LANGUI_VIL3_T30;?> :
                          </th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php $counter1=-1; if( isset($itemTroops) && is_array($itemTroops) && sizeof($itemTroops) ) foreach( $itemTroops as $key1 => $value1 ){ $counter1++; ?>

                          <?php if( $value1 >= 0 ){ ?>

                              <tr>
                                  <td class="ico">
                                    <img class="unit u<?php echo $key1;?>" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php echo constant('troop_' . $key1); ?>" title="<?php echo constant('troop_' . $key1); ?>">
                                  </td>
                                  <td class="val"><?php echo $value1;?></td>
                                  <td class="desc"><?php echo constant('troop_' . $key1); ?></td>
                              </tr>
                          <?php } ?>

                        <?php } ?>

            
                        <?php if( ($counter1 == -1) ){ ?>

                        <tr>
                          <td><?php  echo LANGUI_VIL3_T31;?></td>
                        </tr>
                        <?php } ?>

                      </tbody>
                    </table>
                    <table cellpadding="1" cellspacing="1" id="troop_info" class="tableNone">
                      <thead>
                        <tr>
                          <th>
                            <?php  echo LANGUI_VIL3_T32;?> :
                          </th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td><?php echo $formatedString;?></td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                  <table cellpadding="1" cellspacing="1" id="options" class="tableNone">
                    <thead>
                      <tr>
                        <th>
                          <?php  echo LANGUI_VIL3_T7;?> :
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td>
                          <a href="map?id=<?php echo $mapItemData["id"];?>"><?php  echo LANGUI_VIL3_T8;?></a>
                        </td>
                      </tr>
                      <?php if( ($hasRallyPoint) ){ ?>

                      <tr>
                        <td>
                          <a href="v2v?id=<?php echo $mapItemData["id"];?>"><?php  echo LANGUI_VIL3_T33;?></a>
                        </td>
                      </tr>
                      <?php }else{ ?>

                      <tr>
                        <td class="none"><?php  echo LANGUI_VIL3_T34;?></td>
                      </tr>
                      <?php } ?>

					  <tr>
                        <td>
                           <a href="farm?t=1&x=<?php echo $mapItemData["rel_x"];?>&y=<?php echo $mapItemData["rel_y"];?>" <?php if( !$active_plus_account ){ ?> onclick="return showManual(5,0);"<?php } ?>><?php  echo LANGUI_VIL3_T35;?></a>
                        </td>
                      </tr>
                    </tbody>
                  </table>
        <?php } ?>

</body>
</html>