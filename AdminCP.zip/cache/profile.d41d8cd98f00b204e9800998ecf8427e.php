<?php if(!class_exists('raintpl')){exit;}?><!DOCTYPE html>

<html lang="ar">

<head>

    <meta charset="UTF-8">

    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

</head>

<body>
<?php echo load_lang('ui/profile'); ?>

<h1><?php  echo LANGUI_PROFILE_T1;?></h1>
<br />
<?php if( ($fullView) ){ ?>

    <div id="textmenu">
        <a href="profile" <?php if( $selectedTabIndex == 0 ){ ?> class="selected" <?php } ?>><?php  echo LANGUI_PROFILE_T2;?></a> |
        <a href="profile?t=1" <?php if( $selectedTabIndex == 1 ){ ?> class="selected" <?php } ?>><?php  echo LANGUI_PROFILE_T3;?></a> |
        <a href="profile?t=2" <?php if( $selectedTabIndex == 2 ){ ?> class="selected" <?php } ?>><?php  echo LANGUI_PROFILE_T4;?></a> |
        <a href="profile?t=3" <?php if( $selectedTabIndex == 3 ){ ?> class="selected" <?php } ?>><?php  echo LANGUI_PROFILE_T5;?></a>
        <?php if( ($data['player_type'] != PLAYERTYPE_TATAR ) ){ ?>

           | <a href="profile?t=4" <?php if( $selectedTabIndex == 4 ){ ?> class="selected" <?php } ?>><?php  echo LANGUI_PROFILE_T6;?></a>
        <?php } ?>

           | <a href="profile?t=5"<?php if( !$active_plus_account ){ ?> onclick="return showManual(5,0);"<?php } ?> <?php if( $selectedTabIndex == 5 ){ ?> class="selected" <?php } ?>><?php  echo LANGUI_LNKS_T1;?></a>
        | <a href="profile?t=6" <?php if( $selectedTabIndex == 6 ){ ?> class="selected" <?php } ?>><?php  echo LANGUI_PROFILE_T75;?></a>
    </div>
<?php } ?>

<?php if( ($selectedTabIndex == 0) ){ ?>

    <script type="text/javascript">
        function getMouseCoords(e) {
            var coords = {};
            if (!e) var e = window.event;
            if (e.pageX || e.pageY) {
                coords.x = e.pageX;
                coords.y = e.pageY;
            }
            else if (e.clientX || e.clientY) {
                coords.x = e.clientX + document.body.scrollLeft + document.documentElement.scrollLeft;
                coords.y = e.clientY + document.body.scrollTop + document.documentElement.scrollTop;
            }
            return coords;
        }
        function med_mouseMoveHandler(e, desc_string) {
            var coords = getMouseCoords(e);
            var layer = _("medal_mouseover");
            layer.style.top = (coords.y + 25) + "px";
            layer.style.left = (coords.x - 20) + "px";
            layer.className = "";
            layer.innerHTML  = desc_string;
        }
        function med_closeDescription(){
            var layer = _("medal_mouseover");
            layer.className = "hide";
        }
        layer = document.createElement("div");
        layer.id = "medal_mouseover";
        layer.className = "hide";
        document.body.appendChild(layer);
    </script>
    <table id="profile" cellpadding="1" cellspacing="1">
        <thead>
            <tr>
                <th colspan="2"><?php  echo LANGUI_PROFILE_T7;?> <?php echo $profileData["name"];?>

                    <?php if( (((isset($profileData['is_blocked']) && $profileData['is_blocked'] == 1 ) or $profileData['blocked_second'] > 0)) ){ ?>

                    <font color="#990000"><?php  echo LANGUI_PROFILE_T70;?></font>
                    <?php } ?>

                </th>
            </tr>
            <tr>
                <td><?php  echo LANGUI_PROFILE_T8;?> :</td>
                <td><?php  echo LANGUI_PROFILE_T9;?> :</td>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td class="empty"></td>
                <td class="empty"></td>
            </tr>
            <tr>
                <td class="details">
                    <table cellpadding="0" cellspacing="0">
                        <tbody>
                            <tr>
                                <th><?php  echo LANGUI_PROFILE_T10;?> :</th>
                                <td><?php echo $profileData["rank"];?></td>
                            </tr>
                            <tr>
                                <th><?php  echo LANGUI_PROFILE_T11;?> :</th>
                                <td><?php echo constant('tribe_'.$profileData['tribe_id']); ?></td>
                            </tr>
                            <tr>
                                <th><?php  echo LANGUI_PROFILE_T12;?> :</th>
                                <td><?php if( (0 < intval($profileData['alliance_id'])) ){ ?>

                                    <a href="alliance?id=<?php echo $profileData["alliance_id"];?>"><?php echo $profileData["alliance_name"];?></a>
                                    <?php }else{ ?> - <?php } ?>

                                </td>
                            </tr>
                            <tr>
                                <th><?php  echo LANGUI_PROFILE_T13;?></th>
                                <td><?php echo $villagesCount;?></td>
                            </tr>
                            <tr>
                                <th><?php  echo LANGUI_PROFILE_T14;?> :</th>
                                <td><?php echo $profileData["total_people_count"];?></td>
                            </tr>
                            <?php if( (0 < $profileData['age']) ){ ?>

                            <tr>
                                <th><?php  echo LANGUI_PROFILE_T15;?> :</th>
                                <td><?php echo $profileData["age"];?></td>
                            </tr>
                            <?php } ?>

                            <?php if( (0 < $profileData['gender']) ){ ?>

                            <tr>
                                <th><?php  echo LANGUI_PROFILE_T16;?> :</th>
                                <td><?php if( $profileData['gender'] == 1 ){ ?> <?php  echo LANGUI_PROFILE_T17;?> <?php }else{ ?> <?php  echo LANGUI_PROFILE_T18;?> <?php } ?></td>
                            </tr>
                            <?php } ?>


                            <?php if( ( htmlspecialchars( $profileData['house_name'] ) != '' ) ){ ?>

                                <tr>
                                    <th><?php  echo LANGUI_PROFILE_T19;?> :</th>
                                    <td><?php echo htmlspecialchars( $profileData["house_name"] );?></td>
                                </tr>
                            <?php } ?>


                            <?php if( ($profileData['tribe_id'] != 5 ) ){ ?>

                                <tr>
                                    <td colspan="2" class="empty"></td>
                                </tr>
                                <tr>
                                    <td colspan="2">
                                        <?php if( ( !$player->isAgent ) ){ ?>

                                            <?php if( ( $fullView ) ){ ?>

                                                <a href="profile?t=1"><?php  echo LANGUI_PROFILE_T20;?></a>
                                            <?php }elseif( $isfriend > 0 ){ ?>

                                                <a href="javascript:void(0)" onclick="javascript:jqcc.cometchat.chatWith(<?php echo $profileData["id"];?>);">
                                                <?php  echo LANGUI_PROFILE_T21;?>

                                                </a>
                                            <?php }elseif( $isisend > 0 ){ ?>

                                            <a href="friends?t=2&deto=<?php echo $profileData["id"];?>">
                                                <?php  echo LANGUI_PROFILE_T90;?>

                                                </a>
                                            <?php }elseif( $issend > 0 ){ ?>

                                            <a href="friends?t=1&from=<?php echo $profileData["id"];?>">
                                                <?php  echo LANGUI_PROFILE_T91;?>

                                                </a>
                                            <?php }else{ ?>

                                            <a href="friends?t=2&id=<?php echo $profileData["id"];?>">
                                                <?php  echo LANGUI_PROFILE_T92;?>

                                            </a>
                                            <?php } ?>

                                        <?php } ?>

                                    </td>
                                </tr>
                            <?php } ?>

                            <?php if( !$fullView ){ ?>

                                <tr>
                                    <td colspan="2"><a href="profile?block&uid=<?php echo $profileData["id"];?>"><?php if( $isblock ){ ?><?php  echo LANGUI_PROFILE_T88;?><?php }else{ ?><?php  echo LANGUI_PROFILE_T87;?><?php } ?></a></td>
                                </tr>
                            <?php } ?>

                            <?php if( ( ($isAdmin || $isHunter) && $player->playerId != $profileData['id'] && $profileData['id'] != 1 ) ){ ?>

                                <tr>
                                    <td colspan="2">
                                        <form action="profile?spy&uid=<?php echo $profileData["id"];?>" method="POST">
                                            <input class="text" type="text" name="spybass" value="" />
                                        </form>
                                    </td>
                                </tr>
                            <?php } ?>


                            <tr>
                                <td colspan="2" class="empty"></td>
                            </tr>
                            <tr>
                                <td colspan="2" class="desc2">
                                    <div class="desc2div"><?php echo $getProfileDescription_2;?></div>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </td>
                <td class="desc1"><div><?php echo $getProfileDescription;?></div></td>
            </tr>
        </tbody>
    </table>
    <table cellpadding="1" cellspacing="1" id="villages">
        <thead>
            <tr>
                <th colspan="5"><?php  echo LANGUI_PROFILE_T13;?></th>
            </tr>
            <tr>
                <td><?php  echo LANGUI_PROFILE_T23;?></td>
                <td><?php  echo LANGUI_PROFILE_T73;?></td>
                <td><?php  echo LANGUI_PROFILE_T74;?></td>
                <td><?php  echo LANGUI_PROFILE_T14;?></td>
                <td><?php  echo LANGUI_PROFILE_T24;?></td>
            </tr>
        </thead>
    <tbody>
    <?php $counter1=-1; if( isset($villages) && is_array($villages) && sizeof($villages) ) foreach( $villages as $key1 => $value1 ){ $counter1++; ?>

        <tr>
        <td class="nam">
            <a href="village3?id=<?php echo $value1["id"];?>"><?php echo $value1["village_name"];?></a>
            <?php if( ( $value1['is_capital'] ) ){ ?>

            <span class="none3">(<?php  echo LANGUI_PROFILE_T25;?>)</span>
            <?php } ?>

        </td>
        <td>
            <a href="build?bid=17&vid2=<?php echo $value1["id"];?>">
                <img src="<?php echo add_style('6.gif', ASSETS_DIR.'/default/img/r/'); ?>">
            </a>
        </td>
        <td>
            <a href="v2v?id=<?php echo $value1["id"];?>"><img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="att_all"></a>
        </td>
        <td class="hab"><?php echo $value1["people_count"];?></td>
        <td class="aligned_coords">
            <div class="cox">(<?php echo $value1["rel_x"];?></div>
            <div class="pi">|</div>
            <div class="coy"><?php echo $value1["rel_y"];?>)</div>
        </td>
        </tr>
    <?php } ?>

    </tbody>
    </table>
<?php }elseif( ( $selectedTabIndex == 1 ) ){ ?>

    <form action="profile?t=1" enctype="multipart/form-data" method="POST">
    <input type="hidden" name="e" value="1" />
    <table cellpadding="1" cellspacing="1" id="edit" class="vip">
    <thead>
    <tr>
    <th colspan="3">
        <?php  echo LANGUI_PROFILE_T7;?>

        <?php echo $profileData["name"];?>

    </th>
    </tr>
    <tr>
    <td colspan="2">
    <?php  echo LANGUI_PROFILE_T8;?> :
    </td>
    <td>
    <?php  echo LANGUI_PROFILE_T9;?> :
    </td>
    </tr>
    </thead>
    <tbody>
    <tr>
    <td colspan="2" class="empty"></td>
    <td class="empty"></td>
    </tr>
    <tr>
    <th><?php  echo LANGUI_PROFILE_T26;?> :</th>
    <td class="birth">
    <input tabindex="3" type="text" name="jahr" value="<?php if( ( 0 < $birthDate['year'] ) ){ ?><?php echo $birthDate["year"];?><?php } ?>" maxlength="4" class="text year">
    <select tabindex="2" name="monat" size="0" class="dropdown">
        <option value="0"></option>
        <option value="1" <?php if( ( $birthDate['month'] == 1 ) ){ ?>selected="selected"<?php } ?> ><?php  echo LANGUI_PROFILE_T27;?></option>
        <option value="2" <?php if( ( $birthDate['month'] == 2 ) ){ ?> selected="selected"<?php } ?> ><?php  echo LANGUI_PROFILE_T28;?></option>
        <option value="3" <?php if( ( $birthDate['month'] == 3 ) ){ ?> selected="selected"<?php } ?> ><?php  echo LANGUI_PROFILE_T29;?></option>
        <option value="4" <?php if( ( $birthDate['month'] == 4 ) ){ ?> selected="selected"<?php } ?> ><?php  echo LANGUI_PROFILE_T30;?></option>
        <option value="5" <?php if( ( $birthDate['month'] == 5 ) ){ ?> selected="selected"<?php } ?> ><?php  echo LANGUI_PROFILE_T31;?></option>
        <option value="6" <?php if( ( $birthDate['month'] == 6 ) ){ ?> selected="selected"<?php } ?> ><?php  echo LANGUI_PROFILE_T32;?></option>
        <option value="7" <?php if( ( $birthDate['month'] == 7 ) ){ ?> selected="selected"<?php } ?> ><?php  echo LANGUI_PROFILE_T33;?></option>
        <option value="8" <?php if( ( $birthDate['month'] == 8 ) ){ ?> selected="selected"<?php } ?> ><?php  echo LANGUI_PROFILE_T34;?></option>
        <option value="9" <?php if( ( $birthDate['month'] == 9 ) ){ ?> selected="selected"<?php } ?> ><?php  echo LANGUI_PROFILE_T35;?></option>
        <option value="10" <?php if( ( $birthDate['month'] == 10 ) ){ ?> selected="selected"<?php } ?> ><?php  echo LANGUI_PROFILE_T36;?></option>
        <option value="11" <?php if( ( $birthDate['month'] == 11 ) ){ ?> selected="selected"<?php } ?> ><?php  echo LANGUI_PROFILE_T37;?></option>
        <option value="12" <?php if( ( $birthDate['month'] == 12 ) ){ ?> selected="selected"<?php } ?> ><?php  echo LANGUI_PROFILE_T38;?></option>
    </select>
    <input tabindex="1" class="text day" type="text" name="tag" value="<?php if( ( 0 < $birthDate['day'] ) ){ ?><?php echo $birthDate["day"];?><?php } ?>" maxlength="2">
    </td>
    <td rowspan="8" class="desc1">
        <textarea tabindex="7" name="be1"><?php echo $profileData["description1"];?></textarea>
    </td>
    </tr>
    <tr>
    <th>
    <?php  echo LANGUI_PROFILE_T16;?> :
    </th>
    <td class="gend">
    <label>
        <input class="radio" type="radio" name="mw" value="0" <?php if( ( $profileData['gender'] == 0 ) ){ ?>checked="" tabindex="4"<?php } ?>>
        <?php  echo LANGUI_PROFILE_T39;?>

    </label>
    <label>
        <input class="radio" type="radio" name="mw" value="1" <?php if( ( $profileData['gender'] == 1 ) ){ ?>checked="" tabindex="4"<?php } ?> >
    <?php  echo LANGUI_PROFILE_T40;?>

    </label>
    <label>
        <input class="radio" type="radio" name="mw" value="2" <?php if( ( $profileData['gender'] == 2 ) ){ ?>checked="" tabindex="4"<?php } ?> >
    <?php  echo LANGUI_PROFILE_T41;?>

    </label>
    </td>
    </tr>
    <tr>
    <th>
    <?php  echo LANGUI_PROFILE_T19;?> :
    </th>
    <td>
        <input tabindex="5" type="text" name="ort" value="<?php echo htmlspecialchars($profileData['house_name'] ); ?>" maxlength="30" class="text" />
    </td>
    </tr>
    <tr>
    <td colspan="2" class="empty"></td>
    </tr>
    <tr>
    <th> <?php  echo LANGUI_PROFILE_T42;?> : </th>
    <td>
        <input tabindex="6" type="text" name="dname" value="<?php echo htmlspecialchars($profileData['village_name'] ); ?>" maxlength="20" class="text" />
    </td>
    </tr>
    <tr>
    <td colspan="2" class="empty"></td>
    </tr>
    <tr>
    <td colspan="2" class="desc2"><textarea tabindex="8" name="be2"><?php echo $profileData["description2"];?></textarea></td>
    </tr>
    </tbody>
    </table>
    <table cellpadding="1" cellspacing="1" id="medals">
    <thead>
    <tr>
    <th colspan="5"><?php  echo LANGUI_PROFILE_T43;?></th>
    </tr>
    <tr>
    <td><?php  echo LANGUI_PROFILE_T44;?></td>
    <td><?php  echo LANGUI_PROFILE_T45;?></td>
    <td><?php  echo LANGUI_PROFILE_T46;?></td>
    <td><?php  echo profile_medal_txt_points;?></td>
    <td><?php  echo LANGUI_PROFILE_T47;?></td>
    </tr>
    </thead>
    <tbody>
        <?php $counter1=-1; if( isset($medals) && is_array($medals) && sizeof($medals) ) foreach( $medals as $key1 => $value1 ){ $counter1++; ?>

            <tr>
                <td class="typ"><?php echo $value1["textIndex"];?></td>
                <td class="ra"><?php echo $value1["rank"];?></td>
                <td class="we"><?php echo $value1["week"];?></td>
                <td class="we"><?php echo $value1["points"];?></td>
                <td class="bb">[#<?php echo $value1["bb"];?>]</td>
            </tr>
        <?php } ?>

    </tbody>
    </table>
    <?php if( $_POST && $errorTable != NULL ){ ?>

        <p class="error">
        <?php echo $errorTable;?>

        </p>
    <?php } ?>

    <p class="btn">
        <input type="image" value="" tabindex="9" name="s1" id="btn_ok" class="dynamic_img" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo text_okdone_lang;?>">
    </p>
    </form>
<?php }elseif( ( $selectedTabIndex == 2 ) ){ ?>

    <form action="profile?t=2" method="POST">
    <input type="hidden" name="e" value="2">
    <table cellpadding="1" cellspacing="1" id="change_mail" class="account">
    <thead>
    <tr>
    <th colspan="2"><?php  echo LANGUI_PROFILE_T48;?></th>
    </tr>
    </thead>
    <tbody>
    <tr>
    <td class="note" colspan="2"><?php  echo LANGUI_PROFILE_T49;?></td>
    </tr>
    <tr>
    <th><?php  echo LANGUI_PROFILE_T50;?> :</th>
    <td><input class="text" type="password" name="pw1" maxlength="20"></td>
    </tr>
    <tr>
    <th><?php  echo LANGUI_PROFILE_T51;?> :</th>
    <td>
        <input class="text" type="password" name="pw2" maxlength="20"></td>
    </tr>
    <tr>
    <th><?php  echo LANGUI_PROFILE_T51;?> :</th>
    <td>
        <input class="text" type="password" name="pw3" maxlength="20">
    </td>
    </tr>
    </tbody>
    </table>
    <?php if( $_POST && $errorTable != NULL ){ ?>

        <p class="error">
        <?php echo $errorTable;?>

        </p>
    <?php } ?>

    <table cellpadding="1" cellspacing="1" id="change_mail" class="account">
    <thead>
    <tr>
    <th colspan="2"><?php  echo LANGUI_PROFILE_T52;?></th>
    </tr>
    </thead>
    <tbody>
    <tr>
    <td class="note" colspan="2"><?php  echo LANGUI_PROFILE_T53;?></td>
    </tr>
    <tr>
    <th>
    <?php  echo LANGUI_PROFILE_T54;?> :
    </th>
    <td>
    <input class="text" type="text" name="email_alt" maxlength="50"></td>
    </tr>
    <tr>
    <th>
    <?php  echo LANGUI_PROFILE_T55;?> :
    </th>
    <td>
    <input class="text" type="text" name="email_neu" maxlength="50"></td>
    </tr>
    </tbody>
    </table>
    <?php if( $_POST && $erroremail != NULL ){ ?>

        <p class="error">
        <?php echo $erroremail;?>

        </p>
    <?php } ?>

    <p class="btn">
        <input type="image" value="" name="s1" id="btn_save" class="dynamic_img" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo text_save_lang;?>">
    </p>
    </form>
<?php }elseif( ( $selectedTabIndex == 3 ) ){ ?>

    <?php if( ( $errorText != '' ) ){ ?>

        <p class="f10 e"><?php echo $errorText;?></p>
    <?php } ?>

    <form action="profile?t=3" method="POST">
    <input type="hidden" name="e" value="3">
    <table cellpadding="1" cellspacing="1" id="sitter" class="account">
    <thead>
    <tr>
    <th colspan="2"><?php  echo LANGUI_PROFILE_T56;?></th>
    </tr>
    </thead>
    <tbody>
    <tr>
    <td class="note" colspan="2"><?php  echo LANGUI_PROFILE_T57;?></td>
    </tr>
    <tr>
    <th>
    <?php  echo LANGUI_PROFILE_T58;?> :
    </th>
    <td>
    <input class="text" type="text" name="v1" maxlength="15" <?php if( ( 2 <= sizeof( $myAgentPlayers ) ) ){ ?>disabled=""<?php } ?>>
    <span class="<?php if(  2 <= sizeof( $myAgentPlayers ) ){ ?>  max <?php }else{ ?> count <?php } ?>">(<?php echo sizeof( $myAgentPlayers ); ?>/2)</span>
    </td>
    </tr>
    <tr>
    <td colspan="2" class="sitter">
    <?php if( ( sizeof( $myAgentPlayers ) == 0 ) ){ ?>

        <span class="none"><?php  echo LANGUI_PROFILE_T59;?></span>
    <?php }else{ ?>

        <?php $counter1=-1; if( isset($myAgentPlayers) && is_array($myAgentPlayers) && sizeof($myAgentPlayers) ) foreach( $myAgentPlayers as $key1 => $value1 ){ $counter1++; ?>

            <div>
                <a href="profile?t=3&aid=<?php echo $key1;?>">
                    <img class="del" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" title="<?php  echo LANGUI_PROFILE_T60;?>" alt="<?php  echo LANGUI_PROFILE_T60;?>">
                </a>
                <a href="profile?uid=<?php echo $key1;?>"><?php echo $value1;?></a>
            </div>
        <?php } ?>

    <?php } ?>

    </td>
    </tr>
    <tr>
    <td class="note" colspan="2"><?php  echo LANGUI_PROFILE_T61;?></td>
    </tr>
    <tr>
    <td colspan="2" class="sitter">
    <?php if( ( sizeof( $agentForPlayers ) == 0 ) ){ ?>

        <span class="none"><?php  echo LANGUI_PROFILE_T62;?></span>
    <?php }else{ ?>

        <?php $counter1=-1; if( isset($agentForPlayers) && is_array($agentForPlayers) && sizeof($agentForPlayers) ) foreach( $agentForPlayers as $key1 => $value1 ){ $counter1++; ?>

            <div>
                <a href="profile?t=3&afid=<?php echo $key1;?>">
                    <img class="del" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" title="<?php  echo LANGUI_PROFILE_T63;?>" alt="<?php  echo LANGUI_PROFILE_T63;?>">
                </a>
                <a href="profile?uid=<?php echo $key1;?>"><?php echo $value1;?></a>
            </div>
        <?php } ?>

    <?php } ?>

    </td>
    </tr>
    </tbody>
    </table>
    <?php if( ( sizeof( $myAgentPlayers ) < 2 ) ){ ?>

        <p class="btn">
            <input type="image" value="" name="s1" id="btn_save" class="dynamic_img" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo text_save_lang;?>">
        </p>
    <?php } ?>

    </form>

<?php }elseif( ( $selectedTabIndex == 4 ) ){ ?>

    <form action="profile?t=4" method="POST">
    <input type="hidden" name="e" value="4">
    <table cellpadding="1" cellspacing="1" id="del_acc" class="account">
    <thead>
    <tr>
        <th colspan="2"><?php  echo LANGUI_PROFILE_T6;?></th>
    </tr>
    </thead>
    <tbody>
    <tr>
    <td class="note" colspan="2"><?php  echo LANGUI_PROFILE_T64;?></td>
    </tr>
    <?php if( ( $isPlayerInDeletionProgress ) ){ ?>

    <tr>
    <td colspan="2" class="count">
        <?php if( ( $canCancelPlayerDeletionProcess ) ){ ?>

        <a href="profile?t=4&qid=<?php echo $getPlayerDeletionId;?>">
            <img class="del" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo LANGUI_PROFILE_T65;?>" title="<?php  echo LANGUI_PROFILE_T65;?>">
        </a>
        <?php } ?>

        <?php  echo LANGUI_PROFILE_T66;?>

        <span id="timer1"><?php echo $getPlayerDeletionTime;?></span>
        <?php  echo time_hour_lang;?>

    </td>
    </tr>
    <?php }else{ ?>

    <tr>
    <th><?php  echo LANGUI_PROFILE_T6;?></th>
    <td class="del_selection">
    <label>
        <input class="radio" type="radio" name="del" value="1"><?php  echo LANGUI_PROFILE_T67;?></label>
    <label>
        <input class="radio" type="radio" name="del" value="0" checked=""><?php  echo LANGUI_PROFILE_T68;?></label>
    </td>
    </tr>
    <tr>
        <th><?php  echo LANGUI_PROFILE_T69;?>:</th>
        <td><input class="text" type="password" name="del_pw" maxlength="20"></td>
    </tr>
    <?php } ?>

    </tbody>
    </table>
        <?php if( $_POST && $erroremail != NULL ){ ?>

        <p class="error">
        <?php echo $erroremail;?>

        </p>
    <?php } ?>

    <?php if( ( !$isPlayerInDeletionProgress) ){ ?>

    <p class="btn">
        <input type="image" value="" name="s1" id="btn_save" class="dynamic_img" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo text_save_lang;?>">
    </p>
    <?php } ?>

    </form>
<?php }elseif( $selectedTabIndex == 5 ){ ?>

<form action="profile?t=5" method="POST">
  <input type="hidden" name="e" value="5">
  <table cellpadding="1" cellspacing="1" id="links">
    <thead>
      <tr>
        <th>
          <a href="#" onclick="return showManual(5,6);">
            <img class="help" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo text_helptip_lang;?>" title="<?php  echo text_helptip_lang;?>">
          </a>
        </th>
        <th colspan="2"><?php  echo LANGUI_LNKS_T1;?></th>
      </tr>
      <tr>
        <td><?php  echo LANGUI_LNKS_T2;?></td>
        <td><?php  echo LANGUI_LNKS_T3;?></td>
        <td><?php  echo LANGUI_LNKS_T4;?></td>
      </tr>
    </thead>
    <tbody>
    <?php $_c = 1;?>

    <?php $counter1=-1; if( isset($playerLinks) && is_array($playerLinks) && sizeof($playerLinks) ) foreach( $playerLinks as $key1 => $value1 ){ $counter1++; ?>

      <tr>
        <td class="nr">
          <input class="text" type="text" name="nr[]" value="<?php echo $_c++;?>" size="1" maxlength="3"></td>
        <td class="nam">
          <input class="text" type="text" name="linkname[]" value="<?php echo htmlspecialchars( $value1["linkName"] );?>" maxlength="30">
        </td>
        <td class="link">
          <input class="text" type="text" name="linkurl[]" value="<?php echo htmlspecialchars( $value1["linkHref"] );?><?php if( !$value1["linkSelfTarget"] ){ ?>*<?php } ?>" maxlength="255">
        </td>
      </tr>
      <?php } ?>

      <tr>
        <td class="nr">
          <input class="text" type="text" name="nr[]" value="<?php echo $_c;?>" size="1" maxlength="3">
        </td>
        <td class="nam">
          <input class="text" type="text" name="linkname[]" value="" maxlength="30"></td>
        <td class="link">
          <input class="text" type="text" name="linkurl[]" value="" maxlength="255"></td>
      </tr>
    </tbody>
  </table>
  <p class="btn">
    <input type="image" value="" name="s1" id="btn_ok" class="dynamic_img" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo text_okdone_lang;?>">
  </p>
</form>
<?php }elseif( $selectedTabIndex == 6 ){ ?>

<form action="profile?t=6" method="POST">
    <input type="hidden" name="e" value="6">
    <input type="hidden" name="protection" value="1">
    <table cellpadding="1" cellspacing="1" id="change_mail" class="account">
        <thead>
            <tr>
                <th colspan="2"><?php  echo LANGUI_PROFILE_T76;?></th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td class="note" colspan="2"><?php  echo LANGUI_PROFILE_T77;?></td>
            </tr>
            <?php if( $ProtectionStatus==1 ){ ?>

            <tr>
                <th><?php  echo LANGUI_PROFILE_T78;?>:</th>
                <td>
                    <p class="btn">
                        <input type="image" value="1" name="protection" id="btn_ok" class="dynamic_img" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo text_okdone_lang;?>">
                    </p>
                </td>
            </tr>
            <?php }elseif( $ProtectionStatus==2 ){ ?>

            <tr>
                <th><?php  echo LANGUI_PROFILE_T79;?>:</th>
                <td><span id="timer1"><?php echo $timer;?></span></td>
            </tr>
            <?php }else{ ?>

            <tr>
                <td class="note" colspan="2"><?php  echo LANGUI_PROFILE_T80;?></td>
            </tr>
            <?php } ?>

        </tbody>
    </table>
</form>
<!--<form action="profile?t=6" method="POST">
    <input type="hidden" name="e" value="6">
    <table cellpadding="1" cellspacing="1" id="change_mail" class="account">
        <thead>
            <tr>
                <th colspan="2"><?php  echo LANGUI_PROFILE_T81;?></th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td class="note" colspan="2"><?php  echo LANGUI_PROFILE_T82;?></td>
            </tr>
            <?php if( $holidayActiv==FALSE ){ ?>

            <tr>
                <th><?php if( $holidayEnd==TRUE ){ ?><?php  echo LANGUI_PROFILE_T83;?>:<?php }else{ ?><?php  echo LANGUI_PROFILE_T84;?>:<?php } ?></th>
                <td>
                <?php if( $holidayEnd==TRUE ){ ?>

                    <span id="timer1"><?php echo $holidayback;?></span>
                <?php }else{ ?>

                    <p class="btn">
                        <input type="hidden" name="holiday" value="1">
                        <input type="image" value="1" name="holiday" id="btn_ok" class="dynamic_img" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo text_okdone_lang;?>">
                    </p>
                <?php } ?>

                </td>
            </tr>
            <?php }else{ ?>

            <tr>
                <th><?php if( $holidayEnd==TRUE ){ ?><?php  echo LANGUI_PROFILE_T85;?>(<span id="timer1"><?php echo $holidayback;?></span>)<?php  echo LANGUI_PROFILE_T86;?>:<?php }else{ ?><?php  echo LANGUI_PROFILE_T89;?>:<?php } ?></th>
                <td>
                    <p class="btn">
                        <input type="hidden" name="holiday" value="2">
                        <input type="image" value="2" name="holiday" id="btn_ok" class="dynamic_img" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo text_okdone_lang;?>">
                    </p>
                </td>
            </tr>
            <?php } ?>

        </tbody>
    </table>
</form>-->
<?php } ?>

</body>
</html>