<?php if(!class_exists('raintpl')){exit;}?><!DOCTYPE html>

<html lang="ar">

<head>

    <meta charset="UTF-8">

    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

</head>

<body>
<?php echo load_lang('ui/alliance'); ?>

<?php if( !$hasAlliance ){ ?>

    <h1><?php  echo LANGUI_ALLIANCE_T1;?></h1>
	<p></p>
	<p><?php  echo LANGUI_ALLIANCE_T2;?></p>
	<p></p>
<?php }else{ ?>

    <h1><?php echo $allianceData["name"];?> - <?php echo $allianceData["name2"];?></h1>
    <?php if( $fullView ){ ?>

	    <div id="textmenu">
		    <a href="alliance"<?php if( $selectedTabIndex == 0 ){ ?> class="selected"<?php } ?>><?php  echo LANGUI_ALLIANCE_T3;?></a>
        <?php if( $hasAllianceEditRole ){ ?>

         |<a href="alliance?t=1"<?php if( $selectedTabIndex == 1 ){ ?> class="selected" <?php } ?>><?php  echo LANGUI_ALLIANCE_T4;?></a>
        <?php } ?>

         |<a href="alliance?t=2"<?php if( $selectedTabIndex == 2 ){ ?> class="selected" <?php } ?>><?php  echo LANGUI_ALLIANCE_T5;?></a>
		 |<a href="alliance?t=3"<?php if( $selectedTabIndex == 3 ){ ?> class="selected" <?php } ?>><?php  echo LANGUI_ALLIANCE_T6;?></a>
		</div>
    <?php } ?>


    <?php if( $selectedTabIndex == 0 ){ ?>

    <script type="text/javascript">
	    function getMouseCoords(e)
		{
		    var coords = {};
			if (!e) var e = window.event;
			if (e.pageX || e.pageY)
			{
			    coords.x = e.pageX;coords.y = e.pageY;
			}
			else if (e.clientX || e.clientY)
			{
			    coords.x = e.clientX + document.body.scrollLeft + document.documentElement.scrollLeft;coords.y = e.clientY + document.body.scrollTop + document.documentElement.scrollTop;
			}
			return coords;
		}
		function med_mouseMoveHandler(e, desc_string) {
            var coords = getMouseCoords(e);
            var layer = _("medal_mouseover");
            layer.style.top = (coords.y + 25) + "px";
            layer.style.left = (coords.x - 20) + "px";
            layer.className = "";
            layer.innerHTML  = desc_string;
        }
		function med_closeDescription()
		{
		    var layer = _("medal_mouseover");
			layer.className = "hide";
		}
		layer = document.createElement("div");
		layer.id = "medal_mouseover";
		layer.className = "hide";
		document.body.appendChild(layer);
	</script>
	<table cellpadding="1" cellspacing="1" id="profile">
	    <thead>
		    <tr>
			    <th colspan="2"><?php  echo LANGUI_ALLIANCE_T7;?></th>
			</tr>
			<tr>
			    <td><?php  echo LANGUI_ALLIANCE_T8;?>:</td>
				<td><?php  echo LANGUI_ALLIANCE_T9;?></td>
			</tr>
		</thead>
		<tbody>
		    <tr>
			    <td class="empty"></td>
				<td class="empty"></td>
			</tr>
			<tr>
			    <td class="details">
				    <table cellpadding="0" cellspacing="0">
					    <tbody>
						    <tr>
							    <th><?php  echo LANGUI_ALLIANCE_T10;?>:</th>
								<td><?php echo $allianceData["name"];?></td>
							</tr>
							<tr>
							    <th><?php  echo LANGUI_ALLIANCE_T11;?>:</th>
								<td><?php echo $allianceData["name2"];?></td>
							</tr>
							<tr>
							    <td colspan="2" class="empty"></td>
							</tr>
							<tr>
							    <th><?php  echo LANGUI_ALLIANCE_T12;?>:</th>
								<td><?php echo $allianceData["rank"];?></td>
							</tr>
							<tr>
							    <th><?php  echo LANGUI_ALLIANCE_T13;?>:</th>
								<td><?php echo $allianceData["score"];?></td>
							</tr>
							<tr>
							    <th><?php  echo LANGUI_ALLIANCE_T14;?>:</th>
								<td><?php echo $allianceData["player_count"];?></td>
							</tr>
							<tr>
							    <td colspan="2" class="empty"></td>
							</tr>
						<?php $counter1=-1; if( isset($roles) && is_array($roles) && sizeof($roles) ) foreach( $roles as $key1 => $value1 ){ $counter1++; ?>

                            <tr>
			                    <th><?php echo $value1["role"];?></th>
				                <td>
				                    <a href="profile?uid=<?php echo $value1["id"];?>"><?php echo $value1["name"];?></a>
				                </td>
			                </tr>
                        <?php } ?>

						    <tr>
							    <td colspan="2" class="empty"></td>
							</tr>
						    <tr>
							    <td class="desc2" colspan="2"><?php echo $getAllianceDescription2;?></td>
							</tr>
						</tbody>
					</table>
				</td>
				<td class="desc1"><?php echo $getAllianceDescription1;?></td>
			</tr>
		</tbody>
	</table>
	<script type="text/javascript">
	    function confirmDel ()
		{
		    return confirm ("<?php  echo LANGUI_ALLIANCE_T15;?>");
		}
		function showAllianceRole(uid)
		{
		    p = document.getElementById("ce");
			if (p!=null)
			{
			    p.innerHTML = '<div id="_pwin" class="popup3"><div id="drag" onmousedown="dragStart(event, \'_pwin\')"></div><a href="#" onClick="hideManual(); return false;"><img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" border="1" class="popup4" alt="Move"></a><iframe frameborder="0" id="Frame" src="alliancerole?uid='+uid+'" width="412" height="440" border="0"></iframe></div>';
			}
			return false;
		}
	</script>
	<table cellpadding="1" cellspacing="1" id="member">
	    <thead>
		    <tr>
			    <th>&nbsp;</th>
				<th><?php  echo LANGUI_ALLIANCE_T16;?></th>
				<th><?php  echo LANGUI_ALLIANCE_T17;?></th>
				<th><?php  echo LANGUI_ALLIANCE_T18;?></th>
            <?php if( $fullView ){ ?>

                <th>&nbsp;</th>
                <?php if( $RemovePlayerRole ){ ?>

                <th>&nbsp;</th>
                <?php } ?>

                <?php if( $hasAllianceSetRoles ){ ?>

                <th>&nbsp;</th>
                <?php } ?>

            <?php } ?>

			</tr>
		</thead>
		<tbody>
        <?php $counter1=-1; if( isset($allianceData["players"]) && is_array($allianceData["players"]) && sizeof($allianceData["players"]) ) foreach( $allianceData["players"] as $key1 => $value1 ){ $counter1++; ?>

            <tr>
			    <td class="ra"><?php echo $value1["c"];?>.</td>
			    <td class="pla">
				    <a href="profile?uid=<?php echo $value1["id"];?>"><?php echo $value1["name"];?></a>
				</td>
				<td class="hab"><?php echo $value1["total_people_count"];?></td>
				<td class="vil"><?php echo $value1["villages_count"];?></td>
            <?php if( $fullView ){ ?>

                <td class="on"><?php echo $value1["lastLoginFromHours"];?></td>
                <?php if( $RemovePlayerRole ){ ?>

                <td class="on">
                    <?php if( $value1["id"] != $playerId ){ ?>

                    <a onclick="return confirmDel();" href="alliance?d=<?php echo $value1["id"];?>">
					    <img class="del" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo LANGUI_ALLIANCE_T19;?>" title="<?php  echo LANGUI_ALLIANCE_T19;?>">
					</a>
                    <?php } ?></td>
                <?php } ?>

                <?php if( $hasAllianceSetRoles ){ ?>

                <td class="on">
				    <a onclick="return showAllianceRole(<?php echo $value1["id"];?>);" href="#">
				        <img class="def_c" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo LANGUI_ALLIANCE_T20;?>" title="<?php  echo LANGUI_ALLIANCE_T20;?>">
					</a>
				</td>
                <?php } ?>


            <?php } ?>

            </tr>
        <?php } ?>

		</tbody>
	</table>
<?php }elseif( $selectedTabIndex == 1 ){ ?>

    <form action="alliance?t=<?php echo $selectedTabIndex;?>" method="post">
	    <table cellpadding="1" cellspacing="1" id="edit" class="vip">
		    <thead>
			    <tr>
				    <th colspan="3"><?php  echo LANGUI_ALLIANCE_T7;?></th>
				</tr>
				<tr>
				    <td colspan="2"><?php  echo LANGUI_ALLIANCE_T8;?>:</td>
					<td><?php  echo LANGUI_ALLIANCE_T9;?>:</td>
				</tr>
			</thead>
			<tbody>
			    <tr>
				    <td colspan="2" class="empty"></td>
					<td class="empty"></td>
				</tr>
				<tr>
				    <th><?php  echo LANGUI_ALLIANCE_T10;?>:</th>
					<td class="birth">
					    <input tabindex="1" class="text day" type="text" name="aname1" value="<?php echo $allianceData["name"];?>" maxlength="8">
					</td>
					<td rowspan="4" class="desc1">
					    <textarea tabindex="7" name="be1"><?php echo $allianceData["description1"];?></textarea>
					</td>
				</tr>
				<tr>
				    <th><?php  echo LANGUI_ALLIANCE_T11;?>:</th>
					<td class="gend">
					    <input tabindex="1" class="text day" type="text" name="aname2" value="<?php echo $allianceData["name2"];?>" maxlength="25">
					</td>
				</tr>
				<tr>
				    <td colspan="2" class="empty"></td>
				</tr>
				<tr>
				    <td colspan="2">
					    <textarea tabindex="8" name="be2" rows="15" cols="33"><?php echo $allianceData["description2"];?></textarea>
					</td>
				</tr>
			</tbody>
		</table>
		<table cellpadding="1" cellspacing="1" id="medals">
		    <thead>
			    <tr>
				    <th colspan="5"><?php  echo LANGUI_ALLIANCE_T21;?></th>
				</tr>
				<tr>
					<td><?php  echo LANGUI_ALLIANCE_T22;?></td>
					<td><?php  echo LANGUI_ALLIANCE_T23;?></td>
					<td><?php  echo LANGUI_ALLIANCE_T24;?></td>
                    <td><?php  echo profile_medal_txt_points;?></td>
					<td><?php  echo LANGUI_ALLIANCE_T25;?></td>
				</tr>
			</thead>
			<tbody>
			<?php $counter1=-1; if( isset($Medals) && is_array($Medals) && sizeof($Medals) ) foreach( $Medals as $key1 => $value1 ){ $counter1++; ?>

                <tr>
				    <td class="typ"><?php echo constant('medal_row_'.$value1["medalData"]["textIndex"]); ?></td>
					<td class="ra"><?php echo $value1["rank"];?></td>
					<td class="we"><?php echo $value1["week"];?></td>
                    <td class="we"><?php echo $value1["points"];?></td>
					<td class="bb">[#<?php echo $value1["medalData"]["BBCode"] + $value1["week"] * 10 + ($value1["rank"] - 1);?>]</td>
				</tr>
            <?php } ?>

            </tbody>
		</table>
		<p class="btn">
		    <input type="image" value="" tabindex="9" name="s1" id="btn_ok" class="dynamic_img" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo text_okdone_lang;?>">
		</p>
	</form>
<?php }elseif( $selectedTabIndex == 2 ){ ?>

    <table cellpadding="1" cellspacing="1" id="offs">
	    <thead>
		    <tr>
			    <th colspan="4"><?php  echo LANGUI_ALLIANCE_T26;?><div id="submenu">
				    <a href="alliance?t=2<?php if( is_get('ac') && get('ac') == 2 ){ ?><?php }else{ ?>&ac=2<?php } ?>">
					    <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="btn_def <?php if( is_get('ac') && get('ac') == 2 ){ ?>active<?php } ?>" alt="<?php  echo LANGUI_ALLIANCE_T27;?>" title="<?php  echo LANGUI_ALLIANCE_T27;?>">
					</a>
					<a href="alliance?t=2<?php if( is_get('ac') && get('ac') == 1 ){ ?><?php }else{ ?>&ac=1<?php } ?>>
					    <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="btn_off <?php if( is_get('ac') && get('ac') == 1 ){ ?>active<?php } ?>" alt="<?php  echo LANGUI_ALLIANCE_T28;?>" title="<?php  echo LANGUI_ALLIANCE_T28;?>">
					</a>
				</div>
				</th>
			</tr>
			<tr>
			    <td><?php  echo LANGUI_ALLIANCE_T16;?></td>
				<td><?php  echo LANGUI_ALLIANCE_T7;?></td>
				<td><?php  echo LANGUI_ALLIANCE_T29;?></td>
			</tr>
		</thead>
		<tbody>
		<?php $_c = 0;?>

        <?php $counter1=-1; if( isset($Reports) && is_array($Reports) && sizeof($Reports) ) foreach( $Reports as $key1 => $value1 ){ $counter1++; ?>

		<?php $_c = $_c + 1;?>

            <tr>
			    <td class="sub">
				    <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="iReport iReport<?php echo $value1["_rptResultCss"];?>" alt="<?php echo $value1["btext"];?>" title="<?php echo $value1["btext"];?>">
					<div>
					    <a href="report?id=<?php echo $value1["id"];?>"><?php echo $value1["from_player_name"];?> <?php echo $value1["getreportactiontext"];?> <?php echo $value1["to_player_name"];?></a>
					</div>
				</td>
				<td class="al">
                <?php if( $value1["aData"] != NULL && 0 < $value1["aData"]['alliance_id'] ){ ?>

                    <a href="alliance?id=<?php echo $value1["aData"]['alliance_id'];?>"><?php echo $value1["aData"]['alliance_name'];?></a>
                <?php }else{ ?>-
                <?php } ?></td>
				<td class="dat"><?php echo $value1["mdate"];?></td>
			</tr>
        <?php } ?>


        <?php if( $_c == 0 ){ ?>

            <tr class="none">
			    <td colspan="4"><?php  echo LANGUI_ALLIANCE_T30;?></td>
			</tr>
        <?php } ?>

		</tbody>
	</table>
<?php }elseif( $selectedTabIndex == 3 ){ ?>

    <?php if( !is_get('a') ){ ?>

        <table cellpadding="1" cellspacing="1" id="options" class="small_option">
		    <thead>
			    <tr>
				    <th><?php  echo LANGUI_ALLIANCE_T6;?></th>
				</tr>
			</thead>
			<tbody>
            <?php if( $hasAllianceInviteRoles ){ ?>

                <tr>
				    <td class="val">
					    <a href="alliance?t=<?php echo $selectedTabIndex;?>&a=1"><?php  echo LANGUI_ALLIANCE_T31;?></a>
					</td>
				</tr>
            <?php } ?>

            <?php if( $EditContractRole ){ ?>

                <tr>
				    <td class="val">
					    <a href="alliance?t=<?php echo $selectedTabIndex;?>&a=2"><?php  echo LANGUI_ALLIANCE_T32;?></a>
					</td>
				</tr>
            <?php } ?>

                <tr>
				    <td class="val">
					    <a href="alliance?t=<?php echo $selectedTabIndex;?>&a=3"><?php  echo LANGUI_ALLIANCE_T33;?></a>
					</td>
				</tr>
			</tbody>
		</table>
    <?php }else{ ?>

        <form action="alliance?t=<?php echo $selectedTabIndex;?>&a=<?php echo get('a'); ?>" method="post">
        <?php if( get('a') == 3 ){ ?>

            <table cellpadding="1" cellspacing="1" id="quit" class="small_option">
			    <thead>
				    <tr>
					    <th colspan="2"><?php  echo LANGUI_ALLIANCE_T33;?></th>
					</tr>
				</thead>
				<tbody>
				    <tr>
					    <td colspan="2" class="info"><?php  echo LANGUI_ALLIANCE_T34;?></td>
					</tr>
					<tr>
					    <th><?php  echo LANGUI_ALLIANCE_T35;?>:</th>
						<td>
						    <input class="pass text" type="password" name="pw" maxlength="20">
						</td>
					</tr>
				</tbody>
			</table>
			<p>
			    <input type="image" value="ok" name="s1" id="btn_ok" class="dynamic_img" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo text_okdone_lang;?>">
			</p>
        <?php if( $hasErrors ){ ?>

            <p class="error"><?php  echo LANGUI_ALLIANCE_T36;?></p>
        <?php } ?>

        <?php }elseif( get('a') == 2 ){ ?>

            <table cellpadding="1" cellspacing="1" id="diplomacy" class="dipl">
			    <thead>
				    <tr>
					    <th colspan="2"> <?php  echo LANGUI_ALLIANCE_T37;?></th>
					</tr>
				</thead>
				<tbody>
				    <tr>
					    <th><?php  echo LANGUI_ALLIANCE_T7;?></th>
						<td>
						    <input class="ally text" type="text" name="a_name" maxlength="8">
						</td>
					</tr>
				</tbody>
			</table>
			<table cellpadding="1" cellspacing="1" id="hint" class="infos">
			    <thead>
				    <tr>
					    <th colspan="2"><?php  echo LANGUI_ALLIANCE_T38;?>:</th>
					</tr>
				</thead>
				<tbody>
				    <tr>
					    <td colspan="2"><?php  echo LANGUI_ALLIANCE_T39;?></td>
					</tr>
				</tbody>
			</table>
			<div id="box">
			    <p>
				    <input type="image" value="ok" name="s1" id="btn_ok" class="dynamic_img" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo text_okdone_lang;?>">
				</p>
            <?php if( is_post('a_name') && !$hasErrors ){ ?>

                <p class="error"><?php  echo LANGUI_ALLIANCE_T40;?> <?php echo post('a_name'); ?>.</p>
            <?php } ?>

		    </div>
			<div class="clear"></div>
			<table cellpadding="1" cellspacing="1" id="own" class="dipl">
			    <thead>
				    <tr>
					    <th colspan="3"><?php  echo LANGUI_ALLIANCE_T41;?></th>
					</tr>
				</thead>
				<tbody>
                <?php $_c = 0;?>

                <?php $counter1=-1; if( isset($Contracts) && is_array($Contracts) && sizeof($Contracts) ) foreach( $Contracts as $key1 => $value1 ){ $counter1++; ?>

                    <?php if( $value1["status"] == 1 ){ ?>

                    <?php $_c = $_c + 1;?>

                    <tr>
					    <td class="abo">
						    <a href="alliance?t=<?php echo $selectedTabIndex;?>&a=<?php echo get('a'); ?>&d=<?php echo $key1;?>">
						        <img class="del" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo LANGUI_ALLIANCE_T42;?>" title="<?php  echo LANGUI_ALLIANCE_T42;?>">
							</a>
						</td>
						<td>
						    <a href="alliance?id=<?php echo $key1;?>"><?php  echo LANGUI_ALLIANCE_T43;?> <?php echo $value1["name"];?></a>
						</td>
						<td class="wait"><?php  echo LANGUI_ALLIANCE_T44;?></td>
					</tr>
                    <?php } ?>

				<?php } ?>

                <?php if( $_c == 0 ){ ?>

                    <tr>
					    <td colspan="3" class="none"><?php  echo LANGUI_ALLIANCE_T45;?></td>
					</tr>
                <?php } ?>

				</tbody>
			</table>
			<table cellpadding="1" cellspacing="1" id="tip" class="infos">
			    <thead>
				    <tr>
					    <th colspan="2"><?php  echo LANGUI_ALLIANCE_T46;?>:</th>
					</tr>
				</thead>
				<tbody>
				    <tr>
					    <td colspan="2"><?php  echo LANGUI_ALLIANCE_T47;?><span class="e"> [contracts]</span>&nbsp; <?php  echo LANGUI_ALLIANCE_T48;?>. </td>
					</tr>
				</tbody>
			</table>
			<table cellpadding="1" cellspacing="1" id="foreign" class="dipl">
			    <thead>
				    <tr>
					    <th colspan="3"><?php  echo LANGUI_ALLIANCE_T49;?></th>
				    </tr>
				</thead>
				<tbody>
                <?php $_c = 0;?>

                <?php $counter1=-1; if( isset($Contracts) && is_array($Contracts) && sizeof($Contracts) ) foreach( $Contracts as $key1 => $value1 ){ $counter1++; ?>

                    <?php if( $value1["status"] == 2 ){ ?>

                    <?php $_c = $_c + 1;?>

                    <tr>
					    <td class="abo">
						    <a href="alliance?t=<?php echo $selectedTabIndex;?>&a=<?php echo get('a'); ?>&d=<?php echo $key1;?>">
					            <img class="del" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo LANGUI_ALLIANCE_T42;?>" title="<?php  echo LANGUI_ALLIANCE_T42;?>">
							</a>
						</td>
						<td>
						    <a href="alliance?id=<?php echo $key1;?>"><?php  echo LANGUI_ALLIANCE_T43;?> <?php echo $value1["name"];?></a>
						</td>
						<td class="wait">
						    <a href="alliance?t=<?php echo $selectedTabIndex;?>&a=<?php echo get('a'); ?>&c=<?php echo $key1;?>"><?php  echo LANGUI_ALLIANCE_T50;?></a>
						</td>
					</tr>
                    <?php } ?>

				<?php } ?>

                <?php if( $_c == 0 ){ ?>

                    <tr>
					    <td colspan="3" class="none"><?php  echo LANGUI_ALLIANCE_T45;?></td>
					</tr>
                <?php } ?>

				</tbody>
			</table>
			<table cellpadding="1" cellspacing="1" id="existing" class="dipl">
			    <thead>
				    <tr>
					    <th colspan="2"><?php  echo LANGUI_ALLIANCE_T51;?></th>
					</tr>
				</thead>
				<tbody>
                <?php $_c = 0;?>

                <?php $counter1=-1; if( isset($Contracts) && is_array($Contracts) && sizeof($Contracts) ) foreach( $Contracts as $key1 => $value1 ){ $counter1++; ?>

                <?php if( $value1["status"] == 0 ){ ?>

                    <?php $_c = $_c + 1;?>

                    <tr>
					    <td class="abo">
						    <a href="alliance?t=<?php echo $selectedTabIndex;?>&a=<?php echo get('a'); ?>&d=<?php echo $key1;?>">
							    <img class="del" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo LANGUI_ALLIANCE_T42;?>" title="<?php  echo LANGUI_ALLIANCE_T42;?>">
							</a>
						</td>
						<td colspan="2">
						    <a href="alliance?id=<?php echo $key1;?>"><?php  echo LANGUI_ALLIANCE_T43;?> <?php echo $value1["name"];?></a>
						</td>
					</tr>
                    <?php } ?>

				<?php } ?>

                <?php if( $_c == 0 ){ ?>

                    <tr>
					    <td colspan="3" class="none"><?php  echo LANGUI_ALLIANCE_T45;?></td>
					</tr>
                <?php } ?>

				</tbody>
			</table>
        <?php }elseif( get('a') == 1 ){ ?>

            <table cellpadding="1" cellspacing="1" id="invite" class="small_option">
			    <thead>
				    <tr>
					    <th colspan="2"><?php  echo LANGUI_ALLIANCE_T31;?></th>
					</tr>
				</thead>
				<tbody>
				    <tr>
					    <th><?php  echo LANGUI_ALLIANCE_T11;?>:</th>
						<td>
						    <input class="name text" type="text" name="a_name" maxlength="20">
						</td>
					</tr>
				</tbody>
			</table>
			<p>
			    <input type="image" value="ok" name="s1" id="btn_ok" class="dynamic_img" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo text_okdone_lang;?>">
			</p>
        <?php if( $invitesResult == 1 ){ ?>

            <p class="error"><?php  echo LANGUI_ALLIANCE_T52;?> <?php echo post('a_name'); ?></p>
        <?php }elseif( $invitesResult == 2 ){ ?>

            <p class="error"><?php  echo LANGUI_ALLIANCE_T53;?> <?php echo post('a_name'); ?></p>
        <?php } ?>

            <table cellpadding="1" cellspacing="1" id="invitations" class="small_option">
			    <thead>
				    <tr>
					    <th colspan="2"><?php  echo LANGUI_ALLIANCE_T54;?>:</th>
					</tr>
				</thead>
				<tbody>
                <?php $_c = 0;?>

                <?php $counter1=-1; if( isset($allianceData["players_invites"]) && is_array($allianceData["players_invites"]) && sizeof($allianceData["players_invites"]) ) foreach( $allianceData["players_invites"] as $key1 => $value1 ){ $counter1++; ?>

                    <?php $_c = $_c + 1;?>

                    <tr>
					    <td class="abo">
						    <a href="alliance?t=<?php echo $selectedTabIndex;?>&a=<?php echo get('a'); ?>&d=<?php echo $key1;?>">
						        <img class="del" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo LANGUI_ALLIANCE_T42;?>" title="<?php  echo LANGUI_ALLIANCE_T42;?>">
							</a>
						</td>
						<td>
						    <a href="profile?uid=<?php echo $key1;?>"><?php  echo LANGUI_ALLIANCE_T55;?> <?php echo $value1;?></a>
						</td>
					</tr>
                <?php } ?>

                <?php if( $_c == 0 ){ ?>

                    <tr>
					    <td colspan="2" class="none"><?php  echo LANGUI_ALLIANCE_T45;?></td>
					</tr>
                <?php } ?>

				</tbody>
			</table>
        <?php } ?>

        </form>
    <?php } ?>

<?php } ?>

<?php } ?>

</body>
</html>