<?php if(!class_exists('raintpl')){exit;}?><!DOCTYPE html>

<html lang="ar">

<head>

    <meta charset="UTF-8">

    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

</head>

<body>
<?php echo load_lang('ui/village1'); ?>

<h1>
    <?php echo $data["village_name"];?>

    <br>
    <?php if( ($data['allegiance_percent'] < 100 ) ){ ?>

        <div id="loyality" class="<?php if( $data['allegiance_percent'] <= 60 ){ ?>re<?php }else{ ?>gr<?php } ?>"><?php  echo LANGUI_VIL1_T1;?> <?php echo $data["allegiance_percent"];?>%</div>
    <?php } ?>

</h1>
<map name="rx" id="rx">
    <area href="build?id=1" coords="101,33,28" shape="circle" <?php echo $BuildingTitle_1;?>>
    <area href="build?id=2" coords="165,32,28" shape="circle" <?php echo $BuildingTitle_2;?>>
    <area href="build?id=3" coords="224,46,28" shape="circle" <?php echo $BuildingTitle_3;?>>
    <area href="build?id=4" coords="46,63,28" shape="circle" <?php echo $BuildingTitle_4;?>>
    <area href="build?id=5" coords="138,74,28" shape="circle" <?php echo $BuildingTitle_5;?>>
    <area href="build?id=6" coords="203,94,28" shape="circle" <?php echo $BuildingTitle_6;?>>
    <area href="build?id=7" coords="262,86,28" shape="circle" <?php echo $BuildingTitle_7;?>>
    <area href="build?id=8" coords="31,117,28" shape="circle" <?php echo $BuildingTitle_8;?>>
    <area href="build?id=9" coords="83,110,28" shape="circle" <?php echo $BuildingTitle_9;?>>
    <area href="build?id=10" coords="214,142,28" shape="circle" <?php echo $BuildingTitle_10;?>>
    <area href="build?id=11" coords="269,146,28" shape="circle" <?php echo $BuildingTitle_11;?>>
    <area href="build?id=12" coords="42,171,28" shape="circle" <?php echo $BuildingTitle_12;?>>
    <area href="build?id=13" coords="93,164,28" shape="circle" <?php echo $BuildingTitle_13;?>>
    <area href="build?id=14" coords="160,184,28" shape="circle" <?php echo $BuildingTitle_14;?>>
    <area href="build?id=15" coords="239,199,28" shape="circle" <?php echo $BuildingTitle_15;?>>
    <area href="build?id=16" coords="87,217,28" shape="circle" <?php echo $BuildingTitle_16;?>>
    <area href="build?id=17" coords="140,231,28" shape="circle" <?php echo $BuildingTitle_17;?>>
    <area href="build?id=18" coords="190,232,28" shape="circle" <?php echo $BuildingTitle_18;?>>
    <area href="village2" coords="144,131,36" shape="circle" title="<?php  echo LANGUI_VIL1_T2;?>" alt="<?php  echo LANGUI_VIL1_T2;?>">
</map>
<div id="village_map" class="f<?php echo $data["field_maps_id"];?>">
<?php $counter1=-1; if( isset($buildings) && is_array($buildings) && sizeof($buildings) ) foreach( $buildings as $key1 => $value1 ){ $counter1++; ?>

    <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="reslevel rf<?php echo $key1;?> level<?php echo $value1["level"];?>" alt="<?php echo $value1["name"];?>">
<?php } ?>

<img id="resfeld" usemap="#rx" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="">
</div>
    <div id="map_details">
        <?php if( (0 < $tasksInQueue['war_troops_summary']['total_number']) ){ ?>

            <table id="movements" cellpadding="1" cellspacing="1">
                <thead>
                    <tr>
                        <th colspan="3">
                            <?php  echo LANGUI_VIL1_T3;?>:
                        </th>
                    </tr>
                </thead>
                <tbody>
                <?php $war = $tasksInQueue['war_troops_summary']['to_me']['attacks'];?>

                <?php if( ( 0 < $war["number"] ) ){ ?>

                    <tr>
                        <td class="typ">
                            <a href="build?id=39">
                                <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="att1" alt="<?php  echo LANGUI_VIL1_T4;?>" title="<?php  echo LANGUI_VIL1_T4;?>"></a>
                            <span class="a1">&laquo;</span>
                        </td>
                        <td>
                            <div class="mov">
                                <span class="a1">
                                    <?php echo $war["number"];?>

                                    <?php  echo LANGUI_VIL1_T5;?>

                                </span>
                            </div>
                            <div class="dur_r">
                                <?php  echo text_in_lang;?>

                                <span id="timer1"><?php echo secondstostring( $war["min_time"] );?></span>
                                <?php  echo time_hour_lang;?>

                            </div>
                        </td>
                    </tr>
                    <?php } ?>


                    <?php $war = $tasksInQueue['war_troops_summary']['to_me']['reinforce'];?>

                    <?php if( ( 0 < $war['number'] ) ){ ?>

                    <tr>
                        <td class="typ">
                            <a href="build?id=39">
                                <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="def1" alt="<?php  echo LANGUI_VIL1_T6;?>" title="<?php  echo LANGUI_VIL1_T6;?>"></a>
                            <span class="d1">&laquo;</span>
                        </td>
                        <td>
                            <div class="mov">
                                <span class="d1">
                                    <?php echo $war["number"];?>

                                    <?php  echo LANGUI_VIL1_T7;?>

                                </span>
                            </div>
                            <div class="dur_r">
                                <?php  echo text_in_lang;?>

                                <span id="timer1"><?php echo secondstostring( $war["min_time"] );?></span>
                                <?php  echo time_hour_lang;?>

                            </div>
                        </td>
                    </tr>
                    <?php } ?>

                    <?php $war = $tasksInQueue['war_troops_summary']['from_me']['attacks'];?>

                    <?php if( ( 0 < $war['number'] ) ){ ?>

                    <tr>
                        <td class="typ">
                            <a href="build?id=39">
                                <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="att2" alt="<?php  echo LANGUI_VIL1_T8;?>" title="<?php  echo LANGUI_VIL1_T8;?>"></a>
                            <span class="a2">&raquo;</span>
                        </td>
                        <td>
                            <div class="mov">
                                <span class="a2">
                                    <?php echo $war["number"];?>

                                    <?php  echo LANGUI_VIL1_T5;?>

                                </span>
                            </div>
                            <div class="dur_r">
                                <?php  echo text_in_lang;?>

                                <span id="timer1"><?php echo secondstostring( $war["min_time"] );?></span>
                                <?php  echo time_hour_lang;?>

                            </div>
                        </td>
                    </tr>
                    <?php } ?>


                    <?php $war = $tasksInQueue['war_troops_summary']['from_me']['reinforce'];?>

                    <?php if( ( 0 < $war['number'] ) ){ ?>

                    <tr>
                        <td class="typ">
                            <a href="build?id=39">
                                <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="def2" alt="<?php  echo LANGUI_VIL1_T9;?>" title="<?php  echo LANGUI_VIL1_T9;?>"></a>
                            <span class="d2">&raquo;</span>
                        </td>
                        <td>
                            <div class="mov">
                                <span class="d2">
                                    <?php echo $war["number"];?>

                                    <?php  echo LANGUI_VIL1_T7;?>

                                </span>
                            </div>
                            <div class="dur_r">
                                <?php  echo text_in_lang;?>

                                <span id="timer1"><?php echo secondstostring( $war["min_time"] );?></span>
                                <?php  echo time_hour_lang;?>

                            </div>
                        </td>
                    </tr>
                    <?php } ?>


                    <?php $war = $tasksInQueue['war_troops_summary']['to_my_oasis']['attacks'];?>

                    <?php if( ( 0 < $war['number'] ) ){ ?>

                    <tr>
                        <td class="typ">
                            <a href="build?id=39">
                                <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="att3" alt="<?php  echo LANGUI_VIL1_T10;?>" title="<?php  echo LANGUI_VIL1_T10;?>"></a>
                            <span class="a3">&laquo;</span>
                        </td>
                        <td>
                            <div class="mov">
                                <span class="a3">
                                    <?php echo $war["number"];?>

                                    <?php  echo LANGUI_VIL1_T5;?>

                                </span>
                            </div>
                            <div class="dur_r">
                                <?php  echo text_in_lang;?>

                                <span id="timer1"><?php echo secondstostring( $war["min_time"] );?></span>
                                <?php  echo time_hour_lang;?>

                            </div>
                        </td>
                    </tr>
                    <?php } ?>


                    <?php $war = $tasksInQueue['war_troops_summary']['to_my_oasis']['reinforce'];?>

                    <?php if( ( 0 < $war['number'] ) ){ ?>

                    <tr>
                        <td class="typ">
                            <a href="build?id=39">
                                <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="def3" alt="<?php  echo LANGUI_VIL1_T11;?>" title="<?php  echo LANGUI_VIL1_T11;?>"></a>
                            <span class="d3">&laquo;</span>
                        </td>
                        <td>
                            <div class="mov">
                                <span class="d3">
                                    <?php echo $war["number"];?>

                                    <?php  echo LANGUI_VIL1_T7;?>

                                </span>
                            </div>
                            <div class="dur_r">
                                <?php  echo text_in_lang;?>

                                <span id="timer1"><?php echo secondstostring( $war["min_time"] );?></span>
                                <?php  echo time_hour_lang;?>

                            </div>
                        </td>
                    </tr>
                    <?php } ?>

                </tbody>
            </table>
            <?php } ?>

            <table id="production" cellpadding="1" cellspacing="1">
                <thead>
                    <tr>
                        <th colspan="4"><?php  echo LANGUI_VIL1_T12;?>:</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td class="ico">
                            <img class="r1" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt=" <?php  echo item_title_1;?>" title=" <?php  echo item_title_1;?>" />
                        </td>
                        <?php $time1 = (($resources["1"]['store_max_limit']-$resources["1"]['current_value'])/$resources["1"]['calc_prod_rate'])*(60*60);?>

                        <td class="res" title=" <?php if( ($time1 <= 0) ){ ?> <?php  echo LANGUI_VIL1_T20;?> <?php }else{ ?> <?php  echo LANGUI_VIL1_T19;?>  <?php echo secondstostring( $time1 );?><?php } ?>"><?php  echo item_title_1;?>:</td>
                        <td class="num" title="<?php if( ($time1 <= 0) ){ ?> <?php  echo LANGUI_VIL1_T20;?> <?php }else{ ?> <?php  echo LANGUI_VIL1_T19;?>  <?php echo secondstostring( $time1 );?><?php } ?>"><?php echo $resources["1"]["calc_prod_rate"];?></td>
                        <td class="per" title=" <?php if( ($time1 <= 0) ){ ?> <?php  echo LANGUI_VIL1_T20;?> <?php }else{ ?> <?php  echo LANGUI_VIL1_T19;?>  <?php echo secondstostring( $time1 );?><?php } ?>"><?php  echo LANGUI_VIL1_T13;?></td>
                    </tr>
                    <tr>
                        <td class="ico">
                            <img class="r2" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt=" <?php  echo item_title_2;?>" title=" <?php  echo item_title_2;?>" />
                        </td>
                        <?php $time2 = (($resources["2"]['store_max_limit']-$resources["2"]['current_value'])/$resources["2"]['calc_prod_rate'])*(60*60);?>

                        <td class="res" title=" <?php if( ($time2 <= 0) ){ ?> <?php  echo LANGUI_VIL1_T20;?> <?php }else{ ?> <?php  echo LANGUI_VIL1_T19;?>  <?php echo secondstostring( $time2 );?><?php } ?>"><?php  echo item_title_2;?>:</td>
                        <td class="num" title=" <?php if( ($time2 <= 0) ){ ?> <?php  echo LANGUI_VIL1_T20;?> <?php }else{ ?> <?php  echo LANGUI_VIL1_T19;?>  <?php echo secondstostring( $time2 );?><?php } ?>"><?php echo $resources["2"]["calc_prod_rate"];?></td>
                        <td class="per" title=" <?php if( ($time2 <= 0) ){ ?> <?php  echo LANGUI_VIL1_T20;?> <?php }else{ ?> <?php  echo LANGUI_VIL1_T19;?>  <?php echo secondstostring( $time2 );?><?php } ?>"><?php  echo LANGUI_VIL1_T13;?></td>
                    </tr>
                    <tr>
                        <td class="ico">
                            <img class="r3" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt=" <?php  echo item_title_3;?>" title=" <?php  echo item_title_3;?>" />
                        </td>
                        <?php $time3 = (($resources["3"]['store_max_limit']-$resources["3"]['current_value'])/$resources["3"]['calc_prod_rate'])*(60*60);?>

                        <td class="res" title=" <?php if( ($time3 <= 0) ){ ?> <?php  echo LANGUI_VIL1_T20;?> <?php }else{ ?> <?php  echo LANGUI_VIL1_T19;?>  <?php echo secondstostring( $time3 );?><?php } ?>"><?php  echo item_title_3;?>:</td>
                        <td class="num" title=" <?php if( ($time3 <= 0) ){ ?> <?php  echo LANGUI_VIL1_T20;?> <?php }else{ ?> <?php  echo LANGUI_VIL1_T19;?>  <?php echo secondstostring( $time3 );?><?php } ?>"><?php echo $resources["3"]["calc_prod_rate"];?></td>
                        <td class="per" title=" <?php if( ($time3 <= 0) ){ ?> <?php  echo LANGUI_VIL1_T20;?> <?php }else{ ?> <?php  echo LANGUI_VIL1_T19;?>  <?php echo secondstostring( $time3 );?><?php } ?>"><?php  echo LANGUI_VIL1_T13;?></td>
                    </tr>
                    <tr>
                        <td class="ico">
                            <img class="r4" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt=" <?php  echo item_title_4;?>" title=" <?php  echo item_title_4;?>" />
                        </td>
                        <?php $time4 = $resources["4"]['calc_prod_rate'] <= 0 ? 0 : (($resources["4"]['store_max_limit']-$resources["4"]['current_value'])/$resources["4"]['calc_prod_rate'])*(60*60);?>

                        <td class="res" title=" <?php if( ($time4 <= 0) ){ ?> <?php  echo LANGUI_VIL1_T20;?> <?php }else{ ?> <?php  echo LANGUI_VIL1_T19;?>  <?php echo secondstostring( $time4 );?><?php } ?>"><?php  echo item_title_4;?>:</td>
                        <td class="num" title=" <?php if( ($time4 <= 0) ){ ?> <?php  echo LANGUI_VIL1_T20;?> <?php }else{ ?> <?php  echo LANGUI_VIL1_T19;?>  <?php echo secondstostring( $time4 );?><?php } ?>"><?php echo $resources["4"]["calc_prod_rate"];?></td>
                        <td class="per" title=" <?php if( ($time4 <= 0) ){ ?> <?php  echo LANGUI_VIL1_T20;?> <?php }else{ ?> <?php  echo LANGUI_VIL1_T19;?>  <?php echo secondstostring( $time4 );?><?php } ?>"><?php  echo LANGUI_VIL1_T13;?></td>
                    </tr>
                </tbody>
            </table>
            <table id="troops" cellpadding="1" cellspacing="1">
                <thead>
                    <tr>
                        <th colspan="3">
                            <?php  echo LANGUI_VIL1_T14;?>:
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <?php if( ( $heroCount == 0 && sizeof( $troops ) == 0 ) ){ ?>

                    <tr>
                        <td><?php  echo LANGUI_VIL1_T15;?></td>
                    </tr>
                    <?php }else{ ?>

                    <?php if( ( 0 < $heroCount ) ){ ?>

                        <tr>
                            <td class="ico">
                                <a href="build?id=39">
                                    <img class="unit uhero" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo troop_hero;?>" title="<?php  echo troop_hero;?>"></a>
                            </td>
                            <td class="num"><?php echo $heroCount;?></td>
                            <td class="un"><?php  echo troop_hero;?></td>
                        </tr>
                        <?php } ?>

                        <?php $counter1=-1; if( isset($troops) && is_array($troops) && sizeof($troops) ) foreach( $troops as $key1 => $value1 ){ $counter1++; ?>

                        <tr>
                            <td class="ico">
                                <a href="build?id=39">
                                    <img class="unit u<?php echo $key1;?>" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php echo $value1["name"];?>" title="<?php echo $value1["name"];?>">
                                </a>
                            </td>
                            <td class="num"><?php echo $value1["v"];?></td>
                            <td class="un"><?php echo $value1["name"];?></td>
                        </tr>
                        <?php } ?>

                        <?php } ?>

                    </tbody>
                </table>
            </div>
            <?php if( ($QS_BUILD_CREATEUPGRADE) ){ ?>

            <table cellpadding="1" cellspacing="1" id="building_contract">
                <thead>
                    <tr>
                        <th colspan="3">
                            <?php  echo LANGUI_VIL1_T16;?> :
                            <?php if( ( !$data['is_special_village'] && $gameMetadata['plusTable'][5]['cost'] <= $data['gold_num'] ) ){ ?>

                                <a href="village1?bfs=5&k=<?php echo $data["update_key"];?>" title="<?php  echo LANGUI_VIL1_T18;?>">
                                    <img class="clock" alt="<?php  echo LANGUI_VIL1_T18;?>" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>"></a>
                            <?php } ?>

                            </th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $counter1=-1; if( isset($tmpBuilding) && is_array($tmpBuilding) && sizeof($tmpBuilding) ) foreach( $tmpBuilding as $key1 => $value1 ){ $counter1++; ?>

                        <tr>
                            <td class="ico">
                                <a href="village1?id=<?php echo $value1["id"];?>&d&k=<?php echo $data["update_key"];?>">
                                    <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="del" title="<?php  echo LANGUI_VIL1_T17;?>" alt="<?php  echo LANGUI_VIL1_T17;?>">
                                </a>
                            </td>
                            <td>
                                <?php echo $value1["item_id_title"];?> (<?php  echo level_lang;?>  <?php echo $value1["level"];?>)
                            </td>
                            <td>
                                <?php  echo time_remain_lang;?>

                                <span id="timer1">
                                    <?php echo $value1["remainingSeconds"];?>

                                </span>
                                <?php  echo time_hour_lang;?>

                            </td>
                        </tr>
                        <?php } ?>

                </tbody>
            </table>
        <?php } ?>

		</body>
</html>