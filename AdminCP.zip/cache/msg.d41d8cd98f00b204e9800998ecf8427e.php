<?php if(!class_exists('raintpl')){exit;}?><!DOCTYPE html>

<html lang="ar">

<head>

    <meta charset="UTF-8">

    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

</head>

<body>
<?php echo load_lang('ui/msg'); ?>

<h1><?php  echo LANGUI_MSG_T1;?></h1>
    <div id="textmenu">
	    <a href="message"<?php if( $selectedTabIndex == 0 ){ ?> class="selected" <?php } ?>><?php  echo LANGUI_MSG_T2;?></a> |
	    <a href="message?t=1"<?php if( $selectedTabIndex == 1 ){ ?> class="selected" <?php } ?>><?php  echo LANGUI_MSG_T3;?></a> |
	    <a href="message?t=2"<?php if( $selectedTabIndex == 2 ){ ?> class="selected" <?php } ?>><?php  echo LANGUI_MSG_T4;?></a>
        | <a href="message?t=3"<?php if( !$data["active_plus_account"] ){ ?> onclick="return showManual(5,0);"<?php } ?><?php if( $selectedTabIndex == 3 ){ ?> class="selected" <?php } ?>><?php  echo text_pnotes_lang;?></a> 

	</div>
<?php if( ($showList) ){ ?>

    <form method="post" action="message?p=<?php echo $pageIndex;?><?php if( ($selectedTabIndex == 2) ){ ?>&t=2<?php } ?>" name="msg">
	    <table cellpadding="1" cellspacing="1" id="overview" class="row_table_data">
		    <thead>
			    <tr>
				    <th colspan="2"><?php  echo LANGUI_MSG_T5;?></th>
					<th><?php if( ($selectedTabIndex == 2) ){ ?> <?php  echo LANGUI_MSG_T6;?> <?php }else{ ?> <?php  echo LANGUI_MSG_T7;?> <?php } ?></th>
					<th class="sent"><?php  echo LANGUI_MSG_T8;?></th>
				</tr>
		    </thead>
	    <tbody>
    <?php $_c = 0;?>

    <?php $counter1=-1; if( isset($dataList) && is_array($dataList) && sizeof($dataList) ) foreach( $dataList as $key1 => $value1 ){ $counter1++; ?>

        <?php $_c = $_c + 1;?>

        <tr>
		    <td class="sel"><input class="check" type="checkbox" name="dm[]" value="<?php echo $value1["id"];?>"></td>
            <td class="top"><a href="message?id=<?php echo $value1["id"];?>"><?php echo $value1["msg_title"];?></a><?php if( ( !$value1["is_readed"] ) ){ ?><?php if( ($selectedTabIndex == 0) ){ ?> <?php  echo LANGUI_MSG_T9;?> <?php }else{ ?> <?php  echo LANGUI_MSG_T10;?> <?php } ?> <?php } ?></td>
			<td class="send"><?php if( (0 < $value1["uid"]) ){ ?><a href="profile?uid=<?php echo $value1["uid"];?>"><?php echo $value1["uname"];?></a><?php }else{ ?><span class="none"><?php echo $value1["uname"];?></span><?php } ?></td>
			<td class="dat"><?php echo $value1["mdate"];?></td>
		</tr>
	<?php } ?>

    <?php if( ($_c == 0) ){ ?>

        <tr>
		    <td colspan="4">
			    <span class="none"><?php  echo LANGUI_MSG_T11;?></span>
		    </td>
		</tr>
    <?php } ?>

        </tbody>
		<tfoot>
		    <tr>
			    <th>
				<?php if( (0 < $_c) ){ ?>

		          <input class="check"  type="checkbox" id="s10" name="s10" onclick="Allmsg(this.form);">
                <?php } ?>

                </th>
				<th colspan="2" class="buttons">
                <?php if( (0 < $_c) ){ ?>

                    <input name="delmsg" value="<?php  echo LANGUI_MSG_T12;?>" type="image" id="btn_delete" class="dynamic_img" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo LANGUI_MSG_T12;?>">
				<?php } ?>

                </th>
				<th class="navi"><?php echo $getPreviousLink;?> <?php echo $getNextLink;?></th>
			</tr>
		</tfoot>
	    </table>
	</form>
<?php }elseif( $selectedTabIndex == 3 ){ ?>

<form method="post" action="message?t=3">
    <div id="block">
      <textarea name="notes" id="notice"><?php echo $data["notes"];?></textarea>
      <p class="btn">
        <input id="btn_save" type="image" value="" name="s1" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="dynamic_img" alt="<?php  echo text_save_lang;?>">
        <br />
    <?php if( $_POST && $saved ){ ?>

      <?php  echo text_newssaved_lang;?>

    <?php } ?>

  </p>
</div>
</form>
<?php }elseif( $selectedTabIndex == 4 ){ ?>

    <div id="cometchat_embed_synergy_container" style="width:520px;height:500px;max-width:100%;border:1px solid #CCCCCC;border-radius:5px;overflow:hidden;" ></div><script src="https://www.xtatar.com/cometchat/js.php?type=core&name=embedcode" type="text/javascript"></script><script>var iframeObj = {};iframeObj.module="synergy";iframeObj.style="min-height:420px;min-width:350px;";iframeObj.width="520px";iframeObj.height="500px";iframeObj.src="https://www.xtatar.com/cometchat/cometchat_embedded.php"; if(typeof(addEmbedIframe)=="function"){addEmbedIframe(iframeObj);}</script>
<?php }else{ ?>

<script language="JavaScript" type="text/javascript">
	function closeFriendsList()
	{
	    _('adressbook').className = 'hide';
	}
	function toggleFriendsList()
	{
	    var book = _('adressbook');
		book.className = (book.className == 'hide') ? '' : 'hide';
	}
	function copyElement(element)
	{
	    if (element == 'receiver')
		{
		    _('copy_receiver').value = _('receiver').value;
		}
		else if (element == 'subject')
        {
		    _('copy_subject').value = _('subject').value;
	    }
		else if (element == 'body')
		{
		    _('copy_igm').value = _('igm').value;
	    }
	}
	function setReceiver(name)
	{
	    _('receiver').value = name;copyElement('receiver');
	}
	function delFriend (uid)
	{
	     _("fma").value=uid;document.abform.submit();
    }
</script>
    <span class="error"><?php echo $errorText;?></span>
	<div id="write_head" class="msg_head"></div>
    <div id="write_content" class="msg_content">
	    <form method="post" action="message" accept-charset="UTF-8" name="msg">
		    <input type="hidden" name="<?php if( ($viewOnly) ){ ?>rm<?php }else{ ?>sm<?php } ?>" value="1">
			<img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" id="label" class="<?php if( ($sendMail) ){ ?>send<?php }else{ ?>read<?php } ?>" alt="">
			<div id="heading">
			    <input class="text" type="text"<?php if( ($viewOnly) ){ ?> readonly="readonly" <?php } ?>name="anxc" id="receiver" value="<?php echo $receiver;?>" maxlength="20" onkeyup="copyElement('receiver')" tabindex="1;">
				<br>
				<input class="text" type="text"<?php if( ($viewOnly) ){ ?> readonly="readonly" <?php } ?>name="be" id="subject" value="<?php echo $subject;?>" maxlength="35" onkeyup="copyElement('subject')" tabindex="2;">
			</div>
        <?php if( ($viewOnly) ){ ?>

           <div id="time">
		        <div><?php echo $messageDate;?></div>
				<div><?php echo $messageTime;?></div>
			</div>
        <?php }else{ ?>

            <a id="adbook" href="#" onclick="toggleFriendsList(); return false;">
			    <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo LANGUI_MSG_T13;?>" title="<?php  echo LANGUI_MSG_T13;?>">
		    </a>
        <?php } ?>

            <div class="clear"></div>
			<div id="line"></div>
			<textarea class="textarea write" name="message" id="igm" onkeyup="copyElement('body')" tabindex="3;"<?php if( ($viewOnly) ){ ?> readonly="readonly" <?php } ?>><?php echo $body;?></textarea>

        <?php if( ($isInbox) ){ ?>

            <p class="btn">
            <?php if( ($viewOnly) ){ ?>

		        <input type="image" value="" name="s1" id="btn_reply" class="dynamic_img" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo LANGUI_MSG_T14;?>" onclick="if (this.disabled==false) {document.getElementsByTagName('form')[0].submit();} this.disabled=true;" onLoad="this.disabled=false;">
            <?php }else{ ?>

		        <input type="image" value="" name="s1" id="btn_send" class="dynamic_img" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo LANGUI_MSG_T15;?>" tabindex="4;" onclick="if (this.disabled==false) {document.getElementsByTagName('form')[0].submit();} this.disabled=true;" onLoad="this.disabled=false;">
            <?php } ?>

            </p>
        <?php } ?>

        </form>
    <?php if( (!$viewOnly) ){ ?>

    <div id="adressbook" class="<?php if( (!$showFriendPane) ){ ?>hide<?php } ?>">
		<h2><?php  echo LANGUI_MSG_T13;?></h2>
			<table cellpadding="1" cellspacing="1" id="friendlist">
			    <tbody>
				    <tr>
                    <?php $_c = 0;?>

					<?php $counter1=-1; if( isset($friendList) && is_array($friendList) && sizeof($friendList) ) foreach( $friendList as $key1 => $value1 ){ $counter1++; ?>

						<?php $_c = $_c + 1;?>

                        <?php if( $counter1 == 0 ){ ?><?php $counter1 = 1;?><?php } ?>

                        <td class="end"><?php echo $_c;?></td>
						<td class="pla">
						    <a href="#" onclick="closeFriendsList(); setReceiver('<?php echo $value1;?>'); return false;"><?php echo $value1;?></a>
						</td>
                    <?php if( ($counter1 % 2 == 0) ){ ?></tr><?php } ?>

                    <?php } ?>

                    
                </tbody>
			</table>
		<a href="#" onclick="closeFriendsList(); return false;">
		    <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" id="close" alt="<?php  echo LANGUI_MSG_T16;?>" title="<?php  echo LANGUI_MSG_T16;?>">
		</a>
	</div>
    <?php } ?>

    </div>
	<div id="write_foot" class="msg_foot"></div>
    <?php if( (0 < intval($data["alliance_id"])) ){ ?>

        <span class="error"><?php  echo LANGUI_MSG_T17;?></span>
    <?php } ?>


<?php } ?>

</body>
</html>