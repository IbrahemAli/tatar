<?php if(!class_exists('raintpl')){exit;}?><?php echo load_lang('ui/logout'); ?>

<h1> <?php  echo LANGUI_LOGOUT_T1;?></h1>
<img class="roman" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="">
<p> <?php  echo LANGUI_LOGOUT_T2;?></p>
<p></p>
<p> <?php  echo LANGUI_LOGOUT_T3;?></p><br>
<a href="login?dcookie"> <?php  echo LANGUI_LOGOUT_T4;?></a>
<p></p>