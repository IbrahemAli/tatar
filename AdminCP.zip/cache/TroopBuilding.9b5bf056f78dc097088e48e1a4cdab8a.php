<?php if(!class_exists('raintpl')){exit;}?><!DOCTYPE html>

<html lang="ar">

<head>

    <meta charset="UTF-8">

    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

</head>

<body>
<?php echo load_lang('ui/custbuilds'); ?>

  <p></p>
  <?php if( $if_building_id_36 ){ ?>

      <p>
      <?php  echo LANGUI_CUSTBU_TRP_t1;?>

       <b>
      <?php echo $troops["99"];?>

      </b>
      <?php  echo LANGUI_CUSTBU_TRP_t2;?>

       <b>
      <?php echo $data["troops_trapped_num"];?>

      </b>
      <?php  echo LANGUI_CUSTBU_TRP_t3;?>

      .</p>
      <p></p>
  <?php } ?>

  <form method="post" name="snd" action="build?id=<?php echo $buildingIndex;?>">
    <table cellpadding="1" cellspacing="1" class="build_details">
      <thead>
        <tr>
          <td><?php  echo LANGUI_CUSTBU_TRP_t4;?></td>
          <td><?php  echo LANGUI_CUSTBU_TRP_t5;?></td>
          <td><?php  echo LANGUI_CUSTBU_TRP_t6;?></td>
        </tr>
      </thead>
      <tbody>
        <?php $counter1=-1; if( isset($troopsUpgrade) && is_array($troopsUpgrade) && sizeof($troopsUpgrade) ) foreach( $troopsUpgrade as $key1 => $value1 ){ $counter1++; ?>

              <tr>
                <td class="desc">
                  <div class="tit">
                    <img class="unit u<?php echo $key1;?>" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php echo constant('troop_' . $key1); ?>" title="<?php echo constant('troop_' . $key1); ?>" >
                    <a href="#" onclick="return showManual(<?php echo $value1["manual"];?>);"><?php echo constant('troop_' . $key1); ?></a>
                    <span class="info">( <?php  echo LANGUI_CUSTBU_TRP_t7;?>:  <?php echo $value1["troop_name"];?> )</span>
                  </div>
                  <div class="details">
                    <img class="r1" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo item_title_1;?>" title="<?php  echo item_title_1;?>"><span class="little_res"><?php echo $value1["training_resources_1"];?></span>|<img class="r2" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo item_title_2;?>" title="<?php  echo item_title_2;?>"><span class="little_res"><?php echo $value1["training_resources_2"];?></span>|<img class="r3" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo item_title_3;?>" title="<?php  echo item_title_3;?>"><span class="little_res"><?php echo $value1["training_resources_3"];?></span>|<img class="r4" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo item_title_4;?>" title="<?php  echo item_title_4;?>"><span class="little_res"><?php echo $value1["training_resources_4"];?></span>|<img class="clock" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo text_period_lang;?>" title="<?php  echo text_period_lang;?>"><?php echo $value1["lvlTime"];?><?php echo $value1["neededResources"];?>

              </div>
              </td>
              <td class="val">
                <input type="text" class="text" id="_tf<?php echo $key1;?>" name="tf[<?php echo $key1;?>]" value="0" maxlength="7">
              </td>
              <td class="max">
                <a href="#" onclick="_('_tf<?php echo $key1;?>').value=<?php echo $value1["maxNumber"];?>; return false;">(<?php echo $value1["maxNumber"];?>)</a>
              </td>
              </tr>
        <?php } ?>


  <?php if( ($_ac == 0) ){ ?>

      <tr>
        <td colspan="3">
          <span class="none">
            <?php  echo LANGUI_CUSTBU_TRP_t8;?>

          </span>
        </td>
      </tr>
  <?php } ?>

  </tbody>
</table>

<?php if( (0 < $_ac) ){ ?>

      <p>
        <input type="image" id="btn_train" class="dynamic_img" value="ok" name="s1" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo LANGUI_CUSTBU_TRP_t9;?>">
      </p>
<?php } ?>

</form>


  <?php if( $isset_tasksInQueue ){ ?>

      <table cellpadding="1" cellspacing="1" class="under_progress">
      <?php if( (!$data['is_special_village'] && $gameMetadata['plusTable'][7]['cost'] <= $data['gold_num']) ){ ?>

          <thead>
            <tr>
              <th colspan="2">
              <?php $costTip = sprintf(LANGUI_CUSTBU_TRP_t15, $gameMetadata['plusTable'][7]['cost']);?>

              <?php  echo LANGUI_CUSTBU_TRP_t16;?> :
              <a href="?id=<?php echo $_GET['id'];?>&bfs=7&k=<?php echo $data["update_key"];?>" title="<?php echo $costTip;?>">
                <img class="clock" alt="<?php echo $costTip;?>" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>">
              </a>
              </th>
            </tr>
      </thead>
      <?php } ?>

      <thead>
        <tr>
          <td>
              <?php if( ($buildProperties['building']['item_id'] == 36) ){ ?>

                  <?php  echo LANGUI_CUSTBU_TRP_t10;?>

              <?php }else{ ?>

                  <?php  echo LANGUI_CUSTBU_TRP_t11;?>

              <?php } ?>

        </td>
      <td>
        <?php  echo text_period_lang;?>

      </td>
    </tr>
  </thead>
  <tbody>
      <?php $nextTroopTime = 0;?>

      <?php $_f            = TRUE;?>

      <?php $counter1=-1; if( isset($qts) && is_array($qts) && sizeof($qts) ) foreach( $qts as $key1 => $value1 ){ $counter1++; ?>

          <?php $tid       = $value1['proc_params'];?>

          <?php $troopTime = $value1['execution_time'] - ($value1['execution_time'] * $value1['threads'] - $value1['remainingSeconds']);?>

          <?php if( ($troopTime < $nextTroopTime || $_f) ){ ?>

              <?php $_f            = FALSE;?>

              <?php $nextTroopTime = $troopTime;?>

          <?php } ?>

          <tr>
            <td class="desc">
              <img class="unit u<?php echo $tid;?>" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php echo constant('troop_' . $tid); ?>" title="<?php echo constant('troop_' . $tid); ?>">
                <?php echo $value1["threads"];?>

                <?php echo constant('troop_' . $tid); ?>

            </td>
          <td class="dur">
            <span id="timer1">
              <?php echo secondstostring( $value1["remainingSeconds"] );?>

            </span>
          </td>
        </tr>
      <?php } ?>

      <tr class="next">
        <td colspan="2">
          <?php if( $buildProperties['building']['item_id'] == 36 ){ ?> <?php  echo LANGUI_CUSTBU_TRP_t13;?> <?php }else{ ?> <?php  echo LANGUI_CUSTBU_TRP_t14;?> <?php } ?>

          <?php  echo LANGUI_CUSTBU_TRP_t12;?>

          <span id="timer1">
            <?php echo secondstostring( $nextTroopTime );?>

          </span>
        </td>
  </tr>
</tbody>
</table>
<?php } ?>

</body>
</html>