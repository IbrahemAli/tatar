<?php if(!class_exists('raintpl')){exit;}?><!DOCTYPE html>

<html lang="ar">

<head>

    <meta charset="UTF-8">

    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

</head>

<body>
<?php echo load_lang('ui/village1'); ?>

<?php echo load_lang('ui/village2'); ?>

  <h1><?php echo $data["village_name"];?></h1>
  <map name="map1" id="map1">
    <area href="build?id=40" <?php echo $BuildingTitle_40;?> coords="325,225,180" shape="circle">
   <area href="build?id=40" <?php echo $BuildingTitle_40;?> coords="220,230,185" shape="circle">
 </map>
 <map name="map2" id="map2">
  <?php if( ($data['is_special_village']) ){ ?>

      <area href="build?id=25" <?php echo $BuildingTitle_25;?> coords="180,160,80" shape="circle">
  <?php } ?>

  <area href="build?id=19" <?php echo $BuildingTitle_19;?> coords="53,91,53,37,128,37,128,91,91,112" shape="poly">
  <area href="build?id=20" <?php echo $BuildingTitle_20;?> coords="136,66,136,12,211,12,211,66,174,87" shape="poly">
  <area href="build?id=21" <?php echo $BuildingTitle_21;?> coords="196,56,196,2,271,2,271,56,234,77" shape="poly">
  <area href="build?id=22" <?php echo $BuildingTitle_22;?> coords="270,69,270,15,345,15,345,69,308,90" shape="poly">
  <area href="build?id=23" <?php echo $BuildingTitle_23;?> coords="327,117,327,63,402,63,402,117,365,138" shape="poly">
  <area href="build?id=24" <?php echo $BuildingTitle_24;?> coords="14,129,14,75,89,75,89,129,52,150" shape="poly">
  <?php if( (!$data['is_special_village']) ){ ?>

      <area href="build?id=25" <?php echo $BuildingTitle_25;?> coords="97,137,97,83,172,83,172,137,135,158" shape="poly">
  <?php } ?>


  <?php if( (!$data['is_special_village']) ){ ?>

      <area href="build?id=26" <?php echo $BuildingTitle_26;?> coords="182,119,182,65,257,65,257,119,220,140" shape="poly">
  <?php } ?>

  <area href="build?id=27" <?php echo $BuildingTitle_27;?> coords="337,156,375,136,411,156,375,177" shape="poly">
  <area href="build?id=28" <?php echo $BuildingTitle_28;?> coords="2,199,2,145,77,145,77,199,40,220" shape="poly">
  <?php if( (!$data['is_special_village']) ){ ?>

      <area href="build?id=29" <?php echo $BuildingTitle_29;?> coords="129,164,129,110,204,110,204,164,167,185" shape="poly">
  <?php } ?>


  <?php if( (!$data['is_special_village']) ){ ?>

      <area href="build?id=30" <?php echo $BuildingTitle_30;?> coords="92,189,92,135,167,135,167,189,130,210" shape="poly">
  <?php } ?>

  <area href="build?id=31" <?php echo $BuildingTitle_31;?> coords="342,216,380,196,416,216,380,237" shape="poly">
  <area href="build?id=32" <?php echo $BuildingTitle_32;?> coords="22,238,60,218,96,238,60,259" shape="poly">
  <?php if( (!$data['is_special_village']) ){ ?>

      <area href="build?id=33" <?php echo $BuildingTitle_33;?> coords="167,232,205,212,241,232,205,253" shape="poly">
  <?php } ?>

  <area href="build?id=34" <?php echo $BuildingTitle_34;?> coords="290,251,328,231,364,251,328,272" shape="poly">
  <area href="build?id=35" <?php echo $BuildingTitle_35;?> coords="95,273,133,253,169,273,133,294" shape="poly">
  <area href="build?id=36" <?php echo $BuildingTitle_36;?> coords="222,284,260,264,296,284,260,305" shape="poly">
  <area href="build?id=37" <?php echo $BuildingTitle_37;?> coords="80,306,118,286,154,306,118,327" shape="poly">
  <area href="build?id=38" <?php echo $BuildingTitle_38;?> coords="199,316,237,296,273,316,237,337" shape="poly">
   <area href="build?id=39" <?php echo $BuildingTitle_39;?> coords="270,158,303,135,316,155,318,178,304,211,288,227,263,238,250,215" shape="poly">
   <area href="build?id=40"  <?php echo $BuildingTitle_40;?> coords="312,338,347,338,377,320,406,288,421,262,421,222,396,275,360,311" shape="poly">
   <area href="build?id=40" <?php echo $BuildingTitle_40;?> coords="49,338,0,274,0,240,33,286,88,338" shape="poly">
   <area href="build?id=40" <?php echo $BuildingTitle_40;?> coords="0,144,34,88,93,39,181,15,252,15,305,31,358,63,402,106,421,151,421,93,378,47,280,0,175,0,78,28,0,92" shape="poly">
 </map>
 <div id="village_map" class="<?php echo $getWallCssName;?>">
  <?php if( ($data['is_special_village'] && $buildings["25"]['item_id'] == 40) ){ ?>

      <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="<?php echo $BuildingTitleClass_25;?>" style="position:absolute; z-index:20; left:161px;" width="214">
  <?php } ?>

  <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="building d1 <?php echo $BuildingTitleClass_19;?>" />
  <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="building d2 <?php echo $BuildingTitleClass_20;?>" />
  <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="building d3 <?php echo $BuildingTitleClass_21;?>" />
  <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="building d4 <?php echo $BuildingTitleClass_22;?>" />
  <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="building d5 <?php echo $BuildingTitleClass_23;?>" />
  <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="building d6 <?php echo $BuildingTitleClass_24;?>" />
  <?php if( (!$data['is_special_village']) ){ ?>

      <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="building d7 <?php echo $BuildingTitleClass_25;?>">
  <?php } ?>


  <?php if( (!$data['is_special_village']) ){ ?>

      <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="building d8 <?php echo $BuildingTitleClass_26;?>" />
  <?php } ?>

  <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="building d9 <?php echo $BuildingTitleClass_27;?>" />
  <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="building d10 <?php echo $BuildingTitleClass_28;?>" />
  <?php if( (!$data['is_special_village']) ){ ?>

      <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="building d11 <?php echo $BuildingTitleClass_29;?>">
  <?php } ?>


  <?php if( (!$data['is_special_village']) ){ ?>

      <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="building d12 <?php echo $BuildingTitleClass_30;?>" />
  <?php } ?>

  <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="building d13 <?php echo $BuildingTitleClass_31;?>">
  <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="building d14 <?php echo $BuildingTitleClass_32;?>">
  <?php if( (!$data['is_special_village']) ){ ?>

      <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="building d15 <?php echo $BuildingTitleClass_33;?>">
  <?php } ?>

  <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="building d16 <?php echo $BuildingTitleClass_34;?>">
  <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="building d17 <?php echo $BuildingTitleClass_35;?>">
  <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="building d18 <?php echo $BuildingTitleClass_36;?>">
  <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="building d19 <?php echo $BuildingTitleClass_37;?>">
  <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="building d20 <?php echo $BuildingTitleClass_38;?>">
  <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="dx1 <?php echo $BuildingTitleClass_39;?>">
  <div id="levels" class="<?php echo $showLevelsStr;?>">
    <?php $counter1=-1; if( isset($buildings_array) && is_array($buildings_array) && sizeof($buildings_array) ) foreach( $buildings_array as $key1 => $value1 ){ $counter1++; ?>

    <div class="<?php echo $key1;?>"><?php echo $value1;?></div>
    <?php } ?>

  </div>
  <img class="map1" usemap="#map1" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="">
  <img class="map2" usemap="#map2" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="">
</div>
<img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" id="lswitch" class="<?php echo $showLevelsStr;?>" onclick="toggleLevels()" alt="">
  <?php if( ($QS_BUILD_CREATEUPGRADE) ){ ?>

      <table cellpadding="1" cellspacing="1" id="building_contract">
        <thead>
          <tr>
            <th colspan="3"> <?php  echo LANGUI_VIL2_T3;?> :
                <?php if( (!$data['is_special_village'] && $gameMetadata['plusTable'][5]['cost'] <= $data['gold_num']) ){ ?>

                    <a href="village2?bfs=5&k=<?php echo $data["update_key"];?>" title="<?php  echo LANGUI_VIL2_T1;?>">
                      <img class="clock" alt="<?php  echo LANGUI_VIL2_T1;?>" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>">
                    </a>
                <?php } ?>

           </th>
          </tr>
        </thead>
        <tbody>
            <?php $counter1=-1; if( isset($tmpBuilding) && is_array($tmpBuilding) && sizeof($tmpBuilding) ) foreach( $tmpBuilding as $key1 => $value1 ){ $counter1++; ?>

            <tr>
                <td class="ico">
                    <a href="village1?id=<?php echo $value1["id"];?>&d&k=<?php echo $data["update_key"];?>">
                        <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="del" title="<?php  echo LANGUI_VIL1_T17;?>" alt="<?php  echo LANGUI_VIL1_T17;?>">
                    </a>
                </td>
                <td>
                    <?php echo $value1["item_id_title"];?> (<?php  echo level_lang;?>  <?php echo $value1["level"];?>)
                </td>
                <td>
                    <?php  echo time_remain_lang;?>

                    <span id="timer1">
                        <?php echo $value1["remainingSeconds"];?>

                    </span>
                    <?php  echo time_hour_lang;?>

                </td>
            </tr>
            <?php } ?>

      </tbody>
    </table>
  <?php } ?>

<p></p>
<p></p>
</body>
</html>