<?php if(!class_exists('raintpl')){exit;}?><!DOCTYPE html>

<html lang="ar">

<head>

    <meta charset="UTF-8">

    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

</head>

<body>
<?php echo load_lang('ui/artefacts'); ?>

<div id="textmenu">
  <a href="build?id=<?php echo $buildingIndex;?>" <?php if( ($selectedTabIndex == 0) ){ ?> class="selected" <?php } ?>><?php  echo LANGUI_ART_9;?></a> |
  <a href="build?id=<?php echo $buildingIndex;?>&t=1" <?php if( ($selectedTabIndex == 1) ){ ?> class="selected" <?php } ?>><?php  echo LANGUI_ART_size_1;?></a> |
  <a href="build?id=<?php echo $buildingIndex;?>&t=2" <?php if( ($selectedTabIndex == 2) ){ ?> class="selected" <?php } ?>><?php  echo LANGUI_ART_size_2;?></a> |
  <a href="build?id=<?php echo $buildingIndex;?>&t=3" <?php if( ($selectedTabIndex == 3) ){ ?> class="selected" <?php } ?>><?php  echo LANGUI_ART_size_3;?></a>
</div>
<?php if( $selectedTabIndex == 0 ){ ?>

    <table id="own" cellpadding="1" cellspacing="1">
        <thead>
            <tr>
                <th colspan="4"><?php  echo LANGUI_ART_9;?></th>
            </tr>
            <tr>
                <td></td>
                <td><?php  echo LANGUI_ART_10;?></td>
                <td><?php  echo LANGUI_ART_11;?></td>
                <td><?php  echo LANGUI_ART_12;?></td>
            </tr>
        </thead>
        <tbody>
            <tr>
            <?php if( !$Artefacts ){ ?>

                <td colspan="4" class="none"><?php  echo LANGUI_ART_13;?></td>
            <?php }else{ ?>

                <td class="icon">
                    <img class="artefact_icon_<?php echo $Artefacts["type"];?>" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>">
                </td>
                <td class="nam">
                    <a href="build?id=<?php echo $buildingIndex;?>&t=4&show=<?php echo $Artefacts["id"];?>"><?php echo constant('LANGUI_ART_name_'.$Artefacts["type"]); ?></a>
                    <span class="bon"><?php echo constant('LANGUI_ART_effect_'.$Artefacts["type"].'_'.$Artefacts["size"]); ?></span>
                    <div class="info">
                        <?php  echo item_27;?> <b><?php if( $Artefacts["size"] == 1 ){ ?>10<?php }else{ ?>20<?php } ?></b>, <?php  echo LANGUI_ART_14;?> <b><?php if( $Artefacts["size"] == 1 ){ ?><?php  echo LANGUI_ART_17;?><?php }else{ ?><?php  echo LANGUI_ART_18;?><?php } ?></b>
                    </div>
                </td>
                <td class="pla">
                    <a href="village3?id=<?php echo $data["selected_village_id"];?>"><?php echo $data["village_name"];?></a>
                </td>
                <td class="dist"><?php echo $Artefacts["mdate"];?></td>
            <?php } ?>

            </tr>
        </tbody>
    </table>
<?php }elseif( $selectedTabIndex <= 3 ){ ?>

    <table id="show_artefacts" cellpadding="1" cellspacing="1">
        <thead>
            <tr>
                <th colspan="5"><?php echo constant('LANGUI_ART_size_'.$selectedTabIndex); ?></th>
            </tr>
            <tr>
                <td></td>
                <td><?php  echo LANGUI_ART_10;?></td>
                <td><?php  echo LANGUI_ART_11;?></td>
                <td><?php  echo LANGUI_ART_15;?></td>
                <td><?php  echo LANGUI_ART_16;?></td>
            </tr>
        </thead>
        <tbody>
        <?php $f = 0;?>

        <?php $counter1=-1; if( isset($Artefacts) && is_array($Artefacts) && sizeof($Artefacts) ) foreach( $Artefacts as $key1 => $value1 ){ $counter1++; ?>

            <tr>
                <td class="icon">
                    <img class="artefact_icon_<?php echo $value1["type"];?>" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>">
                </td>
                <td class="nam">
                    <a href="build?id=<?php echo $buildingIndex;?>&t=4&show=<?php echo $value1["id"];?>"><?php echo $value1["name"];?></a>
                    <span class="bon"><?php echo constant('LANGUI_ART_effect_'.$value1["type"].'_'.$selectedTabIndex); ?></span>
                    <div class="info"><?php  echo item_27;?> <b><?php if( $selectedTabIndex == 1 ){ ?>10<?php }else{ ?>20<?php } ?></b>, <?php  echo LANGUI_ART_14;?> <b><?php if( $selectedTabIndex == 1 ){ ?><?php  echo LANGUI_ART_17;?><?php }else{ ?><?php  echo LANGUI_ART_18;?><?php } ?></b></div>
                </td>
                <td class="vil">
                    <a href="village3?id=<?php echo $value1["village_id"];?>"><?php echo $value1["village_name"];?></a>
                </td>
                <td class="pla">
                    <a href="profile?uid=<?php echo $value1["player_id"];?>"><?php echo $value1["player_name"];?></a>
                </td>
                <td class="dist"><?php echo $value1["dist"];?></td>
            </tr>
        <?php if( $key1/$value1["type"] == 4 && $selectedTabIndex != 3 ){ ?>

            <tr><td colspan="5"></td></tr>
        <?php } ?>

        <?php if( $selectedTabIndex == 3 ){ ?>

            <tr><td colspan="5"></td></tr>
        <?php } ?>

        <?php $f = 1;?>

        <?php } ?>

        <?php if( !$f ){ ?>

            <tr><td colspan="5" class="none"><?php  echo LANGUI_ART_19;?></td></tr>
        <?php } ?>

        </tbody>
    </table>
<?php }elseif( $selectedTabIndex == 4 && $Artefacts ){ ?>

    <div class="artefact image-<?php echo $Artefacts["type"];?>"></div>
        <table id="art_details" cellpadding="1" cellspacing="1">
            <thead>
                <tr>
                    <th colspan="2"><?php echo $Artefacts["name"];?></th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td colspan="2" class="desc">
                        <span class="detail"><?php echo $Artefacts["desc"];?></span>
                    </td>
                </tr>
                <tr>
                    <th><?php  echo LANGUI_ART_15;?></th>
                    <td>
                        <a href="profile?uid=<?php echo $Artefacts["player_id"];?>"><?php echo $Artefacts["player_name"];?></a>
                    </td>
                </tr>
                <tr>
                    <th><?php  echo LANGUI_ART_11;?></th>
                    <td>
                        <a href="village3?id=<?php echo $Artefacts["village_id"];?>"><?php echo $Artefacts["village_name"];?></a>
                    </td>
                </tr>
                <tr>
                    <th><?php  echo LANGUI_ART_20;?></th>
                    <td>
                        <a href="alliance?id=<?php echo $Artefacts["alliance_id"];?>"><?php echo $Artefacts["alliance_name"];?></a>
                    </td>
                </tr>
                <tr>
                    <th><?php  echo LANGUI_ART_14;?></th>
                    <td><?php if( $Artefacts["size"] == 1 ){ ?><?php  echo LANGUI_ART_17;?><?php }else{ ?><?php  echo LANGUI_ART_18;?><?php } ?></td>
                </tr>

                <tr>
                    <th><?php  echo LANGUI_ART_21;?></th>
                    <td><?php echo constant('LANGUI_ART_effect_'.$Artefacts["type"].'_'.$Artefacts["size"]); ?></td>
                </tr>
                <tr>
                    <th><?php  echo LANGUI_ART_22;?></th>
                    <td><?php  echo item_27;?> <b><?php if( $Artefacts["size"] == 1 ){ ?>10<?php }else{ ?>20<?php } ?></b></td>
                </tr>
                <tr>
                    <th><?php  echo LANGUI_ART_12;?></th>
                    <td><?php echo $Artefacts["date"];?></td>
                </tr>
                <tr>
                    <th><?php  echo LANGUI_ART_23;?></th>
                    <td><?php echo $Artefacts["date"];?></td>
                </tr>
            </tbody>
        </table>
<?php } ?>

</body>
</html>