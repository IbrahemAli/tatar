<?php if(!class_exists('raintpl')){exit;}?><!DOCTYPE html>

<html lang="ar">

<head>

    <meta charset="UTF-8">

    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

</head>

<body>
<?php echo load_lang('ui/plus'); ?>

    <h1>
        <p>
		    <b><?php  echo LANGUI_PLUS_T1;?> <font color="#FF6F0F"><?php  echo LANGUI_PLUS_T2;?></font></b>
		</p>
	</h1>
	<div id="textmenu">
	    <a href="plus"<?php if( ($selectedTabIndex == 0) ){ ?> class="selected" <?php } ?>><?php  echo LANGUI_PLUS_T3;?></a> |
		<a href="plus?t=1"<?php if( ($selectedTabIndex == 1) ){ ?> class="selected" <?php } ?>><?php  echo LANGUI_PLUS_T4;?></a> |
		<a href="plus?t=2"<?php if( ($selectedTabIndex == 2) ){ ?> class="selected" <?php } ?>><?php  echo LANGUI_PLUS_T5;?></a> |
		<a href="plus?t=3"<?php if( ($selectedTabIndex == 3) ){ ?> class="selected" <?php } ?>><?php  echo LANGUI_INVITE_T1;?></a> |
		<a href="plus?t=4"<?php if( ($selectedTabIndex == 4) ){ ?> class="selected" <?php } ?>><?php  echo LANGUI_TRANS_T11;?></a> |
		<a href="plus?t=5"<?php if( ($selectedTabIndex == 5) ){ ?> class="selected" <?php } ?>><?php  echo LANGUI_BAY_T10;?></a>
	</div>
<?php if( ($selectedTabIndex == 0) ){ ?>

<?php if( ($packageIndex == '') ){ ?>

    <table class="rate_details lang_rtl lang_ar" cellpadding="1" cellspacing="1">
        <thead>
		    <tr>
			    <th colspan="2"><?php echo $G2A["name"];?></th>
			</tr>
		</thead>
		<tbody>
		    <tr>
              	<td class="desc">
	              <?php echo constant('payments_' . $G2A["name"] . '_description'); ?>

	              <br />
	              <a href="plus?id=<?php echo $G2A["name"];?>">
	              	<img src="<?php echo add_style($G2A["image"], ASSETS_DIR.'default/plus/'); ?>" style="width:255px; height:79px;" alt="<?php echo $G2A["name"];?>" >
	              </a>
	              <br />
	          </td>
      		</tr>
  		</tbody>
	</table>
<!--    <table class="rate_details lang_rtl lang_ar" cellpadding="1" cellspacing="1">
        <thead>
		    <tr>
			    <th colspan="2">2 . التحويل البنكي</th>
			</tr>
		</thead>
		<tbody>
		    <tr>
              	<td class="desc">
	              التحويل البنكي داخل السعودية اسهل بكثير من الطرق الالكترونية يوجد قائمة بكل البنوك السعوديه يمكنك اختيار الافضل
				  <br />
				  <br />
	              <a href="bank" onclick="window.open('bank','tgpay','scrollbars=yes,status=yes,resizable=yes,toolbar=yes,width=800,height=600');return false;">قائمة بالاسعار والحسابات البنكية
	              </a>
				  
	              <br />
	          </td>
      		</tr>
  		</tbody>
	</table> -->
   <?php }else{ ?>

   <div id="products">
       <?php $counter1=-1; if( isset($packages) && is_array($packages) && sizeof($packages) ) foreach( $packages as $key1 => $value1 ){ $counter1++; ?>

            <table class="product lang_rtl lang_ar" cellpadding="1" cellspacing="1">
			    <thead>
				    <tr>
					    <th><?php echo $value1["name"];?></th>
					</tr>
				</thead>
				<tbody>
				    <tr>
					    <td class="pic">
							<a href="#" onclick="window.open('payment?pg=<?php echo $value1["id"];?>','tgpay','scrollbars=yes,status=yes,resizable=yes,toolbar=yes,width=800,height=600');return false;">
						    	<img src="<?php echo add_style($value1["image"], ASSETS_DIR.'/default/plus/'); ?>" style="width:100px;height:100px;" alt="<?php echo $value1["name"];?>">
						    </a>
						</td>
					</tr>
					<tr>
					    <td><s><?php echo $value1["gold"];?> <?php  echo LANGUI_PLUS_T6;?></s></td>
					</tr>
					<tr>
					    <td><?php echo $value1["gold"] + ($value1["gold"]*($value1["bonus"] + $G2A["bonus"]))/100;?> <?php  echo LANGUI_PLUS_T6;?></td>
					</tr>
					<tr>
					    <td><?php echo $value1["cost"];?> <?php echo $G2A["currency"];?></td>
					</tr>
					<tr>
					    <td>
						    <a href="#" onclick="window.open('payment?pg=<?php echo $value1["id"];?>','tgpay','scrollbars=yes,status=yes,resizable=yes,toolbar=yes,width=800,height=600');return false;"><?php  echo LANGUI_PLUS_T7;?></a>
						</td>
					</tr>
				</tbody>
			</table>
        <?php } ?>

		
        <div class="clear"></div>
	</div>
	
<?php } ?>


  <?php }elseif( ($selectedTabIndex == 1) ){ ?>

    <table id="plus_features" class="features" cellpadding="1" cellspacing="1">
	    <thead>
		    <tr>
			    <th colspan="2">
				    <p class="custDir"><?php  echo LANGUI_PLUS_T8;?></p>
				</th>
			</tr>
		</thead>
		<tbody>
		    <tr>
			    <td colspan="2" class="empty"></td>
			</tr>
			<tr>
			    <th colspan="2"><?php  echo LANGUI_PLUS_T9;?></th>
			</tr>
			<tr>
			    <td class="preview">
				    <img class="p1" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo LANGUI_PLUS_T9;?>" title="<?php  echo LANGUI_PLUS_T9;?>">
				</td>
				<td class="text"><?php  echo LANGUI_PLUS_T10;?></td>
			</tr>
			<tr>
			    <td colspan="2" class="empty"></td>
			</tr>
			<tr>
			    <th colspan="2"><?php  echo LANGUI_PLUS_T11;?></th>
			</tr>
			<tr>
			    <td class="preview">
				    <img class="xxl_map" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo LANGUI_PLUS_T11;?>" title="<?php  echo LANGUI_PLUS_T11;?>">
				</td>
				<td class="text"><?php  echo LANGUI_PLUS_T12;?></td>
			</tr>
			<tr>
			    <td colspan="2" class="empty"></td>
			</tr>
			<tr>
			    <th colspan="2"><?php  echo LANGUI_PLUS_T13;?></th>
			</tr>
			<tr>
			    <td class="preview">
				    <img class="p7" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo LANGUI_PLUS_T13;?>" title="<?php  echo LANGUI_PLUS_T13;?>">
				</td>
				<td class="text"><?php  echo LANGUI_PLUS_T14;?></td>
			</tr>
			<tr>
			    <td colspan="2" class="empty"></td>
			</tr>
			<tr>
			    <th colspan="2"><?php  echo LANGUI_PLUS_T15;?></th>
			</tr>
			<tr>
			    <td class="preview">
				    <img class="p8" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo LANGUI_PLUS_T15;?>" title="<?php  echo LANGUI_PLUS_T15;?>">
		        </td>
				<td class="text"><?php  echo LANGUI_PLUS_T16;?></td>
			</tr>
		</tbody>
	</table>
	<table id="gold_features" class="features" cellpadding="1" cellspacing="1">
	    <thead>
		    <tr>
			    <th colspan="2"><?php  echo LANGUI_PLUS_T17;?></th>
			</tr>
		</thead>
		<tbody>
		    <tr>
			    <td colspan="2" class="empty"></td>
			</tr>
			<tr>
			    <th colspan="2"><?php  echo LANGUI_PLUS_T18;?></th>
			</tr>
			<tr>
			    <td class="preview">
				    <img class="p1_25" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo LANGUI_PLUS_T18;?>" title="<?php  echo LANGUI_PLUS_T18;?>">
				</td>
				<td class="text"><?php  echo LANGUI_PLUS_T19;?></td>
			</tr>
			<tr>
			    <td colspan="2" class="empty"></td>
			</tr>
			<tr>
			    <th colspan="2"><?php  echo LANGUI_PLUS_T20;?></th>
			</tr>
			<tr>
			    <td class="preview">
				    <img class="p2_25" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo LANGUI_PLUS_T20;?>" title="<?php  echo LANGUI_PLUS_T20;?>">
				</td>
				<td class="text"><?php  echo LANGUI_PLUS_T21;?></td>
			</tr>
			<tr>
			    <td colspan="2" class="empty"></td>
			</tr>
			<tr>
			    <th colspan="2"><?php  echo LANGUI_PLUS_T22;?></th>
			</tr>
			<tr>
			    <td class="preview">
				    <img class="p3_25" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo LANGUI_PLUS_T22;?>" title="<?php  echo LANGUI_PLUS_T22;?>">
				</td>
				<td class="text"><?php  echo LANGUI_PLUS_T23;?></td>
			</tr>
			<tr>
			    <td colspan="2" class="empty"></td>
			</tr>
			<tr>
			    <th colspan="2"><?php  echo LANGUI_PLUS_T24;?></th>
		    </tr>
			<tr>
			    <td class="preview">
				    <img class="p4_25" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo LANGUI_PLUS_T24;?>" title="<?php  echo LANGUI_PLUS_T24;?>">
				</td>
				<td class="text"><?php  echo LANGUI_PLUS_T25;?></td>
			</tr>
			<tr>
			    <td colspan="2" class="empty"></td>
			</tr>
			<tr>
			    <th colspan="2"><?php  echo LANGUI_PLUS_T26;?></th>
			</tr>
			<tr>
			    <td class="preview">
				    <img class="bau0" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo LANGUI_PLUS_T26;?>" title="<?php  echo LANGUI_PLUS_T26;?>">
				</td>
			    <td class="text"><?php  echo LANGUI_PLUS_T27;?></td>
			</tr>
			<tr>
			    <td colspan="2" class="empty"></td>
			</tr>
			<tr>
			    <th colspan="2"><?php  echo LANGUI_PLUS_T45;?></th>
			</tr>
			<tr>
			    <td class="preview">
				    <img class="gid19" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo LANGUI_PLUS_T45;?>" title="<?php  echo LANGUI_PLUS_T45;?>">
			    </td>
				<td class="text"><?php  echo LANGUI_PLUS_T46;?></td>
			</tr>
			<tr>
			    <td colspan="2" class="empty"></td>
			</tr>
			<tr>
			    <th colspan="2"><?php  echo LANGUI_PLUS_T28;?></th>
			</tr>
			<tr>
			    <td class="preview">
				    <img class="npc" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo LANGUI_PLUS_T28;?>" title="<?php  echo LANGUI_PLUS_T28;?>">
				</td>
				<td class="text"><?php  echo LANGUI_PLUS_T29;?></td>
		    </tr>
		</tbody>
	</table>
<?php }elseif( ($selectedTabIndex == 2) ){ ?>

    <script type="text/javascript">
		function payResources(id)
		{
			var txt = _(id);
			if (txt != null)
			{
				window.location = "plus?t=2&a=9&k=<?php echo $data["update_key"];?>&gold=" + txt.value;
			}
		}
	</script>
    <p><?php if( (0 < $data["gold_num"]) ){ ?> <?php  echo LANGUI_PLUS_T30;?> <?php echo $data["gold_num"];?> <?php  echo LANGUI_PLUS_T31;?> <?php }else{ ?> <?php  echo LANGUI_PLUS_T32;?> <?php } ?></p>
	<table class="plusFunctions" cellpadding="1" cellspacing="1">
	    <thead>
		    <tr>
			    <th colspan="5"><?php  echo LANGUI_PLUS_T33;?></th>
		    </tr>
			<tr>
			    <td></td>
				<td><?php  echo LANGUI_PLUS_T34;?></td>
				<td><?php  echo text_period_lang;?></td>
				<td><?php  echo LANGUI_PLUS_T2;?></td>
				<td><?php  echo LANGUI_PLUS_T35;?></td>
			</tr>
		</thead>
		<tbody>
		    <tr>
			    <td class="man">
				    <a href="#" onclick="return showManual(5,0);">
					    <img class="help" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="" title="">
					</a>
				</td>
				<td class="desc">
				    <p>
					    <b>
						    <font color="#71D000"><?php  echo LANGUI_PLUS_T36;?></font>
						</p>
					<br>
					<span class="run"> <?php echo $PlusTime0;?></span>
				</td>
				<td class="dur"><?php if( ($plusTable["0"]["time"] == 0) ){ ?> <?php  echo LANGUI_PLUS_T37;?> <?php }else{ ?> <?php echo $plusTable["0"]["time"];?> <?php  echo LANGUI_PLUS_T38;?> <?php } ?></td>
				<td class="cost"><img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="gold" alt="<?php  echo LANGUI_PLUS_T6;?>" title="<?php  echo LANGUI_PLUS_T6;?>"><?php echo $plusTable["0"]["cost"];?></td>
			    <td class="act"><?php echo $PlusAction0;?></td>
			</tr>
			<tr>
			    <td colspan="5" class="empty"></td>
			</tr>
			<tr>
			    <td class="man">
				    <a href="#" onclick="return showManual(5,1);"><img class="help" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="" title=""></a>
				</td>
				<td class="desc">+<b>1000</b>% <img class="r1" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo item_title_1;?>" title="<?php  echo item_title_1;?>"><?php  echo LANGUI_PLUS_T39;?>

                <br>
				<span class="run"> <?php echo $PlusTime1;?></span>
				</td>
				<td class="dur"><?php if( ($plusTable["1"]["time"] == 0) ){ ?> <?php  echo LANGUI_PLUS_T37;?> <?php }else{ ?> <?php echo $plusTable["1"]["time"];?> <?php  echo LANGUI_PLUS_T38;?> <?php } ?></td>
				<td class="cost"><img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="gold" alt="<?php  echo LANGUI_PLUS_T6;?>" title="<?php  echo LANGUI_PLUS_T6;?>"><?php echo $plusTable["1"]["cost"];?></td>
				<td class="act"><?php echo $PlusAction1;?></td>
			</tr>
			<tr>
			    <td class="man">
				    <a href="#" onclick="return showManual(5,2);"><img class="help" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="" title=""></a>
				</td>
				<td class="desc">+<b>1000</b>% <img class="r2" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo item_title_2;?>" title="<?php  echo item_title_2;?>"><?php  echo LANGUI_PLUS_T40;?>

                <br>
                <span class="run"> <?php echo $PlusTime2;?></span>
				</td>
				<td class="dur"><?php if( ($plusTable["2"]["time"] == 0) ){ ?> <?php  echo LANGUI_PLUS_T37;?> <?php }else{ ?> <?php echo $plusTable["2"]["time"];?> <?php  echo LANGUI_PLUS_T38;?> <?php } ?></td>
				<td class="cost"><img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="gold" alt="<?php  echo LANGUI_PLUS_T6;?>" title="<?php  echo LANGUI_PLUS_T6;?>"><?php echo $plusTable["2"]["cost"];?></td>
				<td class="act"><?php echo $PlusAction2;?></td>
			</tr>
			<tr>
			    <td class="man">
				    <a href="#" onclick="return showManual(5,3);"><img class="help" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="" title=""></a>
				</td>
				<td class="desc">+<b>1000</b>% <img class="r3" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo item_title_3;?>" title="<?php  echo item_title_3;?>"><?php  echo LANGUI_PLUS_T41;?>

                <br>
                <span class="run"> <?php echo $PlusTime3;?></span>
				</td>
				<td class="dur"><?php if( ($plusTable["3"]["time"] == 0) ){ ?> <?php  echo LANGUI_PLUS_T37;?> <?php }else{ ?> <?php echo $plusTable["3"]["time"];?> <?php  echo LANGUI_PLUS_T38;?> <?php } ?></td>
				<td class="cost"><img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="gold" alt="<?php  echo LANGUI_PLUS_T6;?>" title="<?php  echo LANGUI_PLUS_T6;?>"><?php echo $plusTable["3"]["cost"];?></td>
				<td class="act"><?php echo $PlusAction3;?></td>
			</tr>
			<tr>
			    <td class="man">
				    <a href="#" onclick="return showManual(5,4);"><img class="help" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="" title=""></a>
				</td>
				<td class="desc">+<b>1000</b>% <img class="r4" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo item_title_4;?>" title="<?php  echo item_title_4;?>"><?php  echo LANGUI_PLUS_T42;?>

                <br>
                <span class="run"> <?php echo $PlusTime4;?></span>
				</td>
				<td class="dur"><?php if( ($plusTable["4"]["time"] == 0) ){ ?> <?php  echo LANGUI_PLUS_T37;?> <?php }else{ ?> <?php echo $plusTable["4"]["time"];?> <?php  echo LANGUI_PLUS_T38;?> <?php } ?></td>
				<td class="cost"><img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="gold" alt="<?php  echo LANGUI_PLUS_T6;?>" title="<?php  echo LANGUI_PLUS_T6;?>"><?php echo $plusTable["4"]["cost"];?></td>
				<td class="act"><?php echo $PlusAction4;?></td>
			</tr>
			<tr>
			    <td colspan="5" class="empty"></td>
			</tr>
			<tr>
			    <td class="man">
				    <a href="#" onclick="return showManual(5,5);"><img class="help" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="" title=""></a>
			    </td>
			    <td class="desc"><?php  echo LANGUI_PLUS_T43;?></td>
			    <td class="dur"><?php if( ($plusTable["5"]["time"] == 0) ){ ?> <?php  echo LANGUI_PLUS_T37;?> <?php }else{ ?> <?php echo $plusTable["5"]["time"];?> <?php  echo LANGUI_PLUS_T38;?> <?php } ?></td>
			    <td class="cost"><img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="gold" alt="<?php  echo LANGUI_PLUS_T6;?>" title="<?php  echo LANGUI_PLUS_T6;?>"><?php echo $plusTable["5"]["cost"];?></td>
			    <td class="act"><?php echo $PlusAction5;?></td>
			</tr>
			<tr>
			    <td class="man">
				    <a href="#" onclick="return showManual(5,7);"><img class="help" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="" title=""></a>
				</td>
				<td class="desc"><?php  echo LANGUI_PLUS_T44;?></td>
				<td class="dur"><?php if( ($plusTable["6"]["time"] == 0) ){ ?> <?php  echo LANGUI_PLUS_T37;?> <?php }else{ ?> <?php echo $plusTable["6"]["time"];?> <?php  echo LANGUI_PLUS_T38;?> <?php } ?></td>
	            <td class="cost"><img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="gold" alt="<?php  echo LANGUI_PLUS_T6;?>" title="<?php  echo LANGUI_PLUS_T6;?>"><?php echo $plusTable["6"]["cost"];?></td>
				<td class="act"><?php echo $PlusAction6;?></td>
			</tr>
			<tr>
			    <td class="man">
				    <a href="#" onclick="return showManual(5,8);"><img class="help" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="" title=""></a>
				</td>
				<td class="desc"><?php  echo LANGUI_PLUS_T45;?></td>
				<td class="dur"><?php if( ($plusTable["7"]["time"] == 0) ){ ?> <?php  echo LANGUI_PLUS_T37;?> <?php }else{ ?> <?php echo $plusTable["7"]["time"];?> <?php  echo LANGUI_PLUS_T38;?> <?php } ?></td>
	            <td class="cost"><img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="gold" alt="<?php  echo LANGUI_PLUS_T6;?>" title="<?php  echo LANGUI_PLUS_T6;?>"><?php echo $plusTable["7"]["cost"];?></td>
				<td class="act"><?php echo $PlusAction7;?></td>
			</tr>
			<tr>
			    <td class="man">
				    <a href="#" onclick="return showManual(5,9);"><img class="help" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="" title=""></a>
				</td>
				<td class="desc"><?php  echo LANGUI_PLUS_T57;?></td>
				<td class="dur"><?php if( ($plusTable["8"]["time"] == 0) ){ ?> <?php  echo LANGUI_PLUS_T37;?> <?php }else{ ?> <?php echo $plusTable["8"]["time"];?> <?php  echo LANGUI_PLUS_T38;?> <?php } ?></td>
	            <td class="cost"><img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="gold" alt="<?php  echo LANGUI_PLUS_T6;?>" title="<?php  echo LANGUI_PLUS_T6;?>"><?php echo $plusTable["8"]["cost"];?></td>
				<td class="act"><?php echo $PlusAction8;?></td>
			</tr>
			<tr>
			    <td class="man">
				    <a href="#" onclick="return showManual(5,10);"><img class="help" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="" title=""></a>
				</td>
				<td class="desc"><?php  echo LANGUI_PLUS_T58;?></td>
				<td class="dur"><?php  echo LANGUI_PLUS_T37;?></td>
	            <td class="cost"><img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="gold" alt="<?php  echo LANGUI_PLUS_T6;?>" title="<?php  echo LANGUI_PLUS_T6;?>"><?php echo $plusTable["9"]["cost"];?></td>
				<td class="act"><?php if( $data["gold_num"] >= $plusTable["9"]["cost"] ){ ?><img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="gold" alt="<?php  echo LANGUI_PLUS_T6;?>" title="<?php  echo LANGUI_PLUS_T6;?>"><input type="text" style="width:25px;" id="gold" name="gold" value="<?php echo $plusTable["9"]["cost"];?>" title="<?php  echo LANGUI_TRANS_T4;?>" maxlength="4" class="text year"><?php } ?> <?php echo $PlusAction9;?></td>
			</tr>
        </tbody>
	</table>
<?php }elseif( ($selectedTabIndex == 3) ){ ?>

    <h1><?php  echo LANGUI_INVITE_T1;?></h1>
    <br>
    <h3 style="clear:both;"><?php  echo LANGUI_INVITE_T2;?></h3>
    <span class="notice"><?php  echo LANGUI_INVITE_T3;?></span><br>
    <span class="link">https://www.xtatar.com/index?ref=<?php echo $playerId;?></span>
    <h3 style="clear:both;"><?php  echo LANGUI_INVITE_T4;?></h3>
    <?php  echo LANGUI_INVITE_T5;?>

    <br>
<table class="rate_details lang_rtl lang_ar" cellpadding="1" cellspacing="1">
    <thead>
        <tr>
		    <th colspan="6"> <?php  echo LANGUI_INVITE_T6;?> </th>
        </tr>
        <tr>
		    <td><?php  echo LANGUI_INVITE_T7;?></td>
		    <td><?php  echo LANGUI_INVITE_T8;?></td>
		    <td><?php  echo LANGUI_INVITE_T9;?></td>
		    <td><?php  echo LANGUI_INVITE_T10;?></td>
        </tr>
    </thead>
    <tbody>
	<?php $counter1=-1; if( isset($dataList) && is_array($dataList) && sizeof($dataList) ) foreach( $dataList as $key1 => $value1 ){ $counter1++; ?>

        <tr>
            <td><center><?php echo $value1["id"];?></center></td>
            <td><center><?php echo $value1["name"];?></center></td>
            <td><center><?php echo $value1["total_people_count"];?></center></td>
            <td><center><?php echo $value1["villages_count"];?></center></td>
        </tr>
	<?php } ?>

    <?php if( (!$found) ){ ?>

        <tr>
		    <td class="none" colspan="6"><?php  echo LANGUI_INVITE_T11;?></td>
		</tr>
	<?php } ?>

    </tbody>
</table>
<?php }elseif( ($selectedTabIndex == 4) ){ ?>

<br>
<form action="plus?t=4" method="post">
    <table class="rate_details lang_rtl lang_ar" cellpadding="1" cellspacing="1">
        <thead>
            <tr>
		        <th colspan="2"><?php  echo LANGUI_TRANS_T1;?></th>
            </tr>
        </thead>
        <tbody>
            <tr>
			    <td colspan="2"><center><?php  echo LANGUI_TRANS_T2;?><?php echo $goldCantrans;?> <?php  echo text_gold_lang;?></center></td>
			</tr>
            <tr class="top">
		        <td><?php  echo LANGUI_TRANS_T3;?></td>
		        <td><input class="text" type="text" name="name" maxlength="20" value=""></td>
            </tr>
            <tr>
		        <td><?php  echo LANGUI_TRANS_T4;?></td>
		        <td><input class="text" type="text" name="gold" maxlength="10" value=""></td>
            </tr>
            <tr class="btm">
		        <td><?php  echo LANGUI_TRANS_T5;?></td>
		        <td><input class="text" type="password" name="pass" maxlength="25" value=""></td>
            </tr>
        </tbody>
    </table>
    <p class="btn"><center>
        <input type="image" value="" name="s1" id="btn_send" class="dynamic_img" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>">
    </center></p>
</form>
<?php if( ( isset($errorTable) and $errorTable != NULL ) ){ ?>

    <p class="error"><?php echo $errorTable;?></p>
<?php } ?>

<br>
<table id="brought_in" cellpadding="3" cellspacing="1">
	<thead>
		<tr>
			<th colspan="5"><?php  echo LANGUI_PLUS_T49;?></th>
		</tr>
		<tr>
		    <td>#</td>
		    <td><?php  echo LANGUI_PLUS_T59;?></td>
			<td><?php  echo LANGUI_PLUS_T51;?></td>
			<td><?php  echo LANGUI_PLUS_T52;?></td>
			<td><?php  echo LANGUI_PLUS_T53;?></td>
		</tr>
	</thead>
	<?php $counter1=-1; if( isset($dataList) && is_array($dataList) && sizeof($dataList) ) foreach( $dataList as $key1 => $value1 ){ $counter1++; ?>

	    <tr>
	        <td><center><?php echo $key1;?></center></td>
	        <td><center><a href="profile?uid=<?php echo $value1["fromid"];?>"><?php echo $value1["fromnam"];?></a></center></td>
		    <td><center><a href="profile?uid=<?php echo $value1["userid"];?>"><?php echo $value1["usernam"];?></a></center></td>
		    <td><center><?php echo $value1["golds"];?></center></td>
		    <td><center><?php echo $value1["date"];?></center></td>
	    </tr>
    <?php } ?>

    <?php if( (!$found) ){ ?>

        <tr>
		    <td class="none" colspan="5"><center><?php  echo LANGUI_PLUS_T54;?></center></td>
		</tr>
    <?php } ?>

</table>
<table cellpadding="1" cellspacing="1" id="search_navi">
	<tbody>
		<tr>
			<td>
			<div class="navi"><?php echo $getPreviousLink;?>|<?php echo $getNextLink;?></div>
			</td>
		</tr>

	</tbody>
</table>
<?php }elseif( ($selectedTabIndex == 5) ){ ?>

<table id="brought_in" cellpadding="3" cellspacing="1">
	<thead>
		<tr>
			<th colspan="6"><?php  echo LANGUI_BAY_T4;?></th>
		</tr>
		<tr>
			<td>#</td>
			<td><?php  echo LANGUI_BAY_T5;?></td>
			<td><?php  echo LANGUI_BAY_T6;?></td>
			<td><?php  echo LANGUI_BAY_T7;?></td>
			<td><?php  echo LANGUI_BAY_T8;?></td>
			<td><?php  echo LANGUI_BAY_T9;?></td>
		</tr>
	</thead>
	<?php $counter1=-1; if( isset($dataList) && is_array($dataList) && sizeof($dataList) ) foreach( $dataList as $key1 => $value1 ){ $counter1++; ?>

	<tr>
		<td>
			<center><?php echo $key1;?></center>
		</td>
		<td>
			<center><?php echo $value1["transID"];?></center>
		</td>
		<td>
			<center><?php echo $value1["type"];?></center>
		</td>
		<td>
			<center><?php echo $value1["golds"];?></center>
		</td>
		<td>
			<center><?php echo $value1["money"];?> <?php echo $value1["currency"];?></center>
		</td>
		<td>
			<center><?php echo $value1["time"];?></center>
		</td>
	</tr>
	<?php } ?><?php if( (!$found) ){ ?>

	<tr>
		<td class="none" colspan="6">
			<center><?php  echo LANGUI_BAY_T3;?></center>
		</td>
	</tr>
	<?php } ?>

</table>
<table cellpadding="1" cellspacing="1" id="search_navi">
	<tbody>
		<tr>
			<td>
				<div class="navi"><?php echo $getPreviousLink;?>|<?php echo $getNextLink;?></div>
			</td>
		</tr>
	</tbody>
</table>
<?php } ?>

</body>
</html>