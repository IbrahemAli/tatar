<?php if(!class_exists('raintpl')){exit;}?><!DOCTYPE html>

<html lang="ar">

<head>

    <meta charset="UTF-8">

    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

</head>

<body>

<?php echo load_lang('ui/game'); ?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
    <title>العالم رقم (<?php echo $_COOKIE['server'];?>)</title>
    <meta http-equiv="cache-control" content="max-age=0" />
    <meta http-equiv="pragma" content="no-cache" />
    <meta http-equiv="expires" content="0" />
    <meta http-equiv="imagetoolbar" content="no" />
    <meta http-equiv="content-type" content="text/html; charset=UTF-8" />
    <meta content="<?php echo $metatag;?>" name="keywords">
    <link href="<?php echo add_style('lang.css', ASSETS_DIR.'default/lang/'.$lang.'/'); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo add_style('compact.css', ASSETS_DIR.'default/lang/'.$lang.'/'); ?>" rel="stylesheet" type="text/css" />
    <meta name="google-site-verification" content="vTjsRxnpRzHRJvw5E3uOiAA-jcGayHNOw_SEAD93-fc" />
    <link rel="shortcut icon" href="<?php echo add_style('favicon.ico', ASSETS_DIR); ?>" type="image/x-icon" />
    <script type="text/javascript">var d3l= <?php if( $lang == 'ar'  ){ ?>180<?php }else{ ?>-600<?php } ?>;</script>
    <script src="<?php echo add_style('core.js', ASSETS_DIR); ?>" type="text/javascript"></script>

</head>

<body class="v35 webkit">
    <div class="wrapper">
        <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" id="msfilter" alt="" />
        <div id="dynamic_header"></div>
        <div id="header">
            <div id="mtop">
                <?php if( ($player != NULL) ){ ?>

                <a href="village1" id="n1" accesskey="1">
                    <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" title="<?php  echo LANGUI_GAME_ICO1;?>" alt="<?php  echo LANGUI_GAME_ICO1;?>" />
                </a>
                <a href="village2" id="n2" accesskey="2">
                    <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" title="<?php  echo LANGUI_GAME_ICO2;?>" alt="<?php  echo LANGUI_GAME_ICO2;?>" />
                </a>
                <a href="map" id="n3" accesskey="3">
                    <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" title="<?php  echo LANGUI_GAME_ICO3;?>" alt="<?php  echo LANGUI_GAME_ICO3;?>" />
                </a>
                <a href="analytics" id="n4" accesskey="4">
                    <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" title="<?php  echo LANGUI_GAME_ICO4;?>" alt="<?php  echo LANGUI_GAME_ICO4;?>" />
                </a>
                <div id="n5" class="i<?php echo $reportMessageStatus;?>">
                    <a class="reports" href="report" accesskey="5">
                        <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="l" title="<?php  echo LANGUI_GAME_ICO5;?>" alt="<?php  echo LANGUI_GAME_ICO5;?>" />
                    </a>
                    <a class="messages" href="message" accesskey="6">
                        <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="r" title="<?php  echo LANGUI_GAME_ICO6;?>" alt="<?php  echo LANGUI_GAME_ICO6;?>" />
                    </a>
                </div>
                <a href="plus?t=2" id="plus">
                    <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" id="btn_plus" <?php if( ($data['active_plus_account']) ){ ?> class="active" <?php }else{ ?> class="inactive" <?php } ?> title="<?php  echo LANGUI_GAME_ICO7;?>" alt="<?php  echo LANGUI_GAME_ICO7;?>" /> <b><font color="#FF6F0F"><img alt="<?php  echo text_gold_lang;?>" class="gold" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" title="<?php  echo text_gold_lang;?>" /><?php echo $data["gold_num"];?></font></b>
                </a>
                <?php } ?>

                <div class="clear"></div>
            </div>
        </div>
        <div id="mid">
            <div id="side_navi">
                <a id="logo" href="#">
                    <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt=" <?php  echo LANGUI_GAME_GNAME;?>" />
                </a>
                <?php if( ($player != NULL) ){ ?>

                <?php $_d = intval(date('G'));?>

                    <?php if( (6 <= $_d && $_d <= 19) ){ ?>

                    <img class="time_of_day day" title="<?php  echo LANGUI_GAME_MORNING;?>" alt="<?php  echo LANGUI_GAME_MORNING;?>" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" />
                    <?php }else{ ?>

                    <img class="time_of_day night" title="<?php  echo LANGUI_GAME_AFTERNOON;?>" alt="<?php  echo LANGUI_GAME_AFTERNOON;?>" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" />
                    <?php } ?>

                <?php } ?>

                <br>
                <p>
                    <a href="index.php"><?php  echo LANGUI_GAME_MENU1;?></a>
                    <?php if( ($player != NULL) ){ ?>

                    <a href="#" onclick="return showManual(0,0);"><?php  echo LANGUI_GAME_MENU2;?></a>
                    <a href="profile"><?php  echo LANGUI_GAME_MENU3;?></a>
                    <a href="friends?t=1"><?php  echo LANGUI_GAME_MENU5;?> <span style="background-color:green;color:#ffffff;padding:2px;border-radius: 4px;"><?php echo $FriendR;?></span></a>
                    <a href="support"> <b><?php  echo LANGUI_GAME_MENU14;?></b>
                    </a>
                    <a href="logout"><?php  echo LANGUI_GAME_MENU4;?></a>
                </p>
                <p>
                    <a href="plus"><?php  echo LANGUI_GAME_MENU9;?></a>
                </p>
                <?php } ?>

                <?php if( ($player != NULL && $isPlayerInDeletionProgress) ){ ?>

                <p class="deltimer">
                    <a href="profile?t=4">
                        <?php  echo LANGUI_GAME_PLAYERDEL;?>

                        <span id="timer1"><?php echo $getPlayerDeletionTime;?></span>
                        <?php  echo time_hour_lang;?>

                    </a>
                </p>
                <?php } ?>

             
            </div>
            <div id="content" class="<?php echo $contentCssClass;?>">
                <div class="top"></div>
                <?php echo $content;?>

            </div>
            <div id="side_info">
            <?php if( ( $data['guide_quiz'] != GUIDE_QUIZ_COMPLETED && $player != NULL ) ){ ?>

                <div id="anm" style="width:118px; height:142px; visibility: hidden;"></div>
                <div id="qge">
                    <img onclick="showTask();" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" id="qgei" class="<?php echo $getGuideQuizClassName;?>" title="<?php  echo LANGUI_GAME_LMENU1;?>" alt="<?php  echo LANGUI_GAME_LMENU1;?>">
                </div>
                <?php } ?>

                <?php if( ( $player != NULL ) ){ ?>

                    <?php if( ( 1 < sizeof( $playerVillages ) ) ){ ?>

                    <table cellpadding="1" cellspacing="1" id="vlist">
                        <thead>
                            <tr>
                                <td colspan="3">
                                    <b><a href="villages" <?php if( !$data["active_plus_account"] ){ ?> onclick="return showManual(5,0);"<?php } ?>><?php  echo LANGUI_GAME_LMENU2;?>:</a></b>
                                </td>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $counter1=-1; if( isset($playerVillages) && is_array($playerVillages) && sizeof($playerVillages) ) foreach( $playerVillages as $key1 => $value1 ){ $counter1++; ?>

                                <?php $m = new Global_Model();;?>

                                <?php $war9 = $m->IfVillageHasAttak($key1);;?>

                                <tr>
                                    <td class="dot <?php if( $key1 == $data['selected_village_id'] ){ ?>hl<?php } ?>" >?</td>
                                    <td class="link">
                                        <div>
                                            <a href="?vid=<?php echo $key1;?><?php echo $villagesLinkPostfix;?>" >
                                                <?php echo $value1["2"];?>

                                                <?php if( ( $war9 > 0 ) ){ ?>

                                                    <font color="red"><img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="att1" alt="( <?php echo $war9;?> <?php  echo LANGUI_GAME_LMENU5;?> )" title="( <?php echo $war9;?> <?php  echo LANGUI_GAME_LMENU5;?> )"></a></font>
                                                <?php } ?>

                                            </a>
                                        </div>
                                    </td>
                                    <td>
                                        <a href="build?bid=17&vid2=<?php echo $key1;?>">
                                            <img src="<?php echo add_style('6.gif', ASSETS_DIR.'/default/img/r/'); ?>"></a>
                                    </td>
                                    <td>
                                        <a href="v2v?id=<?php echo $key1;?>">
                                            <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="att_all"></a>
                                    </td>
                                    <td>
                                    </td>
                                    <td class="aligned_coords">
                                        <div class="cox">
                                            ( <?php echo $value1["0"];?>

                                        </div>
                                        <div class="pi">|</div>
                                        <div class="coy"><?php echo $value1["1"];?> )</div>
                                    </td>
                                </tr>
                            <?php } ?>

                        </tbody>
                    </table>
                    <?php } ?>


                    <?php if( ( sizeof( $playerLinks ) && $data['active_plus_account'] ) ){ ?>

                    <table id="llist">
                        <thead>
                            <tr>
                                <td colspan="2">
                                    <a href="links">
                                        <?php  echo LANGUI_GAME_LMENU3;?>:
                                    </a>
                                </td>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $counter1=-1; if( isset($playerLinks) && is_array($playerLinks) && sizeof($playerLinks) ) foreach( $playerLinks as $key1 => $value1 ){ $counter1++; ?>

                            <tr>
                                <td class="dot">?</td>
                                <td class="link">
                                    <div>
                                        <a href="<?php echo htmlspecialchars( $value1["linkHref"] );?>" <?php if( ( !$value1["linkSelfTarget"] ) ){ ?>target="_blank"<?php } ?>><?php echo $value1["linkName"];?></a>
                                        <?php if( (!$value1["linkSelfTarget"]) ){ ?>

                                        <img class="external" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo LANGUI_GAME_LMENU4;?>" title="<?php  echo LANGUI_GAME_LMENU4;?>">
                                        <?php } ?>

                                    </div>
                                </td>
                            </tr>
                            <?php } ?>

                        </tbody>
                    </table>
                    <?php } ?>

					<?php } ?>

                </div>
                <div class="clear"></div>
            </div>

            <div class="footer-stopper"></div>
            <div class="clear"></div>
            <div id="footer">
                <div id="mfoot">
                    <div class="footer-menu">
                        <?php $tpl = new RainTPL;$tpl_dir_temp = self::$tpl_dir;$tpl->assign( $this->var );$tpl->draw( dirname("layout/footer") . ( substr("layout/footer",-1,1) != "/" ? "/" : "" ) . basename("layout/footer") );?>

                    </div>
                </div>
                <div id="cfoot"></div>
            </div>
        </div>
        <?php if( ( $player != NULL ) ){ ?>

        <div id="res">
            <div id="resWrap">
                <table cellpadding="1" cellspacing="1">
                    <tbody>
                        <tr class="res">
                            <td>
                                <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="warehouse" alt="<?php  echo item_10;?>" title="<?php  echo item_10;?>" />
                            </td>
                            <td id="warehouse" class="res" title="<?php  echo item_curprod_10;?>"><?php echo $resources["1"]["store_max_limit"];?></td>
                            <td>
                                <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="r1" alt="<?php  echo item_title_1;?>" title="<?php  echo item_title_1;?>" />
                            </td>
                            <td id="l4" class="res" alt="<?php echo $resources["1"]["store_max_limit"];?>" title="<?php echo $resources["1"]["calc_prod_rate"];?>"><?php echo $resources["1"]["current_value"];?></td>
                            <td>
                                <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="r2" alt="<?php  echo item_title_2;?>" title="<?php  echo item_title_2;?>" />
                            </td>
                            <td id="l3" class="res" title="<?php echo $resources["2"]["calc_prod_rate"];?>"><?php echo $resources["2"]["current_value"];?></td>
                            <td>
                                <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="r3" alt="<?php  echo item_title_3;?>" title="<?php  echo item_title_3;?>" />
                            </td>
                            <td id="l2" class="res" title="<?php echo $resources["3"]["calc_prod_rate"];?>"><?php echo $resources["3"]["current_value"];?></td>
                            <td>
                                <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="granary" alt="<?php  echo item_11;?>" title="<?php  echo item_11;?>" />
                            </td>
                            <td id="granary" class="res" title="<?php  echo item_curprod_10;?>"><?php echo $resources["4"]["store_max_limit"];?></td>
                            <td>
                                <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="r4" alt="<?php  echo item_title_4;?>" title="<?php  echo item_title_4;?>" />
                            </td>
                            <td id="l1" class="res" title="<?php echo $resources["4"]["calc_prod_rate"];?>"><?php echo $resources["4"]["current_value"];?></td>
                            <td>
                                <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="r5" alt="<?php  echo LANGUI_GAME_CROPCONSUM;?>" title="<?php  echo LANGUI_GAME_CROPCONSUM;?> <?php echo floor($data["crop_consumption"]*$crop); ?>/<?php echo floor($data["crop_consumption"]*$crop + $resources["4"]["calc_prod_rate"]); ?>" />
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
        <div id="stime">
            <div id="ltime">
                <div id="ltimeWrap">
                    <?php  echo LANGUI_GAME_CALCMS;?>

                    <b>
                        <?php echo $scriptstarttime;?>

                    </b>
                    ms<br />
                    <?php  echo LANGUI_GAME_SRVTIME;?>

                    <span id="timer2" class="b"><?php echo date( "G:i:s" );?></span>
                </div>
            </div>
        </div>
        <?php } ?>

        <div id="ce"></div>
</body>
<script type="text/javascript">init(); <?php if( ($player!= NULL && !$player->isSpy && $data['guide_quiz']==GUIDE_QUIZ_NOTSTARTED) ){ ?>showTask();<?php } ?></script>
</html>
</body>
</html>