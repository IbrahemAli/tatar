<?php if(!class_exists('raintpl')){exit;}?><!DOCTYPE html>

<html lang="ar">

<head>

    <meta charset="UTF-8">

    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

</head>

<body>
<?php echo load_lang('ui/contact'); ?>

<!--Content-->
<div class="wrapper-contact">
    <img src="<?php echo add_style('background-land.jpg', ASSETS_DIR.'indx/images/'); ?>" /></a></li>

</div>

<div class="container-fluid section2 contact-content-container">

    <article class="caption-block">
        <h1 class="caption-heading"><?php  echo LANGUI_CON_T1;?></h1>
        <div class="box-info about-desciption contact-block">
            <div class="pull-right right-block-inside">
                <h1 class="text-center"><?php  echo LANGUI_CON_T2;?></h1>
                <div class="col-md-6 col-xs-12">
                    <p><?php  echo LANGUI_CON_T3;?>

                    </p>
                </div>
                <div class="col-md-6 col-xs-12  contact-details">
                    <p><?php  echo LANGUI_CON_T4;?></p>
                    <p><?php  echo LANGUI_CON_T5;?></p>
                    <p><?php  echo LANGUI_CON_T6;?></p>
                    <p><?php  echo LANGUI_CON_T7;?></p>
                    <p><?php  echo LANGUI_CON_T8;?></p>
                    <p><?php  echo LANGUI_CON_T9;?></p>

                </div>

            </div>
        </div>


    </article>
    <article>
        <div class="box-info about-desciption contact-block-2">
            <div class="contact-form" >
                <h1 class="text-center"><?php  echo LANGUI_CON_T1;?></h1>
                <form id="contact-form" class="validation-form" method="post" action="contact.php" role="form">

                    <div class="messages"></div>

                    <div class="controls">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group textField">
                                    <label for="form_name"><?php  echo LANGUI_CON_T10;?></label>
                                    <input id="form_name" type="text" name="name" class="form-control" placeholder="<?php  echo LANGUI_CON_T15;?> <?php  echo LANGUI_CON_T10;?>"   data-error="<?php  echo LANGUI_CON_T10;?> <?php  echo LANGUI_CON_T17;?>">
                                    <div class="validation">
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group textField">
                                    <label for="form_lastname"><?php  echo LANGUI_CON_T11;?></label>
                                    <input id="form_lastname" type="text" name="surname" class="form-control" placeholder="<?php  echo LANGUI_CON_T15;?>  <?php  echo LANGUI_CON_T11;?>"   data-error="<?php  echo LANGUI_CON_T11;?> <?php  echo LANGUI_CON_T17;?>">
                                    <div class="validation">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group textField">
                                    <label for="form_email"><?php  echo LANGUI_CON_T12;?></label>
                                    <input id="form_email" type="text" name="email" class="form-control" placeholder="<?php  echo LANGUI_CON_T15;?> <?php  echo LANGUI_CON_T12;?>"  data-error="<?php  echo LANGUI_CON_T12;?> <?php  echo LANGUI_CON_T17;?>">
                                    <div class="validation">
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="form_phone"><?php  echo LANGUI_CON_T13;?></label>
                                    <input id="form_phone" type="tel" name="phone" class="form-control" placeholder="<?php  echo LANGUI_CON_T15;?> <?php  echo LANGUI_CON_T13;?>">
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group textField">
                                    <label for="form_message"><?php  echo LANGUI_CON_T14;?></label>
                                    <textarea id="form_message" name="message" class="form-control" placeholder="<?php  echo LANGUI_CON_T15;?> <?php  echo LANGUI_CON_T14;?>" rows="4"   data-error="<?php  echo LANGUI_CON_T14;?> <?php  echo LANGUI_CON_T17;?>"></textarea>
                                    <div class="validation">
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <input type="submit" class="btn default btn-send" value="<?php  echo LANGUI_CON_T16;?>">
                            </div>
                        </div>
                    </div>
                </form>
            </div>

        </div>
    </article>

</div>
</body>
</html>

<!--/Content-->