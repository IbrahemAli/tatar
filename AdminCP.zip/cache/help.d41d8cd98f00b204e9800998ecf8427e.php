<?php if(!class_exists('raintpl')){exit;}?><!DOCTYPE html>

<html lang="ar">

<head>

    <meta charset="UTF-8">

    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

</head>

<body>
<?php echo load_lang('ui/help'); ?>


  <?php if( ($state == 0) ){ ?>

      <h1><img class="point" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="" title="">
      <?php  echo LANGUI_HLP_T1;?>

      </h1><p></p><p>
      <?php  echo LANGUI_HLP_T2;?>.</p><p></p>
      <img class="troops" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo LANGUI_HLP_T3;?>" title="<?php  echo LANGUI_HLP_T3;?>">
      <img class="buildings" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo LANGUI_HLP_T4;?>" title="<?php  echo LANGUI_HLP_T4;?>"><ul>
      <li>
      <?php  echo LANGUI_HLP_T5;?>

      </li><ul>
      <li><a href="?c=1&id=7"><?php  echo tribe_7;?></a></li>
      <li><a href="?c=1&id=1"><?php  echo tribe_1;?></a></li>
      <li><a href="?c=1&id=2"><?php  echo tribe_2;?></a></li>
      <li><a href="?c=1&id=3"><?php  echo tribe_3;?></a></li>
      </ul>
      <br><li>
      <?php  echo LANGUI_HLP_T4;?></li><ul><li><a href="?c=2&id=1"><?php  echo LANGUI_HLP_T6;?></a></li>
      <li><a href="?c=2&id=2"><?php  echo LANGUI_HLP_T7;?></a></li>
      <li><a href="?c=2&id=3"><?php  echo LANGUI_HLP_T8;?></a></li></ul>
      <br><li><a href="manual" target="_blank"><?php  echo LANGUI_HLP_T9;?>

       <img class="external" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo LANGUI_HLP_T10;?>" title="<?php  echo LANGUI_HLP_T10;?>"></a>
       <br><p><br><br>
      <?php  echo LANGUI_HLP_T11;?>.</p></li><br></ul>

      <?php }elseif( ($state == 1) ){ ?>

      <h1><img class="unit uunits" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="" title="">
      <?php  echo LANGUI_HLP_T12;?>(<?php echo merge_manual_text('tribe', $tribeId); ?>)</h1>
      <ul>
      <?php $counter1=-1; if( isset($gameMetadata["troops"]) && is_array($gameMetadata["troops"]) && sizeof($gameMetadata["troops"]) ) foreach( $gameMetadata["troops"] as $key1 => $value1 ){ $counter1++; ?>

        <?php if( $value1["for_tribe_id"] == $tribeId && $value1["is_cavalry"] !== NULL ){ ?>

          <li><a href="?c=3&id=<?php echo $key1;?>"><?php echo merge_manual_text('troop', $key1); ?></a></li>
        <?php } ?>

      <?php } ?>

      </ul>
  <?php }elseif( ($state == 2) ){ ?>

      <?php if( ($buildingGroup == 1) ){ ?>

          <h1><img class="unit ugeb" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="" title="">
          <?php  echo LANGUI_HLP_T13;?>

          </h1><ul><li><a href="?c=4&id=1">
          <?php  echo item_1;?>

          </a></li><li><a href="?c=4&id=2">
          <?php  echo item_2;?>

          </a></li><li><a href="?c=4&id=3">
          <?php  echo item_3;?>

          </a></li><li><a href="?c=4&id=4">
          <?php  echo item_4;?>

          </a></li><li><a href="?c=4&id=5">
          <?php  echo item_5;?>

          </a></li><li><a href="?c=4&id=6">
          <?php  echo item_6;?>

          </a></li><li><a href="?c=4&id=7">
          <?php  echo item_7;?>

          </a></li><li><a href="?c=4&id=8">
          <?php  echo item_8;?>

          </a></li><li><a href="?c=4&id=9">
          <?php  echo item_9;?>

          </a></li><li><a href="?c=4&id=10">
          <?php  echo item_10;?>

          </a></li><li><a href="?c=4&id=11">
          <?php  echo item_11;?>

          </a></li></ul>

        <?php }elseif( ($buildingGroup == '2') ){ ?>

          <h1><img class="unit ugeb" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="" title="">
          <?php  echo LANGUI_HLP_T14;?>

          </h1><ul><li><a href="?c=4&id=12">
          <?php  echo item_12;?>

          </a></li><li><a href="?c=4&id=13">
          <?php  echo item_13;?>

          </a></li><li><a href="?c=4&id=14">
          <?php  echo item_14;?>

          </a></li><li><a href="?c=4&id=16">
          <?php  echo item_16;?>

          </a></li><li><a href="?c=4&id=19">
          <?php  echo item_19;?>

          </a></li><li><a href="?c=4&id=20">
          <?php  echo item_20;?>

          </a></li><li><a href="?c=4&id=21">
          <?php  echo item_21;?>

          </a></li><li><a href="?c=4&id=22">
          <?php  echo item_22;?>

          </a></li><li><a href="?c=4&id=29">
          <?php  echo item_29;?>

          </a></li><li><a href="?c=4&id=30">
          <?php  echo item_30;?>

          </a></li><li><a href="?c=4&id=36">
          <?php  echo item_36;?>

          </a></li><li><a href="?c=4&id=37">
          <?php  echo item_37;?>

          </a></li><li><a href="?c=4&id=42">
          <?php  echo item_42;?>

          </a></li></ul>
          <?php }elseif( ($buildingGroup == 3) ){ ?>

          <h1><img class="unit ugeb" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="" title="">
          <?php  echo LANGUI_HLP_T15;?>

          </h1><ul><li><a href="?c=4&id=15">
          <?php  echo item_15;?>

          </a></li><li><a href="?c=4&id=17">
          <?php  echo item_17;?>

          </a></li><li><a href="?c=4&id=18">
          <?php  echo item_18;?>

          </a></li><li><a href="?c=4&id=23">
          <?php  echo item_23;?>

          </a></li><li><a href="?c=4&id=24">
          <?php  echo item_24;?>

          </a></li><li><a href="?c=4&id=25">
          <?php  echo item_25;?>

          </a></li><li><a href="?c=4&id=26">
          <?php  echo item_26;?>

          </a></li><li><a href="?c=4&id=28">
          <?php  echo item_28;?>

          </a></li><li><a href="?c=4&id=34">
          <?php  echo item_34;?>

          </a></li><li><a href="?c=4&id=35">
          <?php  echo item_35;?>

          </a></li><li><a href="?c=4&id=38">
          <?php  echo item_38;?>

          </a></li><li><a href="?c=4&id=39">
          <?php  echo item_39;?>

          </a></li><li><a href="?c=4&id=41">
          <?php  echo item_41;?>

          </a></li><li><a href="?c=4&id=40">
          <?php  echo item_40;?>

          </a></li></ul>
      <?php } ?>

      <?php }elseif( ($state == 3) ){ ?>

      <h1><img class="unit u <?php echo $troopId;?>" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php echo merge_manual_text('troop', $troopId); ?>" title="<?php echo merge_manual_text('troop', $troopId); ?>">
      <?php echo merge_manual_text('troop', $troopId); ?>

      <span class="tribe">(<?php if( ($troop['for_tribe_id'] > 0) ){ ?> <?php echo merge_manual_text('tribe', $troop['for_tribe_id']); ?> <?php } ?>)</span></h1>
      <table id="troop_info" cellpadding="1" cellspacing="1">
        <thead>
          <tr>
            <th><img class="att_all" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo LANGUI_HLP_T16;?>" title="<?php  echo LANGUI_HLP_T16;?>"></th>
            <th><img class="def_i" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo LANGUI_HLP_T17;?>" title="<?php  echo LANGUI_HLP_T17;?>"></th><th><img class="def_c" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo LANGUI_HLP_T18;?>" title="<?php  echo LANGUI_HLP_T18;?>"></th>
            <th><img class="r1" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo item_title_1;?>" title="<?php  echo item_title_1;?>"></th>
            <th><img class="r2" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo item_title_2;?>" title="<?php  echo item_title_2;?>"></th>
            <th><img class="r3" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo item_title_3;?>" title="<?php  echo item_title_3;?>"></th>
            <th><img class="r4" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo item_title_4;?>" title="<?php  echo item_title_4;?>"></th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td><?php echo $troop["attack_value"];?></td>
            <td><?php echo $troop["defense_infantry"];?></td>
            <td><?php echo $troop["defense_cavalry"];?></td>
            <td><?php echo $troop["training_resources"]["1"];?></td>
            <td><?php echo $troop["training_resources"]["2"];?></td>
            <td><?php echo $troop["training_resources"]["3"];?></td>
            <td><?php echo $troop["training_resources"]["4"];?></td>
          </tr>
        </tbody>
      </table>
      <table id="troop_details" cellpadding="1" cellspacing="1">
        <tbody>
          <tr>
            <th><?php  echo LANGUI_HLP_T19;?>:</th>
            <td><b><?php echo $troop["velocity"] * $gameMetadata['game_speed'];?></b> <?php  echo LANGUI_HLP_T20;?></td>
          </tr>
          <tr>
            <th><?php  echo LANGUI_HLP_T21;?>:</th>
            <td><b><?php echo $troop["carry_load"];?></b> <?php  echo LANGUI_HLP_T6;?></td>
          </tr>
          <tr>
            <th><?php  echo LANGUI_HLP_T22;?>:</th>
            <td>
              <img class="r5" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo LANGUI_HLP_T23;?>" title="<?php  echo LANGUI_HLP_T23;?>">
            <?php echo $troop["crop_consumption"];?>

          </td>
        </tr>
        <tr>
          <th><?php  echo LANGUI_HLP_T24;?>:</th>
          <td><img class="clock" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo text_period_lang;?>" title="<?php  echo text_period_lang;?>">
              <?php echo secondstostring($troop['training_time_consume'] / $gameSpeed); ?>

          </td>
        </tr>
      </tbody>
    </table>
    <img id="big_unit" class="big_u<?php echo $troopId;?>" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php echo merge_manual_text('troop', $troopId); ?>" title="<?php echo merge_manual_text('troop', $troopId); ?>" />
    <div id="t_desc">
      <p><br>
      <?php if( $troop['for_tribe_id'] != 4 AND $troop['for_tribe_id'] != 5 ){ ?>

        <?php echo merge_manual_text('troop_desc', $troopId); ?>

      <?php } ?>

      <br />
    </p>
  </div>
  <div id="prereqs">
    <b><?php  echo LANGUI_HLP_T25;?>:</b>
    <br />
      <?php if( isset($troop['help_pre_requests']) ){ ?>

        <?php $t_pre_request = $troop['help_pre_requests'];?>

      <?php }else{ ?>

        <?php $t_pre_request = $troop['pre_requests'];?>

      <?php } ?>

      <?php $flag = FALSE;?>

      <?php $counter1=-1; if( isset($t_pre_request) && is_array($t_pre_request) && sizeof($t_pre_request) ) foreach( $t_pre_request as $key1 => $value1 ){ $counter1++; ?>

          <?php $reqIds = explode("|", $key1);?>

          <?php $strFlag = FALSE;?>

          <?php if( $flag ){ ?>,<?php } ?>

          <?php $counter2=-1; if( isset($reqIds) && is_array($reqIds) && sizeof($reqIds) ) foreach( $reqIds as $key2 => $value2 ){ $counter2++; ?>

              <?php if( !$strFlag ){ ?><?php $strFlag = TRUE;?><?php }else{ ?>  <?php  echo text_or_lang;?><?php } ?>

              <a href="?c=4&id=<?php echo $key2;?>">
              <?php if( ($value1 == NULL) ){ ?><strike><?php } ?>

                  <?php echo merge_manual_text('item', $value2); ?>

              <?php if( ($value1 == NULL) ){ ?></strike><?php } ?>

              </a>
              <?php if( ($value1 != NULL) ){ ?>

                  <?php  echo level_lang;?>

                  <?php echo $value1;?>

              <?php } ?>

          <?php } ?>

          <?php $flag = TRUE;?>

      <?php } ?>

      <?php if( !$flag ){ ?><?php  echo LANGUI_HLP_T26;?><?php } ?>

    </div>
  <?php }elseif( ($state == 4) ){ ?>

      <h1><img class="unit ugeb" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>">
        <?php echo merge_manual_text('item', $itemId); ?>

      </h1><img class="building g<?php echo $itemId;?>" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php echo merge_manual_text('item', $itemId); ?>" title="<?php echo merge_manual_text('item', $itemId); ?>">
      <?php echo merge_manual_text('item_desc', $itemId); ?>

      <p><b>
      <?php  echo LANGUI_HLP_T27;?>:<br><img class="r1" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo item_title_1;?>" title="<?php  echo item_title_1;?>">
      <?php echo $build["levels"]["0"]["resources"]["1"];?>|
      <img class="r2" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo item_title_2;?>" title="<?php  echo item_title_2;?>">
      <?php echo $build["levels"]["0"]["resources"]["2"];?>|
      <img class="r3" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo item_title_3;?>" title="<?php  echo item_title_3;?>">
      <?php echo $build["levels"]["0"]["resources"]["3"];?> |
      <img class="r4" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo item_title_4;?>" title="<?php  echo item_title_4;?>">
      <?php echo $build["levels"]["0"]["resources"]["4"];?>|
      <img class="r5" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo LANGUI_HLP_T23;?>" title="<?php  echo LANGUI_HLP_T23;?>">
      <?php echo $build["levels"]["0"]["people_inc"];?>

      <span class="dur">
        <img class="clock" alt="<?php  echo text_period_lang;?>" title="<?php  echo text_period_lang;?>" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>">
        <?php echo secondstostring($build['levels'][0]['time_consume'] / $gameSpeed); ?>

      </span></p><p><b>
      <?php  echo LANGUI_HLP_T25;?>:
    </b><br>
    <?php $flag = FALSE;?>

    <?php $counter1=-1; if( isset($build["pre_requests"]) && is_array($build["pre_requests"]) && sizeof($build["pre_requests"]) ) foreach( $build["pre_requests"] as $key1 => $value1 ){ $counter1++; ?>

      <?php if( $flag ){ ?>,<?php } ?>

      <a href="?c=4&id=<?php echo $key1;?>">
        <?php if( $value1 == NULL ){ ?><strike><?php } ?>

        <?php echo merge_manual_text('item', $key1); ?>

        <?php if( $value1 == NULL ){ ?></strike><?php } ?>

      </a>
      <?php if( $value1 != NULL ){ ?>

        <?php  echo level_lang;?><?php echo $value1;?>

      <?php } ?>

      <?php $flag = TRUE;?>

    <?php } ?>

    <?php if( !$flag ){ ?><?php  echo LANGUI_HLP_T26;?><?php } ?>

    </p>
      <?php }elseif( ($state == 5) ){ ?>

      <?php if( ($plusIndex == 0) ){ ?>

          <h1>
            <img class="point" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="" title="" />
            <?php  echo LANGUI_HLP_T28;?>

          </h1>
          <?php  echo LANGUI_HLP_T29;?>:
          <br />
          <br />
          <ul>
            <li><?php  echo LANGUI_HLP_T31;?></li>
            <li><?php  echo LANGUI_HLP_T82;?></li>
            <li><?php  echo LANGUI_HLP_T33;?></li>
            <li><?php  echo LANGUI_HLP_T30;?></li>
            <li><?php  echo LANGUI_HLP_T83;?></li>
            <li><?php  echo LANGUI_HLP_T32;?></li>
            <li><?php  echo LANGUI_HLP_T81;?></li>
            <li><?php  echo LANGUI_HLP_T84;?></li>
          </ul>
      <?php }elseif( ($plusIndex == 1) ){ ?>

          <h1><img class="point" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="" title="">
          <?php  echo LANGUI_HLP_T34;?>

          </h1>
          <?php  echo LANGUI_HLP_T35;?>

          .
      <?php }elseif( ($plusIndex == 2) ){ ?>

          <h1><img class="point" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="" title="">
          <?php  echo LANGUI_HLP_T36;?>

          </h1>
          <?php  echo LANGUI_HLP_T37;?>

          .
      <?php }elseif( ($plusIndex == 3) ){ ?>

          <h1>
            <img class="point" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="" title="">
          <?php  echo LANGUI_HLP_T38;?>

          </h1>
          <?php  echo LANGUI_HLP_T39;?>

          .
      <?php }elseif( ($plusIndex == 4) ){ ?>

          <h1>
            <img class="point" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="" title="">
          <?php  echo LANGUI_HLP_T40;?>

          </h1>
          <?php  echo LANGUI_HLP_T41;?>

          .
      <?php }elseif( ($plusIndex == 5) ){ ?>

          <h1><img class="point" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="" title="">
          <?php  echo LANGUI_HLP_T42;?>

          </h1>
          <?php  echo LANGUI_HLP_T43;?>

          .
      <?php }elseif( ($plusIndex == 7) ){ ?>

          <h1><img class="point" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="" title="">
          <?php  echo LANGUI_HLP_T44;?>

          </h1>
          <?php  echo LANGUI_HLP_T45;?>

          .
      <?php }elseif( ($plusIndex == 8) ){ ?>

          <h1><img class="point" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="" title="">
          <?php  echo LANGUI_HLP_T75;?>

          </h1>
          <?php  echo LANGUI_HLP_T76;?>

          .
      <?php }elseif( ($plusIndex == 9) ){ ?>

          <h1><img class="point" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="" title="">
          <?php  echo LANGUI_HLP_T77;?>

          </h1>
          <?php  echo LANGUI_HLP_T78;?>

          .
      <?php }elseif( ($plusIndex == 10) ){ ?>

          <h1><img class="point" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="" title="">
          <?php  echo LANGUI_HLP_T79;?>

          </h1>
          <?php  echo LANGUI_HLP_T80;?>

          .
      <?php }elseif( ($plusIndex == 6) ){ ?>

          <h1>
            <img class="point" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="" title=""><?php  echo LANGUI_HLP_T46;?></h1>
          <p>
            <?php  echo LANGUI_HLP_T47;?>.
          </p>
          <table id="examples" cellpadding="1" cellspacing="1">
            <thead>
              <tr>
                <th colspan="2"><?php  echo LANGUI_HLP_T48;?></th>
              </tr>
              <tr>
                <td><?php  echo LANGUI_HLP_T49;?></td>
                <td><?php  echo LANGUI_HLP_T50;?></td>
              </tr>
            </thead>
            <tbody>
              <tr>
                <th><?php  echo item_19;?></th>
                <td>build?bid=19</td>
              </tr>
              <tr>
                <th><?php  echo item_17;?></th>
                <td>build?bid=17</td>
              </tr>
              <tr>
                <th><?php  echo item_16;?></th>
                <td>build?bid=16</td>
              </tr>
              <tr>
                <th><?php  echo LANGUI_HLP_T51;?></th>
                <td>notes*</td>
              </tr>
            </tbody>
          </table>
          <p>
            <?php  echo LANGUI_HLP_T52;?>.
          </p>
      <?php } ?>

    <?php }elseif( ($state == 6) ){ ?>

      <?php if( ($id == 0) ){ ?>

          <h1>
            <img class="point" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="" title=""><?php  echo LANGUI_HLP_T53;?></h1>
          <p></p>
          <p><?php  echo LANGUI_HLP_T54;?></p>
          <p></p>
          <table id="examples" cellpadding="1" cellspacing="1">
            <thead>
              <tr>
                <th colspan="2"><?php  echo LANGUI_HLP_T55;?></th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <th><?php  echo LANGUI_HLP_T56;?></th>
                <td><?php  echo LANGUI_HLP_T57;?></td>
              </tr>
              <tr>
                <th><?php  echo LANGUI_HLP_T58;?></th>
                <td><?php  echo LANGUI_HLP_T59;?></td>
              </tr>
              <tr>
                <th><?php  echo LANGUI_HLP_T60;?></th>
                <td><?php  echo LANGUI_HLP_T61;?></td>
              </tr>
              <tr>
                <th><?php  echo LANGUI_HLP_T62;?></th>
                <td><?php  echo LANGUI_HLP_T63;?></td>
              </tr>
            </tbody>
          </table>
          <p></p>
          <p>
            <?php  echo LANGUI_HLP_T64;?>:-
          </p>
          <p></p>
          <p class="medals">
            <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="medal t1_1" alt="" title="">
            <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="medal t1_2" alt="" title="">
            <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="medal t1_3" alt="" title="">
            <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="medal t1_4" alt="" title="">
          </p>
      <?php }elseif( ($id == 1) ){ ?>

          <h1><img class="point" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="" title="">
          <?php  echo LANGUI_HLP_T65;?>

          </h1><p>
          <?php  echo LANGUI_HLP_T66;?>

          </p><p></p>
          <table id="examples" cellpadding="1" cellspacing="1">
            <thead>
              <tr>
                <th colspan="2"><?php  echo LANGUI_HLP_T67;?></th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <th><?php  echo LANGUI_HLP_T56;?></th>
                <td><?php  echo LANGUI_HLP_T68;?></td>
              </tr>
              <tr>
                <th><?php  echo LANGUI_HLP_T58;?></th>
                <td><?php  echo LANGUI_HLP_T69;?></td>
          </tr>
          <tr>
              <th><?php  echo LANGUI_HLP_T60;?></th>
              <td><?php  echo LANGUI_HLP_T61;?></td>
          </tr>
          <tr>
              <th><?php  echo LANGUI_HLP_T62;?></th>
              <td><?php  echo LANGUI_HLP_T63;?></td>
          </tr>
          </tbody>
          </table>
          <p>
          <?php  echo LANGUI_HLP_T70;?>

          </p>
          <p class="medals">
            <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="medal a1_1" alt="" title="">
            <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="medal a1_2" alt="" title="">
            <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="medal a1_3" alt="" title="">
            <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="medal a1_4" alt="" title="">
          </p>
      <?php } ?>

  <?php }elseif( ($state == 7) ){ ?>

      <h1><img class="point" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="" title=""><?php  echo LANGUI_HLP_T73;?></h1>
      <?php  echo LANGUI_HLP_T74;?>

  <?php } ?>


  <?php if( (0 < $state) ){ ?>

      <map id="nav" name="nav"><area href="<?php echo $previousLink;?>" title="<?php  echo LANGUI_HLP_T71;?>" coords="0,0,45,18" shape="rect" alt="">
        <area href="help" title="<?php  echo LANGUI_HLP_T1;?>" coords="46,0,70,18" shape="rect" alt="">
        <area href="<?php echo $nextLink;?>" title="<?php  echo LANGUI_HLP_T72;?>" coords="71,0,116,18" shape="rect" alt=""></map>
        <img usemap="#nav" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="navi" alt="">
  <?php } ?>

</body>
</html>