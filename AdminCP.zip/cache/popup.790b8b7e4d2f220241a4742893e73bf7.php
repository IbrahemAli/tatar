<?php if(!class_exists('raintpl')){exit;}?><!DOCTYPE html>

<html lang="ar">

<head>

    <meta charset="UTF-8">

    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

</head>

<body>
  <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
  <html>
  <head>
    <title><?php echo $title;?></title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta http-equiv="imagetoolbar" content="no" />
    <meta http-equiv="cache-control" content="max-age=0" />
    <meta http-equiv="pragma" content="no-cache" />
    <meta http-equiv="expires" content="0" />
    <link href="<?php echo add_style('lang.css', ASSETS_DIR.'/default/lang/'.$lang.'/'); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo add_style('compact.css', ASSETS_DIR.'/default/lang/'.$lang.'/'); ?>" rel="stylesheet" type="text/css" />
    <script type="text/javascript">
      var d3l= <?php if( $lang == 'ar'  ){ ?>180<?php }else{ ?>-600<?php } ?>;
    </script>
    <script src="<?php echo add_style('core.js', ASSETS_DIR); ?>" type="text/javascript"></script>
    </head>
  <body class="manual">
    <?php echo $content;?>

  </body>
  <script type="text/javascript">init();</script></html>
</body>
</html>