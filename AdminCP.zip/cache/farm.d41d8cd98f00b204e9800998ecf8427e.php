<?php if(!class_exists('raintpl')){exit;}?>﻿<!DOCTYPE html>

<html lang="ar">

<head>

    <meta charset="UTF-8">

    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

</head>

<body>
<?php echo load_lang('ui/farm'); ?>

<h1><?php  echo LANGUI_FARM_T1;?></h1>
    <div id="textmenu">
        <a href="farm"<?php if( $selectedTabIndex == 0 ){ ?> class="selected" <?php } ?>><?php  echo LANGUI_FARM_T1;?></a> |
        <a href="farm?t=1"<?php if( $selectedTabIndex == 1 ){ ?> class="selected" <?php } ?>><?php  echo LANGUI_FARM_T6;?></a>
    </div>
<?php if( $selectedTabIndex == 0 ){ ?>

<script src="<?php echo add_style('jquery.js', ASSETS_DIR); ?>" type="text/javascript"></script>
<script>var texting = "<?php  echo LANGUI_FARM_T8;?>";</script>
<script type="text/javascript" src="<?php echo add_style('farm.js', ASSETS_DIR); ?>"></script>
<div id="farming"></div>
<form name='farm'>
    <table id="plusFunctions" cellpadding="1" cellspacing="1">
        <thead>
            <tr>
                <th colspan="5"><?php  echo LANGUI_FARM_T1;?></th>
            </tr>
            <tr>
                <td><input type='checkbox' onclick='CheckAll(this.checked)'></td>
                <td><?php  echo LANGUI_FARM_T16;?></td>
                <td><?php  echo LANGUI_FARM_T17;?></td>
                <td><?php  echo LANGUI_FARM_T2;?></td>
                <td><?php  echo LANGUI_FARM_T3;?></td>
            </tr>
        </thead>
        <tbody>
        <?php if( $found ){ ?>

        <?php $_c = 0;?>

        <?php $counter1=-1; if( isset($listData) && is_array($listData) && sizeof($listData) ) foreach( $listData as $key1 => $value1 ){ $counter1++; ?>

        <?php $_c = $_c + 1;?>

            <tr>
                <td id="a<?php echo $_c;?>">
                    <center>
                        <input class='check' type='checkbox' name='list[]' id='list' value='<?php echo $value1["vid"];?>|<?php echo $value1["troop"];?>'>
                    </center>
                </td>
                <td id="b<?php echo $_c;?>">
                    <center>
                        <a href="village3?id=<?php echo $value1["vid"];?>"><?php echo $value1["name"];?></a>
                    </center>
                </td>
                <td id="c<?php echo $_c;?>">
                    <center><?php echo $value1["time"];?></center>
                </td>
                <td id="d<?php echo $_c;?>">
                    <center>
                    <?php $counter2=-1; if( isset($value1["troops"]) && is_array($value1["troops"]) && sizeof($value1["troops"]) ) foreach( $value1["troops"] as $key2 => $value2 ){ $counter2++; ?>

                        <img class="unit u<?php echo $key2;?>" src='assets/x.gif' alt="<?php echo constant('troop_'.$key2); ?>" title="<?php echo constant('troop_'.$key2); ?>"><?php echo $value2;?>

                    <?php } ?>

                    </center>
                </td>
                <td id="e<?php echo $_c;?>">
                    <center>
                        <a href='farm?del=<?php echo $key1;?>'><img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="del" title="<?php  echo text_delete_lang;?>" alt="<?php  echo text_delete_lang;?>"></a>
                    </center>
                </td>
            </tr>
        <?php } ?>

        <?php }else{ ?>

            <tr>
                <td colspan='5'>
                    <center><?php  echo LANGUI_FARM_T4;?></center>
                </td>
            </tr>
        <?php } ?>

        </tbody>
    </table>
    <br>
    <input class="text" name="attack" type="button" value="<?php  echo LANGUI_FARM_T5;?>" onClick="javascript:farming();scrollTo(0,0);">
</form>
<?php }elseif( $selectedTabIndex == 1 ){ ?>

<form action="farm?t=1" method="post">
    <table id="plusFunctions" cellpadding="1" cellspacing="1">
        <thead>
            <tr>
                <th colspan="3">
                    <center><?php  echo LANGUI_FARM_T6;?></center>
                </th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>
                    <center><?php  echo LANGUI_FARM_T15;?></center>
                </td>
                <td>
                    <center>
                        X: <input class="text" type="text" name="x" value="<?php if( is_post('x') ){ ?><?php echo post('x'); ?><?php }elseif( is_get('x') ){ ?><?php echo get('x'); ?><?php } ?>" size="8">
                    </center>
                </td>
                <td>
                    <center>
                        Y: <input class="text" type="text" name="y" value="<?php if( is_post('y') ){ ?><?php echo post('y'); ?><?php }elseif( is_get('y') ){ ?><?php echo get('y'); ?><?php } ?>" size="8">
                    </center>
                </td>
            </tr>
            <tr>
                <td>
                    <center><?php  echo LANGUI_FARM_T2;?></center>
                </td>
                <td colspan="2">
                <?php $counter1=-1; if( isset($troops) && is_array($troops) && sizeof($troops) ) foreach( $troops as $key1 => $value1 ){ $counter1++; ?>

                    <img class="unit u<?php echo $value1;?>" src='assets/x.gif' alt="<?php echo constant('troop_'.$value1); ?>" title="<?php echo constant('troop_'.$value1); ?>">
                    <input class="text" size="6" name="t[<?php echo $value1;?>]" type="text" value="">
                <?php } ?>

                </td>
            </tr>
        </tbody>
    </table>
    <?php if( isset($error) ){ ?>

    <p class="error"><?php echo $error;?></p>
    <?php } ?>

    <p>
        <input type="image" value="ok" name="s1" id="btn_ok" class="dynamic_img" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo text_okdone_lang;?>">
    </p>
</form>
<?php } ?>

</body>
</html>