<?php if(!class_exists('raintpl')){exit;}?><!DOCTYPE html>

<html lang="ar">

<head>

    <meta charset="UTF-8">

    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

</head>

<body>
<?php echo load_lang('ui/build'); ?>

<?php if( (!$buildProperties['emptyPlace']) ){ ?>

<div id="build" class="gid<?php echo $buildProperties["building"]["item_id"];?>">
  <a href="" onclick="return showManual(4, <?php echo $buildProperties["building"]["item_id"];?>);" class="build_logo">
    <img class="building g<?php echo $buildProperties["building"]["item_id"];?>" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php echo constant('item_' . $buildProperties['building']['item_id']); ?>" title="<?php echo constant('item_' . $buildProperties['building']['item_id']); ?>">
  </a>
  <h1>
    <?php echo constant('item_' . $buildProperties['building']['item_id']); ?>

    <span class="level">
      <?php  echo level_lang;?> 
      <?php echo $buildProperties["building"]["level"];?>

    </span>
  </h1>
  <p class="build_desc"></p>
  <p>
    <?php echo constant('item_desc_' . $buildProperties['building']['item_id']); ?>

  </p>
  <p></p>
    <?php if( (4 < $buildProperties['building']['item_id'] && 0 < $buildProperties['building']['update_state'] && $buildProperties['building']['level'] == 0) ){ ?>

      <p></p>
      <br />
      <p></p>
      <p class="none">
        <?php  echo LANGUI_BUILD_T1;?> .
      </p>
      <p></p>
      <br/>
      <p></p>
      <?php }else{ ?>

      <?php if( ($productionPane) ){ ?>

      <table cellpadding="1" cellspacing="1" id="build_value">
        <tbody>
          <tr>
            <th>
              <?php echo constant('item_curprod_' . $buildProperties['building']['item_id']); ?> :
            </th>
            <td>
              <b><?php echo $buildProperties["level"]["current_value"];?></b>
              <?php echo constant('item_unit_' . $buildProperties['building']['item_id']); ?>

            </td>
          </tr>
          <?php if( ($buildProperties['building']['level'] < $buildProperties['maxLevel']) ){ ?>

            <tr>
              <th>
                <?php echo constant('item_nextprod_' . $buildProperties['building']['item_id']); ?>

                <?php echo $buildProperties["nextLevel"];?> :
              </th>
              <td>
                <b><?php echo $buildProperties["level"]["value"];?></b>
                <?php echo constant('item_unit_' . $buildProperties['building']['item_id']); ?>

              </td>
            </tr>
            <?php } ?>

          </tbody>
      </table>
        <?php } ?>

          <?php if( ($buildingView != '') ){ ?>

            <?php echo $buildingTemplateContent;?>

          <?php } ?>

      <?php } ?>

      
      <?php if( ($buildProperties['maxLevel'] <= $buildProperties['building']['level']) ){ ?>

          <p class="none">
            <?php  echo LANGUI_BUILD_T2;?>

              <?php echo constant('item_' . $buildProperties['building']['item_id']); ?>

            <?php  echo LANGUI_BUILD_T3;?>

          </p>

      <?php }elseif( ($buildProperties['maxLevel'] <= $buildProperties['upgradeToLevel'] && 0 < $buildProperties['building']['update_state']) ){ ?>

              <p class="none">
                <?php  echo LANGUI_BUILD_T4;?>

                  <?php echo constant('item_' . $buildProperties['building']['item_id']); ?>

                <?php  echo LANGUI_BUILD_T3;?>

              </p>
              <?php }else{ ?>

              <p id="contract">
                <b><?php  echo LANGUI_BUILD_T5;?></b>
                <?php  echo LANGUI_BUILD_T6;?>

                <?php echo $buildProperties["nextLevel"];?>:
                <br />
                <img class="r1" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo item_title_1;?>" title="<?php  echo item_title_1;?>">
                <?php echo $buildProperties["level"]["resources"]["1"];?> |
                <img class="r2" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo item_title_2;?>" title="<?php  echo item_title_2;?>">
                <?php echo $buildProperties["level"]["resources"]["2"];?> |
                <img class="r3" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo item_title_3;?>" title="<?php  echo item_title_3;?>">
                <?php echo $buildProperties["level"]["resources"]["3"];?> |
                <img class="r4" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo item_title_4;?>" title="<?php  echo item_title_4;?>">
                <?php echo $buildProperties["level"]["resources"]["4"];?> |
                <img class="r5" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo LANGUI_BUILD_T7;?>" title="<?php  echo LANGUI_BUILD_T7;?>">
                <?php echo $buildProperties["level"]["people_inc"];?> |
                <img class="clock" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo text_period_lang;?>" title="<?php  echo text_period_lang;?>">
                <?php echo secondstostring( $buildProperties["level"]["calc_consume"] );?>

          
                <?php echo $resource_gold_exchange;?>

                <br />
                <?php echo $get_action_text;?> | <?php if( $buildProperties['building']['item_id'] != 40 ){ ?><a class="build" href="village<?php if( $buildProperties['building']['item_id']>4 ){ ?>2<?php }else{ ?>1<?php } ?>?id=<?php echo $buildProperties['building']['index'];?>&k=<?php echo $data['update_key'];?>&max=1"><?php  echo LANGUI_BUILD_T6;?> <?php echo $buildProperties['maxLevel'];?></a> 
				<img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="gold" alt="<?php  echo text_gold_lang;?>" title="<?php  echo text_gold_lang;?>"><?php echo $buildProperties['maxLevel'] - $buildProperties['upgradeToLevel'];?><?php } ?>

                </p>
                <?php } ?>

              </div>
              <?php }else{ ?>

              <script language="JavaScript" type="text/javascript">
                function showPane(list)
                {
                  var build_list = _('build_list_'+list);
                  var link = _(list+'_link');
                  if (build_list.className == 'hide')
                  {
                      build_list.className = '';
                      link.innerHTML = '<?php  echo LANGUI_BUILD_T8;?>';
                  }
                  else
                  {
                      build_list.className = 'hide';
                      link.innerHTML = '<?php  echo LANGUI_BUILD_T9;?>';
                    }
                  }
              </script>
              <div id="build" class="gid0">
                <h1><?php  echo LANGUI_BUILD_T10;?></h1>

                <?php $counter1=-1; if( isset($availableBuildings) && is_array($availableBuildings) && sizeof($availableBuildings) ) foreach( $availableBuildings as $key1 => $value1 ){ $counter1++; ?>

                  <h2><?php echo constant('item_' . $value1['item_id']); ?></h2>
                  <table class="new_building" cellpadding="1" cellspacing="1">
                    <tbody>
                      <tr>
                        <td class="desc">
                          <p><?php echo constant('item_desc_' . $value1['item_id']); ?></p>
                        </td>
                        <td rowspan="3" class="bimg">
                          <a href="#" onclick="return showManual(4, <?php echo $value1["item_id"];?>);">
                            <img class="building g<?php echo $value1["item_id"];?>" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php echo constant('item_' . $value1['item_id']); ?>" title="<?php echo constant('item_' . $value1['item_id']); ?>">
                          </a>
                        </td>
                      </tr>
                      <tr>
                        <td class="res">
                          <img class="r1" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo item_title_1;?>" title="<?php  echo item_title_1;?>">
                          <?php echo $value1["neededResources"]["1"];?> |
                          <img class="r2" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo item_title_2;?>" title="<?php  echo item_title_2;?>">
                          <?php echo $value1["neededResources"]["2"];?> |
                          <img class="r3" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo item_title_3;?>" title="<?php  echo item_title_3;?>">
                          <?php echo $value1["neededResources"]["3"];?> |
                          <img class="r4" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo item_title_4;?> " title="<?php  echo item_title_4;?>">
                          <?php echo $value1["neededResources"]["4"];?> |
                          <img class="r5" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo LANGUI_BUILD_T7;?>" title="<?php  echo LANGUI_BUILD_T7;?>">
                          <?php echo $value1["build"]["levels"]["0"]["people_inc"];?> |
                          <img class="clock" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo text_period_lang;?>" title="<?php  echo text_period_lang;?>">
                          <?php echo $value1["time"];?>

                          <?php echo $value1["getResourceGoldExchange"];?>

                        </td>
                      </tr>
                      <tr>
                        <td class="link">
                          <?php echo $value1["getActionText"];?>

                        </td>
                      </tr>
                    </tbody>
                  </table>
                <?php } ?>

      
              <?php if( ($_GET['id'] != 39 && $_GET['id'] != 40 && !($data['is_special_village'] && ($_GET['id'] == 25 || $_GET['id'] == 26 || $_GET['id'] == 29 || $_GET['id'] == 30 || $_GET['id'] == 33))) ){ ?>

                <p class="switch">
                  <a id="soon_link" href="javascript:showPane('soon');"><?php  echo LANGUI_BUILD_T9;?></a>
                </p>
              <div id="build_list_soon" class="hide">
                <?php $counter1=-1; if( isset($soonBuildings) && is_array($soonBuildings) && sizeof($soonBuildings) ) foreach( $soonBuildings as $key1 => $value1 ){ $counter1++; ?>

                    <?php $counter2=-1; if( isset($value1) && is_array($value1) && sizeof($value1) ) foreach( $value1 as $key2 => $value2 ){ $counter2++; ?>

                      <h2><?php echo constant('item_' . $key2); ?></h2> 
                      <table class="new_building" cellpadding="1" cellspacing="1">
                        <tbody>
                          <tr>
                            <td class="desc">
                              <p><?php echo constant('item_desc_' . $key2); ?></p>
                            </td>
                            <td rowspan="3" class="bimg">
                              <a href="#" onclick="return showManual(4, <?php echo $key2;?>);">
                                <img class="building g<?php echo $key2;?>" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php echo constant('item_' . $key2); ?>" title="<?php echo constant('item_' . $key2); ?>">
                              </a>
                            </td>
                          </tr>
                          <tr>
                            <td class="requ">
                              <?php  echo LANGUI_BUILD_T11;?> :
                            </td>
                          </tr>
                          <tr>
                            <td>
                                <?php $flag = FALSE;?>

                                <?php $counter3=-1; if( isset($value2['pre_requests']) && is_array($value2['pre_requests']) && sizeof($value2['pre_requests']) ) foreach( $value2['pre_requests'] as $key3 => $value3 ){ $counter3++; ?>                                    
                                    <?php if( ($flag) ){ ?> , <?php } ?>

                                  <a href="#" onclick="return showManual(4,<?php echo $key3;?>);">
                                    <?php if( ($value3 == NULL) ){ ?> <strike> <?php } ?>

                                      <?php echo constant('item_' . $key3); ?>

                                    <?php if( ($value3 == NULL) ){ ?></strike><?php } ?>

                                  </a>
                                  <?php if( ($value3 != NULL) ){ ?>

                                    <span title="<?php if( $value2['pre_requests_dependencyCount'][$key3] < 0 ){ ?>><?php }else{ ?>+<?php } ?><?php echo $value2["pre_requests_dependencyCount"]["$key3"];?>"> 
                                    <?php  echo level_lang;?>

                                    <?php echo $value3;?>

                                    </span>
                                  <?php } ?>

                                  <?php $flag = TRUE;?>

                                <?php } ?>

                          </td>
                          </tr>
                        </tbody>
                      </table>
                  <?php } ?>

                <?php } ?>

              </div>
              <?php } ?>

            </div>
            <?php } ?>

			</body>
</html>