<?php if(!class_exists('raintpl')){exit;}?><!DOCTYPE html>

<html lang="ar">

<head>

    <meta charset="UTF-8">

    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

</head>

<body>
<?php echo load_lang('ui/support'); ?>

<h1><?php  echo LANGUI_SUPP_5;?></h1>
    <div id="textmenu">
        <a href="support"<?php if( $selectedTabIndex == 0 ){ ?> class="selected" <?php } ?>><?php  echo LANGUI_SUPP_1;?></a> |
        <a href="support?t=1"<?php if( $selectedTabIndex == 1 ){ ?> class="selected" <?php } ?>><?php  echo LANGUI_SUPP_2;?></a> |
        <a href="support?t=2"<?php if( $selectedTabIndex == 2 ){ ?> class="selected" <?php } ?>><?php  echo LANGUI_SUPP_3;?></a>
    </div>
<?php if( $selectedTabIndex == 2 ){ ?>

<form action='support?t=2' method='post'>
    <table class="rate_details lang_rtl lang_ar" cellpadding="1" cellspacing="1">
        <thead>
            <tr>
                <th colspan="2"><?php  echo LANGUI_SUPP_4;?></th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td><?php  echo LANGUI_SUPP_6;?></td>
                <td>
                    <select name='type'>
                        <option value="2"><?php  echo LANGUI_SUPP_7;?></option>
                        <option value="1"><?php  echo LANGUI_SUPP_8;?></option>
                        <option value="3"><?php  echo LANGUI_SUPP_9;?></option>
                        <option value="4"><?php  echo LANGUI_SUPP_10;?></option>
                    </select>
                </td>
            </tr>
            <tr>
                <td><?php  echo LANGUI_SUPP_11;?></td>
                <td><input type="text" maxlength='60' size="35" name="title" class="text"/></td>
            </tr>
            <tr>
                <td><?php  echo LANGUI_SUPP_12;?></td>
                <td><textarea name='content' cols="52" rows="12"><?php if( is_post('content') ){ ?><?php echo post('content'); ?><?php } ?></textarea></td>
            </tr>
            <p>
        </tbody>
    </table>
    <center>
        <input type="image" value="" name="s1" id="btn_send" class="dynamic_img" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo LANGUI_SUPP_16;?>" tabindex="4;">
    </center>
</form>
<?php }elseif( is_get('id') && $ticket != null ){ ?>

<table class="rate_details lang_rtl lang_ar" cellpadding="1" cellspacing="1">
    <thead>
        <tr>
		  <th><?php echo $ticket["title"];?></th>
          <th><?php echo $ticket["added_time"];?></th>
        </tr>
    </thead>
    <tbody>
        <tr>
		  <td colspan="2"><?php echo nl2br($ticket["content"]); ?></td>
        </tr>
    </tbody>
</table>
<?php if( $reply != null ){ ?>

<table class="rate_details lang_rtl lang_ar" cellpadding="1" cellspacing="1">
<?php $counter1=-1; if( isset($reply) && is_array($reply) && sizeof($reply) ) foreach( $reply as $key1 => $value1 ){ $counter1++; ?>

    <thead>
        <tr>
		  <td><?php if( !$value1["is_player"] ){ ?><?php  echo LANGUI_SUPP_13;?><?php }else{ ?><?php  echo LANGUI_SUPP_14;?><?php } ?></td>
          <td><?php echo $value1["added_time"];?></td>
        </tr>
    </thead>
    <tbody>
        <tr <?php if( !$value1["is_player"] ){ ?>class="hl"<?php } ?>>
            <td colspan="2"><?php echo nl2br($value1["replay"]); ?></td>
        </tr>
    </tbody>
<?php } ?>

</table>
<?php } ?>

<?php if( $ticket["status"] != 3 ){ ?>

<form action='support?id=<?php echo $ticket["id"];?>' method='post'>
    <center>
        <input type="submit" name="close" value="<?php  echo LANGUI_SUPP_21;?>">
    </center>
</form>
<form action='support?id=<?php echo $ticket["id"];?>' method='post'>
    <table class="rate_details lang_rtl lang_ar" cellpadding="1" cellspacing="1">
        <thead>
            <tr>
                <td><?php  echo LANGUI_SUPP_15;?></td>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td><textarea name='reply' cols="69" rows="10"></textarea></td>
            </tr>
        </tbody>
    </table>
        <input type="image" value="" name="s1" id="btn_send" class="dynamic_img" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo LANGUI_SUPP_16;?>" tabindex="4;">
</form>
<?php } ?>

<?php }elseif( $selectedTabIndex <= 1 ){ ?>

<table class="rate_details lang_rtl lang_ar" cellpadding="1" cellspacing="1">
    <thead>
        <tr>
          <th colspan="3"><?php  echo LANGUI_SUPP_17;?></th>
        </tr>
        <tr>
            <td><?php  echo LANGUI_SUPP_18;?></td>
            <td><?php  echo LANGUI_SUPP_19;?></td>
            <td><?php  echo LANGUI_SUPP_20;?></td>
        </tr>
    </thead>
    <tbody>
    <?php $counter1=-1; if( isset($tickets) && is_array($tickets) && sizeof($tickets) ) foreach( $tickets as $key1 => $value1 ){ $counter1++; ?>

        <tr>
            <td><a href="support?id=<?php echo $value1["id"];?>"><?php echo $value1["title"];?></a></td>
            <td><?php echo constant('LANGUI_SUPP_stat_'.$value1["status"]); ?></td>
            <td><?php echo $value1["added_time"];?></td>
        </tr>
    <?php } ?>

    <?php if( $tickets == null ){ ?>

        <tr>
            <td colspan='3'>
                <center><?php  echo LANGUI_SUPP_22;?></center>
            </td>
        </tr>
    <?php } ?>

    </tbody>
</table>
<?php } ?>

</body>
</html>