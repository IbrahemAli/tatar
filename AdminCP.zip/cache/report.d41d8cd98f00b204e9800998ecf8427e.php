<?php if(!class_exists('raintpl')){exit;}?><!DOCTYPE html>

<html lang="ar">

<head>

    <meta charset="UTF-8">

    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

</head>

<body>
<?php echo load_lang('ui/report'); ?>

<h1><?php  echo LANGUI_RPT_T1;?></h1>
<div id="textmenu">
    <a href="report" <?php if( ( $selectedTabIndex == 0 ) ){ ?> class="selected" <?php } ?> ><?php  echo LANGUI_RPT_T2;?></a>
    |
    <a href="report?t=1" <?php if( ( $selectedTabIndex == 1 ) ){ ?> class="selected" <?php } ?> ><?php  echo LANGUI_RPT_T3;?></a>
    |
    <a href="report?t=2" <?php if( ( $selectedTabIndex == 2 ) ){ ?> class="selected" <?php } ?> ><?php  echo LANGUI_RPT_T4;?></a>
    |
    <a href="report?t=3" <?php if( ( $selectedTabIndex == 3 ) ){ ?>class="selected"<?php } ?> ><?php  echo LANGUI_RPT_T5;?></a>
    |
    <a href="report?t=4" <?php if( ( $selectedTabIndex == 4 ) ){ ?>class="selected"<?php } ?> ><?php  echo LANGUI_RPT_T6;?></a>
</div>
<?php if( ( $showList ) ){ ?>

<form method="post" action="report?p=<?php echo $pageIndex;?><?php if( ( 0 < $selectedTabIndex ) ){ ?>&t=<?php echo $selectedTabIndex;?><?php } ?>" name="msg">
    <table cellpadding="1" cellspacing="1" id="overview" class="row_table_data">
        <thead>
            <tr>
                <th colspan="2"><?php  echo LANGUI_RPT_T7;?></th>
                <th class="sent"><?php  echo LANGUI_RPT_T8;?></th>
            </tr>
        </thead>
        <tbody>
            <?php $counter1=-1; if( isset($dataListArray) && is_array($dataListArray) && sizeof($dataListArray) ) foreach( $dataListArray as $key1 => $value1 ){ $counter1++; ?>

                <tr>
                    <td class="sel">
                        <input class="check" type="checkbox" name="dr[]" value="<?php echo $value1["id"];?>">
                    </td>
                    <td class="sub">
                        <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="iReport iReport<?php echo $value1["_rptResultCss"];?>" alt="<?php echo $value1["btext"];?>" title="<?php echo $value1["btext"];?>">
                        <div>
                            <a href="report?id=<?php echo $value1["id"];?>">
                                <?php echo $value1["rpt_cat"];?>

                            </a>
                            <?php if( ( !$value1['is_readed'] ) ){ ?>

                                 <?php  echo LANGUI_RPT_T9;?>

                            <?php } ?>

                        </div>
                    </td>
                    <td class="dat"><?php echo $value1["mdate"];?></td>
                </tr>
            <?php } ?>

            <?php if( ( $counter1 == -1 ) ){ ?>

                <tr>
                    <td colspan="3" class="none"><?php  echo LANGUI_RPT_T10;?></td>
                </tr>
            <?php } ?>

        </tbody>
        <tfoot>
            <tr>
                <th>
                    <?php if( $counter1 > -1 ){ ?>

                    <input class="check"  type="checkbox" id="s10" name="s10" onclick="Allmsg(this.form);"><?php } ?></th>
                    <th class="buttons">
                    <?php if( $counter1 > -1 ){ ?>

                        <input name="delmsg" value="<?php  echo LANGUI_RPT_T11;?>" type="image" id="btn_delete" class="dynamic_img" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo LANGUI_RPT_T11;?>">
                    <?php } ?>

                    </th>
                    <th class="navi">
                        <?php echo $getPreviousLink;?>

                        <?php echo $getNextLink;?>

                    </th>
                </tr>
            </tfoot>
        </table>
</form>
<?php }elseif( ( $reportData['rpt_cat'] == 1 ) ){ ?>

<table cellpadding="1" cellspacing="1" id="report_surround">
        <thead>
            <tr>
                <th><?php  echo LANGUI_RPT_T7;?>:</th>
                <th>
                    <?php echo $getVillageName;?>

                    <?php echo $getreportactiontext;?>

                    <?php echo $getVillageName_to;?>

                </th>
            </tr>
            <tr>
                <td class="sent"><?php  echo LANGUI_RPT_T8;?>:</td>
                <td>
                    <?php  echo text_in_lang;?> <?php echo $reportData["mdate"];?>

                    <span><?php  echo time_hour_lang2;?> <?php echo $reportData["mtime"];?></span>
                </td>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td colspan="2" class="empty"></td>
            </tr>
            <tr>
                <td colspan="2" class="report_content">
                    <table cellpadding="1" cellspacing="1" id="trade">
                        <thead>
                            <tr>
                                <td>&nbsp;</td>
                                <td>
                                    <?php if( ( 0 < intval( $reportData['from_player_id'] ) ) ){ ?>

                                        <a href="profile?uid=<?php echo $reportData["from_player_id"];?>">
                                            <?php echo $reportData["from_player_name"];?>

                                        </a>
                                        <?php  echo LANGUI_RPT_T12;?>

                                        <a href="village3?id=<?php echo $reportData["from_village_id"];?>">
                                            <?php echo $getVillageName;?>

                                        </a>
                                        <?php }else{ ?>

                                            <span class="none"><?php echo $reportData["from_player_name"];?></span>
                                            <?php  echo LANGUI_RPT_T12;?>

                                            <span class="none">[?]</span>
                                        <?php } ?>

                                    </td>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <th><?php  echo LANGUI_RPT_T13;?></th>
                                    <td>
                                        <img class="r1" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo item_title_1;?>" title="<?php  echo item_title_1;?>">
                                        <?php echo $reportData["resources"]["0"];?> |
                                        <img class="r2" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo item_title_2;?>" title="<?php  echo item_title_2;?>">
                                        <?php echo $reportData["resources"]["1"];?> |
                                        <img class="r3" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo item_title_3;?>" title="<?php  echo item_title_3;?>">
                                        <?php echo $reportData["resources"]["2"];?> |
                                        <img class="r4" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo item_title_4;?>" title="<?php  echo item_title_4;?>">
                                        <?php echo $reportData["resources"]["3"];?>

                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
            </tbody>
</table>
<?php }elseif( ( $reportData['rpt_cat'] == 3 ) ){ ?>

    <table cellpadding="1" cellspacing="1" id="report_surround">
        <thead>
            <tr>
                <th><?php  echo LANGUI_RPT_T7;?>: </th>
                <th>
                    <?php echo $getVillageName;?>

                    <?php echo $getreportactiontext;?>

                    <?php echo $getVillageName_to;?>

                </th>
            </tr>
            <tr>
                <td class="sent"><?php  echo LANGUI_RPT_T8;?>:</td>
                <td>
                    <?php  echo text_in_lang;?> <?php echo $reportData["mdate"];?>

                    <span><?php  echo time_hour_lang2;?> <?php echo $reportData["mtime"];?></span>
                </td>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td colspan="2" class="empty"></td>
            </tr>
            <tr>
                <td colspan="2" class="report_content">
                    <table cellpadding="1" cellspacing="1" id="attacker">
                        <thead>
                            <tr>
                                <td class="role"><?php  echo LANGUI_RPT_T17;?></td>
                                <td colspan="<?php if( 0 < $reportData['attackTroopsTable']['heros']['number'] ){ ?> 11 <?php }else{ ?> 10 <?php } ?>" >
                                    <?php if( ( 0 < intval( $reportData['from_player_id'] ) ) ){ ?>

                                    <a href="profile?uid=<?php echo $reportData["from_player_id"];?>">
                                        <?php echo $reportData["from_player_name"];?>

                                    </a>
                                    <?php  echo LANGUI_RPT_T12;?>

                                    <a href="village3?id=<?php echo $reportData["from_village_id"];?>">
                                        <?php echo $getVillageName;?>

                                    </a>
                                    <?php }else{ ?>

                                        <span class="none"><?php echo $reportData["from_player_name"];?></span>
                                        <?php  echo LANGUI_RPT_T12;?>

                                        <span class="none">[?]</span>
                                    <?php } ?>

                                </td>
                            </tr>
                        </thead>
                        <tbody class="units">
                            <tr>
                                <td>&nbsp;</td>

                                <?php $counter1=-1; if( isset($reportData['attackTroopsTable']['troops']) && is_array($reportData['attackTroopsTable']['troops']) && sizeof($reportData['attackTroopsTable']['troops']) ) foreach( $reportData['attackTroopsTable']['troops'] as $key1 => $value1 ){ $counter1++; ?>

                                    <?php if( ( $key1 > 0 ) ){ ?>

                                        <td>
                                            <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="unit u<?php echo $key1;?>" title="<?php echo constant('troop_'.$key1 ); ?>" alt="<?php echo constant('troop_'.$key1 ); ?>">
                                        </td>
                                    <?php } ?>

                                <?php } ?>

                                <?php if( ( 0 < $reportData['attackTroopsTable']['heros']['number'] ) ){ ?>

                                    <td>
                                        <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="unit uhero" title="<?php  echo troop_hero;?>" alt="<?php  echo troop_hero;?>">
                                    </td>
                                <?php } ?>

                            </tr>
                            <tr>
                                <th><?php  echo LANGUI_RPT_T14;?></th>
                                <?php $counter1=-1; if( isset($reportData['attackTroopsTable']['troops']) && is_array($reportData['attackTroopsTable']['troops']) && sizeof($reportData['attackTroopsTable']['troops']) ) foreach( $reportData['attackTroopsTable']['troops'] as $key1 => $value1 ){ $counter1++; ?>

                                    <?php if( ( $key1 > 0 ) ){ ?>

                                        <?php $tnum = $value1['number'];?>


                                        <?php if( ( $tnum <= 0 ) ){ ?>

                                            <td class="none">0</td>
                                        <?php }else{ ?>

                                            <td><?php echo $tnum;?></td>
                                        <?php } ?>

                                    <?php } ?>

                                <?php } ?>


                                <?php if( ( 0 < $reportData['attackTroopsTable']['heros']['number'] ) ){ ?>

                                    <td <?php if( ( $reportData['attackTroopsTable']['heros']['number'] == 0 ) ){ ?>class="none"<?php } ?>>
                                        <?php echo $reportData["attackTroopsTable"]["heros"]["number"];?>

                                    </td>
                                <?php } ?>

                            </tr>
                            <tr>
                                <th><?php  echo LANGUI_RPT_T18;?></th>
                                <?php $counter1=-1; if( isset($reportData['attackTroopsTable']['troops']) && is_array($reportData['attackTroopsTable']['troops']) && sizeof($reportData['attackTroopsTable']['troops']) ) foreach( $reportData['attackTroopsTable']['troops'] as $key1 => $value1 ){ $counter1++; ?>

                                    <?php if( ( $key1 > 0 ) ){ ?>

                                        <?php $tnum = $value1['dead_number'];?>


                                        <?php if( ( $tnum <= 0 ) ){ ?>

                                            <td class="none">0</td>
                                        <?php }else{ ?>

                                            <td><?php echo $tnum;?></td>
                                        <?php } ?>

                                    <?php } ?>

                                <?php } ?>

                                <?php if( ( 0 < $reportData['attackTroopsTable']['heros']['number'] ) ){ ?>

                                    <td <?php if( ( $reportData['attackTroopsTable']['heros']['dead_number'] == 0 ) ){ ?>class="none"<?php } ?>>
                                        <?php echo $reportData["attackTroopsTable"]["heros"]["dead_number"];?>

                                    </td>
                                <?php } ?>

                            </tr>
                        </tbody>

                        <?php if( ( !$reportData['all_attackTroops_dead'] ) ){ ?>

                        <tbody class="goods">
                                    <tr>
                                        <th><?php  echo LANGUI_RPT_T24;?></th>
                                        <td colspan="<?php if( 0 < $reportData['attackTroopsTable']['heros']['number'] ){ ?> 11 <?php }else{ ?> 10<?php } ?>">
                                            <div class="res">
                                                <img class="r1" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo item_title_1;?>" title="<?php  echo item_title_1;?>">
                                                <?php echo $reportData["harvest_resources"]["0"];?> |
                                                <img class="r2" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo item_title_2;?>" title="<?php  echo item_title_2;?>">
                                                <?php echo $reportData["harvest_resources"]["1"];?> |
                                                <img class="r3" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo item_title_3;?>" title="<?php  echo item_title_3;?>">
                                                <?php echo $reportData["harvest_resources"]["2"];?> |
                                                <img class="r4" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo item_title_4;?>" title="<?php  echo item_title_4;?>">
                                                <?php echo $reportData["harvest_resources"]["3"];?>

                                            </div>
                                            <div class="carry">
                                                <img class="car" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo LANGUI_RPT_T19;?>" title="<?php  echo LANGUI_RPT_T19;?>">
                                                <?php echo $reportData["total_carry_load"];?> / <?php echo $reportData["total_harvest_carry_load"];?>

                                            </div>
                                        </td>
                                    </tr>
                        </tbody>
                        <?php } ?>

                        <?php if( ( $reportData['all_attackTroops_dead'] ) ){ ?>

                            <tbody class="infos">
                                <tr>
                                    <th><?php  echo LANGUI_RPT_T20;?></th>
                                    <td colspan="<?php if( 0 < $reportData['attackTroopsTable']['heros']['number'] ){ ?> 11 <?php }else{ ?> 10<?php } ?>">
                                        <?php  echo LANGUI_RPT_T21;?>

                                    </td>
                                </tr>
                            </tbody>
                            <?php }else{ ?>

                                <?php if( ( isset( $reportData['captureResult'] ) ) ){ ?>

                                    <tbody class="infos">
                                        <tr>
                                            <th><?php  echo LANGUI_RPT_T20;?></th>
                                            <td colspan="<?php if( 0 < $reportData['attackTroopsTable']['heros']['number'] ){ ?> 11 <?php }else{ ?> 10 <?php } ?>">
                                                <?php echo $reportData["captureResult"];?>

                                            </td>
                                        </tr>
                                    </tbody>
                                <?php } ?>


                                <?php if( ( isset( $reportData['oasisResult'] ) ) ){ ?>

                                    <tbody class="infos">
                                        <tr>
                                            <th><?php  echo LANGUI_RPT_T20;?></th>
                                            <td colspan="<?php if( 0 < $reportData['attackTroopsTable']['heros']['number'] ){ ?> 11 <?php }else{ ?> 10<?php } ?>">
                                                <?php echo $reportData["oasisResult"];?>

                                            </td>
                                        </tr>
                                    </tbody>
                                <?php } ?>


                                <?php if( ( isset( $reportData['wallDestructionResult'] ) ) ){ ?>

                                    <tbody class="infos">
                                        <tr>
                                            <th><?php  echo LANGUI_RPT_T20;?></th>
                                            <td colspan="<?php if( 0 < $reportData['attackTroopsTable']['heros']['number'] ){ ?>  11 <?php }else{ ?> 10<?php } ?>">
                                                <?php echo $reportData["wallDestructionResult"];?>

                                            </td>
                                        </tr>
                                    </tbody>
                                <?php } ?>


                                <?php if( ( isset( $reportData['buildingDestructionResult'] ) ) ){ ?>

                                    <?php $counter1=-1; if( isset($reportData['buildingDestructionResult']) && is_array($reportData['buildingDestructionResult']) && sizeof($reportData['buildingDestructionResult']) ) foreach( $reportData['buildingDestructionResult'] as $key1 => $value1 ){ $counter1++; ?>

                                        <tbody class="infos">
                                            <tr>
                                                <th><?php  echo LANGUI_RPT_T20;?></th>
                                                <td colspan="<?php if( 0 < $reportData['attackTroopsTable']['heros']['number'] ){ ?>11<?php }else{ ?>10<?php } ?>">
                                                    <?php echo $value1;?>

                                                </td>
                                            </tr>
                                        </tbody>
                                    <?php } ?>

                                <?php } ?>

                        <?php } ?>

                    </table>
                    <?php if( ( $data['player_type'] == PLAYERTYPE_ADMIN || $data['player_type'] == PLAYERTYPE_HUNTER || $reportData['deadRate'] >= 90 ||(!$reportData['all_attackTroops_dead']
                        || intval( $reportData['to_player_id'] ) == $player->playerId
                        || $playerRie == $player->playerId || $reportData['to_player_alliance_id'] == $data['alliance_id']
                        && 0 < intval( $data['alliance_id'] )) ) ){ ?>


                            <?php $counter1=-1; if( isset($reportData['defenseTroopsTable']) && is_array($reportData['defenseTroopsTable']) && sizeof($reportData['defenseTroopsTable']) ) foreach( $reportData['defenseTroopsTable'] as $key1 => $value1 ){ $counter1++; ?>

                                <table cellpadding="1" cellspacing="1" class="defender">
                                    <thead>
                                        <tr>
                                            <td class="role"><?php  echo LANGUI_RPT_T22;?></td>
                                            <td colspan="<?php if( 0 < $value1['heros']['number'] ){ ?> 11 <?php }else{ ?> 10<?php } ?>">
                                                    <?php if( ( $counter1 == 0 ) ){ ?>

                                                        <?php if( ( 0 < intval( $reportData['to_player_id'] ) ) ){ ?>

                                                            <a href="profile?uid=<?php echo $reportData["to_player_id"];?>"><?php echo $reportData["to_player_name"];?></a>
                                                            <?php  echo LANGUI_RPT_T12;?>

                                                            <a href="village3?id=<?php echo $reportData["to_village_id"];?>">
                                                                <?php echo $getVillageName_to;?>

                                                            </a>
                                                        <?php }else{ ?>

                                                            <span class="none"><?php echo $reportData["to_player_name"];?></span>
                                                            <?php  echo LANGUI_RPT_T12;?>

                                                            <span class="none">[?]</span>
                                                        <?php } ?>

                                                    <?php }else{ ?>

                                                        <?php  echo LANGUI_RPT_T4;?>

                                                    <?php } ?>

                                            </td>
                                        </tr>
                                    </thead>
                                    <tbody class="units">
                                            <tr>
                                                <td>&nbsp;</td>
                                                <?php $counter2=-1; if( isset($value1['troops']) && is_array($value1['troops']) && sizeof($value1['troops']) ) foreach( $value1['troops'] as $key2 => $value2 ){ $counter2++; ?>

                                                    <?php if( ( $key2 > 0 ) ){ ?>

                                                        <td>
                                                            <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="unit u<?php echo $key2;?>" title="<?php echo constant('troop_'.$key2 ); ?>" alt="<?php echo constant('troop_'.$key2 ); ?>">
                                                        </td>
                                                    <?php } ?>

                                                <?php } ?>


                                                <?php if( ( 0 < $value1['heros']['number'] ) ){ ?>

                                                    <td>
                                                        <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="unit uhero" title="<?php  echo troop_hero;?>" alt="<?php  echo troop_hero;?>"></td>
                                                <?php } ?>

                                            </tr>
                                            <tr>
                                                <th><?php  echo LANGUI_RPT_T14;?></th>
                                                <?php $counter2=-1; if( isset($value1['troops']) && is_array($value1['troops']) && sizeof($value1['troops']) ) foreach( $value1['troops'] as $key2 => $value2 ){ $counter2++; ?>

                                                    <?php if( ( $key2 > 0 ) ){ ?>

                                                    <?php $tnum = $value2['number'];?>

                                                        <?php if( ( $tnum <= 0 ) ){ ?>

                                                            <td class="none">0</td>
                                                        <?php }else{ ?>

                                                            <td><?php echo $tnum;?></td>
                                                        <?php } ?>

                                                    <?php } ?>

                                                <?php } ?>


                                                <?php if( ( 0 < $value1['heros']['number'] ) ){ ?>

                                                    <td <?php if( ( $value1['heros']['number'] == 0 ) ){ ?> class="none" <?php } ?>><?php echo $value1["heros"]["number"];?></td>
                                                <?php } ?>

                                            </tr>
                                            <tr>
                                                <th><?php  echo LANGUI_RPT_T18;?></th>
                                                <?php $counter2=-1; if( isset($value1['troops']) && is_array($value1['troops']) && sizeof($value1['troops']) ) foreach( $value1['troops'] as $key2 => $value2 ){ $counter2++; ?>

                                                    <?php if( ( $key2 > 0 ) ){ ?>

                                                        <?php $tnum = $value2['dead_number'];?>


                                                        <?php if( ( $tnum <= 0 ) ){ ?>

                                                            <td class="none">0</td>
                                                        <?php }else{ ?>

                                                            <td><?php echo $tnum;?></td>
                                                        <?php } ?>

                                                    <?php } ?>

                                                <?php } ?>


                                                <?php if( ( 0 < $value1['heros']['number'] ) ){ ?>

                                                    <td <?php if( ( $value1['heros']['dead_number'] == 0 ) ){ ?>class="none"<?php } ?>><?php echo $value1["heros"]["dead_number"];?></td>
                                                <?php } ?>

                                            </tr>
                                    </tbody>
                                </table>
                            <?php } ?>

                    <?php } ?>

                        </td>
                    </tr>
                </tbody>
    </table>
    <p></p>
<?php }elseif( ( $reportData['rpt_cat'] == 2 ) ){ ?>

        <table cellpadding="1" cellspacing="1" id="report_surround">
            <thead>
                <tr>
                    <th>
                        <?php  echo LANGUI_RPT_T7;?> :
                    </th>
                    <th>
                        <?php echo $getVillageName;?>

                        <?php echo $getreportactiontext;?>

                        <?php echo $getVillageName_to;?>

                    </th>
                </tr>
                <tr>
                    <td class="sent"><?php  echo LANGUI_RPT_T8;?>:</td>
                    <td>
                        <?php  echo text_in_lang;?> <?php echo $reportData["mdate"];?>

                        <span><?php  echo time_hour_lang2;?> <?php echo $reportData["mtime"];?></span>
                    </td>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td colspan="2" class="empty"></td>
                </tr>
                <tr>
                    <td colspan="2" class="report_content">
                        <table cellpadding="1" cellspacing="1" id="reinforcement">
                            <thead>
                                <tr>
                                    <td class="role"><?php  echo LANGUI_RPT_T23;?></td>
                                    <td colspan="<?php if( $reportData['troopsTable']['hasHero'] ){ ?> 11 <?php }else{ ?> 10 <?php } ?>">
                                        <?php if( ( 0 < intval( $reportData['from_player_id'] ) ) ){ ?>

                                                <a href="profile?uid=<?php echo $reportData["from_player_id"];?>">
                                                    <?php echo $reportData["from_player_name"];?>

                                                </a>
                                                <?php  echo LANGUI_RPT_T12;?>

                                                <a href="village3?id=<?php echo $reportData["from_village_id"];?>">
                                                    <?php echo $getVillageName;?>

                                                </a>
                                            <?php }else{ ?>

                                                <span class="none"><?php echo $reportData["from_player_name"];?></span>
                                                <?php  echo LANGUI_RPT_T12;?>

                                                <span class="none">[?]</span>
                                            <?php } ?>

                                        </td>
                                    </tr>
                                </thead>
                                <tbody class="units">
                                    <tr>
                                        <td>&nbsp;</td>
                                        <?php $counter1=-1; if( isset($reportData['troopsTable']['troops']) && is_array($reportData['troopsTable']['troops']) && sizeof($reportData['troopsTable']['troops']) ) foreach( $reportData['troopsTable']['troops'] as $key1 => $value1 ){ $counter1++; ?>

                                            <?php if( ( $key1 > 0 ) ){ ?>

                                                <td>
                                                    <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="unit u<?php echo $key1;?>" title="<?php echo constant('troop_'.$key1 ); ?>" alt="<?php echo constant('troop_'.$key1 ); ?>">
                                                </td>
                                            <?php } ?>

                                        <?php } ?>


                                        <?php if( ( $reportData['troopsTable']['hasHero'] ) ){ ?>

                                            <td>
                                                <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="unit uhero" title="<?php  echo troop_hero;?>" alt="<?php  echo troop_hero;?>">
                                            </td>
                                        <?php } ?>

                                    </tr>
                                    <tr>
                                        <th><?php  echo LANGUI_RPT_T14;?></th>

                                        <?php $counter1=-1; if( isset($reportData['troopsTable']['troops']) && is_array($reportData['troopsTable']['troops']) && sizeof($reportData['troopsTable']['troops']) ) foreach( $reportData['troopsTable']['troops'] as $key1 => $value1 ){ $counter1++; ?>

                                            <?php if( ( $key1 > 0 ) ){ ?>

                                                <?php if( ( $value1 <= 0 ) ){ ?>

                                                    <td class="none">0</td>
                                                <?php }else{ ?>

                                                    <td><?php echo $value1;?></td>
                                                <?php } ?>

                                            <?php } ?>

                                        <?php } ?>


                                        <?php if( ( $reportData['troopsTable']['hasHero'] ) ){ ?>

                                            <td>1</td>
                                        <?php } ?>

                                    </tr>
                                </tbody>
                                <tbody class="infos">
                                    <tr>
                                        <th><?php  echo LANGUI_RPT_T15;?></th>
                                        <td colspan="<?php if( $reportData['troopsTable']['hasHero'] ){ ?> 11 <?php }else{ ?> 10 <?php } ?> ">
                                            <?php echo $reportData["cropConsume"];?>

                                            <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="r4" title="<?php  echo item_title_4;?>" alt="<?php  echo item_title_4;?>">
                                            <?php  echo LANGUI_RPT_T16;?>

                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </td>
                    </tr>
                </tbody>
        </table>
<?php }elseif( ( $reportData['rpt_cat'] == 4 ) ){ ?>

    <table cellpadding="1" cellspacing="1" id="report_surround">
        <thead>
            <tr>
                <th>
                    <?php  echo LANGUI_RPT_T7;?> :
                </th>
                <th>
                    <?php echo $getVillageName;?>

                    <?php echo $getreportactiontext;?>

                    <?php echo $getVillageName_to;?>

                </th>
            </tr>
            <tr>
                <td class="sent"><?php  echo LANGUI_RPT_T8;?> : </td>
                <td>
                    <?php  echo text_in_lang;?> <?php echo $reportData["mdate"];?>

                    <span>
                        <?php  echo time_hour_lang2;?> <?php echo $reportData["mtime"];?>

                    </span>
                </td>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td colspan="2" class="empty"></td>
            </tr>
            <tr>
                <td colspan="2" class="report_content">
                    <table cellpadding="1" cellspacing="1" id="attacker">
                        <thead>
                            <tr>
                                <td class="role"><?php  echo LANGUI_RPT_T17;?></td>
                                <td colspan="<?php if( 0 < $reportData['attackTroopsTable']['heros']['number'] ){ ?> 11 <?php }else{ ?> 10<?php } ?>">
                                <?php if( ( 0 < intval( $reportData['from_player_id'] ) ) ){ ?>

                                    <a href="profile?uid=<?php echo $reportData["from_player_id"];?>"><?php echo $reportData["from_player_name"];?></a>
                                        <?php  echo LANGUI_RPT_T12;?>

                                    <a href="village3?id=<?php echo $reportData["from_village_id"];?>">
                                        <?php echo $getVillageName;?>

                                    </a>
                                <?php }else{ ?>

                                    <span class="none"><?php echo $reportData["from_player_name"];?></span>
                                    <?php  echo LANGUI_RPT_T12;?>

                                    <span class="none">[?]</span>
                                <?php } ?>

                                </td>
                                </tr>
                            </thead>
                            <tbody class="units">
                                <tr>
                                    <td>&nbsp;</td>
                                    <?php $counter1=-1; if( isset($reportData['attackTroopsTable']['troops']) && is_array($reportData['attackTroopsTable']['troops']) && sizeof($reportData['attackTroopsTable']['troops']) ) foreach( $reportData['attackTroopsTable']['troops'] as $key1 => $value1 ){ $counter1++; ?>

                                        <?php if( ( $key1 > 0 ) ){ ?>

                                            <td>
                                                <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="unit u<?php echo $key1;?>" title="<?php echo constant('troop_'.$key1 ); ?>" alt="<?php echo constant('troop_'.$key1 ); ?>">
                                            </td>
                                        <?php } ?>

                                    <?php } ?>


                                        <?php if( ( 0 < $reportData['attackTroopsTable']['heros']['number'] ) ){ ?>

                                            <td>
                                                <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="unit uhero" title="<?php  echo troop_hero;?>" alt="<?php  echo troop_hero;?>">
                                            </td>
                                        <?php } ?>

                                    </tr>
                                    <tr>
                                        <th><?php  echo LANGUI_RPT_T14;?></th>
                                        <?php $counter1=-1; if( isset($reportData['attackTroopsTable']['troops']) && is_array($reportData['attackTroopsTable']['troops']) && sizeof($reportData['attackTroopsTable']['troops']) ) foreach( $reportData['attackTroopsTable']['troops'] as $key1 => $value1 ){ $counter1++; ?>

                                            <?php if( ( $key1 > 0 ) ){ ?>

                                                <?php $tnum = $value1['number'];?>


                                                <?php if( ( $tnum <= 0 ) ){ ?>

                                                    <td class="none">0</td>
                                                <?php }else{ ?>

                                                    <td><?php echo $tnum;?></td>
                                                <?php } ?>

                                            <?php } ?>

                                        <?php } ?>


                                        <?php if( ( 0 < $reportData['attackTroopsTable']['heros']['number'] ) ){ ?>

                                            <td <?php if( ( $reportData['attackTroopsTable']['heros']['number'] == 0 ) ){ ?> class="none" <?php } ?>>
                                                    <?php echo $reportData["attackTroopsTable"]["heros"]["number"];?>

                                            </td>
                                        <?php } ?>

                                        </tr>
                                        <tr>
                                            <th><?php  echo LANGUI_RPT_T18;?></th>
                                            <?php $counter1=-1; if( isset($reportData['attackTroopsTable']['troops']) && is_array($reportData['attackTroopsTable']['troops']) && sizeof($reportData['attackTroopsTable']['troops']) ) foreach( $reportData['attackTroopsTable']['troops'] as $key1 => $value1 ){ $counter1++; ?>

                                                <?php if( ( $key1 > 0 ) ){ ?>

                                                    <?php $tnum = $value1['dead_number'];?>


                                                    <?php if( ( $tnum <= 0 ) ){ ?>

                                                        <td class="none">0</td>
                                                    <?php }else{ ?>

                                                        <td><?php echo $tnum;?></td>
                                                    <?php } ?>

                                                <?php } ?>

                                            <?php } ?>


                                            <?php if( ( 0 < $reportData['attackTroopsTable']['heros']['number'] ) ){ ?>

                                                <td <?php if( ( $reportData['attackTroopsTable']['heros']['dead_number'] == 0 ) ){ ?>class="none"<?php } ?>>
                                                    <?php echo $reportData["attackTroopsTable"]["heros"]["dead_number"];?>

                                                </td>
                                            <?php } ?>

                                            </tr>
                                    </tbody>

                                        <?php if( ( isset( $reportData['harvest_resources'] ) ) ){ ?>

                                        <tbody class="goods">
                                            <tr>
                                                <th><?php  echo LANGUI_RPT_T13;?></th>
                                                <td colspan="<?php if( 0 < $reportData['attackTroopsTable']['heros']['number'] ){ ?> 11 <?php }else{ ?> 10 <?php } ?>">
                                                    <div class="res">
                                                        <img class="r1" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo item_title_1;?>" title=" <?php  echo item_title_1;?>">
                                                        <?php echo $reportData["harvest_resources"]["0"];?>

                                                        <img class="r2" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo item_title_2;?>" title="<?php  echo item_title_2;?>">
                                                        <?php echo $reportData["harvest_resources"]["1"];?> |
                                                        <img class="r3" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo item_title_3;?>" title="<?php  echo item_title_3;?>">
                                                        <?php echo $reportData["harvest_resources"]["2"];?> |
                                                        <img class="r4" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo item_title_4;?>" title="<?php  echo item_title_4;?>">
                                                        <?php echo $reportData["harvest_resources"]["3"];?></div>
                                                </td>
                                            </tr>
                                        </tbody>
                                        <?php } ?>


                                        <?php if( ( isset( $reportData['harvest_info'] ) ) ){ ?>

                                        <tbody class="infos">
                                            <tr>
                                                <th><?php  echo LANGUI_RPT_T20;?></th>
                                                <td colspan="10"><?php echo $reportData["harvest_info"];?></td>
                                            </tr>
                                        </tbody>
                                        <?php } ?>

                                </table>

                                    <?php if( ( !$reportData['all_spy_dead'] || intval( $reportData['to_player_id'] ) == $player->playerId
                                    || $reportData['to_player_alliance_id'] == $data['alliance_id'] && 0 < intval( $data['alliance_id'] ) ) ){ ?>


                                            <?php $counter1=-1; if( isset($reportData['defenseTroopsTable']) && is_array($reportData['defenseTroopsTable']) && sizeof($reportData['defenseTroopsTable']) ) foreach( $reportData['defenseTroopsTable'] as $key1 => $value1 ){ $counter1++; ?>

                                                <table cellpadding="1" cellspacing="1" class="defender">
                                                    <thead>
                                                        <tr>
                                                            <td class="role"><?php  echo LANGUI_RPT_T22;?></td>
                                                            <td colspan="<?php if( 0 < $value1['heros']['number'] ){ ?> 11 <?php }else{ ?> 10<?php } ?>">
                                                                <?php if( ( $counter1 == 0 ) ){ ?>

                                                                    <?php if( ( 0 < intval( $reportData['to_player_id'] ) ) ){ ?>

                                                                        <a href="profile?uid=<?php echo $reportData["to_player_id"];?>"><?php echo $reportData["to_player_name"];?></a>
                                                                        <?php  echo LANGUI_RPT_T12;?>

                                                                        <a href="village3?id=<?php echo $reportData["to_village_id"];?>">
                                                                            <?php echo $getVillageName_to;?>

                                                                        </a>
                                                                    <?php }else{ ?>

                                                                        <span class="none"><?php echo $reportData["to_player_name"];?></span>
                                                                        <?php  echo LANGUI_RPT_T12;?>

                                                                        <span class="none">[?]</span>
                                                                    <?php } ?>

                                                                <?php }else{ ?>

                                                                    <?php  echo LANGUI_RPT_T4;?>

                                                                <?php } ?>

                                                                </td>
                                                            </tr>
                                                        </thead>
                                                        <tbody class="units">
                                                            <tr>
                                                                <td>&nbsp;</td>
                                                                <?php $counter2=-1; if( isset($value1['troops']) && is_array($value1['troops']) && sizeof($value1['troops']) ) foreach( $value1['troops'] as $key2 => $value2 ){ $counter2++; ?>

                                                                   <?php if( ( $key2 > 0 ) ){ ?>

                                                                        <td>
                                                                            <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="unit u<?php echo $key2;?>" title="<?php echo constant('troop_'.$key2 ); ?>" alt="<?php echo constant('troop_'.$key2 ); ?>">
                                                                        </td>
                                                                    <?php } ?>

                                                                <?php } ?>


                                                                <?php if( ( 0 < $value1['heros']['number'] ) ){ ?>

                                                                    <td>
                                                                        <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="unit uhero" title="<?php  echo troop_hero;?>" alt="<?php  echo troop_hero;?>">
                                                                    </td>
                                                                <?php } ?>

                                                            </tr>
                                                            <tr>
                                                                <th><?php  echo LANGUI_RPT_T14;?></th>
                                                                <?php $counter2=-1; if( isset($value1['troops']) && is_array($value1['troops']) && sizeof($value1['troops']) ) foreach( $value1['troops'] as $key2 => $value2 ){ $counter2++; ?>

                                                                    <?php if( ( $key2 > 0 ) ){ ?>

                                                                        <?php $tnum = $value2['number'];?>


                                                                        <?php if( ( $tnum <= 0 ) ){ ?>

                                                                            <td class="none">0</td>
                                                                        <?php }else{ ?>

                                                                            <td><?php echo $tnum;?></td>
                                                                        <?php } ?>

                                                                    <?php } ?>

                                                                <?php } ?>


                                                                <?php if( ( 0 < $value1['heros']['number'] ) ){ ?>

                                                                    <td <?php if( ( $value1['heros']['number'] == 0 ) ){ ?> class="none" <?php } ?>>
                                                                        <?php echo $value1["heros"]["number"];?>

                                                                    </td>
                                                                <?php } ?>

                                                            </tr>
                                                            <tr>
                                                                <th><?php  echo LANGUI_RPT_T18;?></th>
                                                                <?php $counter2=-1; if( isset($value1['troops']) && is_array($value1['troops']) && sizeof($value1['troops']) ) foreach( $value1['troops'] as $key2 => $value2 ){ $counter2++; ?>

                                                                    <?php if( ( $key2 > 0 ) ){ ?>

                                                                        <?php $tnum = $value2['dead_number'];?>


                                                                        <?php if( ( $tnum <= 0 ) ){ ?>

                                                                            <td class="none">0</td>
                                                                        <?php }else{ ?>

                                                                            <td><?php echo $tnum;?></td>
                                                                        <?php } ?>

                                                                    <?php } ?>

                                                                <?php } ?>


                                                                <?php if( ( 0 < $value1['heros']['number'] ) ){ ?>

                                                                    <td <?php if( ( $value1['heros']['dead_number'] == 0 ) ){ ?>class="none"<?php } ?>>
                                                                        <?php echo $value1["heros"]["dead_number"];?>

                                                                    </td>
                                                                <?php } ?>

                                                            </tr>
                                                        </tbody>
                                                </table>
                                            <?php } ?>

                                        <?php } ?>

                                        </td>
                                    </tr>
                                </tbody>
                            </table>

<?php }elseif( ( $reportData['rpt_cat'] == 5 ) ){ ?>

    <table cellpadding="1" cellspacing="1" id="report_surround">
        <thead>
            <tr>
                <th>
                    <?php  echo LANGUI_RPT_T7;?> :
                </th>
                <th>
                    <?php echo $getreportactiontext;?>

                    <?php echo $tovillg;?>

                </th>
            </tr>
            <tr>
                <td class="sent">
                    <?php  echo LANGUI_RPT_T8;?> :
                </td>
                <td>
                    <?php  echo text_in_lang;?>

                    <?php echo $reportData["mdate"];?>

                    <span>
                        <?php  echo time_hour_lang2;?>

                        <?php echo $reportData["mtime"];?>

                    </span>
                </td>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td colspan="2" class="empty"></td>
            </tr>
            <tr>
                <td class="role"><?php  echo LANGUI_RPT_T17;?></td>
                <td colspan="2">
                    <a href="profile?uid=<?php echo $reportData["from_player_id"];?>">
                        <?php echo $reportData["from_player_name"];?>

                    </a>
                    <?php  echo LANGUI_RPT_T12;?>

                    <a href="village3?id=<?php echo $reportData["from_village_id"];?>">
                        <?php echo $getVillageName;?>

                    </a>
                </td>
            </tr>
            <tr>
                <td colspan="2" class="empty"></td>
            </tr>
            <table cellpadding="1" cellspacing="1" class="defender">
                <thead>
                    <tr>
                        <td class="role"><?php  echo LANGUI_RPT_T22;?></td>
                        <td colspan="<?php if( $hasHero ){ ?>11 <?php }else{ ?> 10<?php } ?>">
                            <a href="profile?uid=<?php echo $reportData["to_player_id"];?>">
                                <?php echo $reportData["to_player_name"];?>

                            </a>
                            <?php  echo LANGUI_RPT_T12;?>

                            <a href="village3?id=<?php echo $reportData["to_village_id"];?>">
                                <?php echo $getVillageName_to;?>

                            </a>
                        </td>
                    </tr>
                </thead>
                <tbody class="units">
                    <tr>
                        <td>&nbsp;</td>
                        <?php $a_arr = explode(',', $toorp);?>

                        <?php $counter1=-1; if( isset($a_arr) && is_array($a_arr) && sizeof($a_arr) ) foreach( $a_arr as $key1 => $value1 ){ $counter1++; ?>

                            <?php $p =explode(' ', $value1);?> <?php $tid = $p["0"];?>


                            <?php if( ($tid == 0 - 1) ){ ?>

                                <?php $tid = 'hero';?>

                            <?php } ?>

                                <td>
                                    <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="unit u<?php echo $tid;?>" title="constant('troop_'.$tid )"}" alt="constant('troop_'.$tid )"}">
                                </td>
                        <?php } ?>

                    </tr>
                    <tr>
                        <th><?php  echo LANGUI_RPT_T14;?></th>
                        <?php $counter1=-1; if( isset($a_arr) && is_array($a_arr) && sizeof($a_arr) ) foreach( $a_arr as $key1 => $value1 ){ $counter1++; ?>

                            <?php $p =explode(' ', $value1);?> <?php $tnum = $p["1"];?>


                            <?php if( ( $tnum <= 0 ) ){ ?>

                                <td class="none">0</td>
                            <?php }else{ ?>

                                 <td><?php echo $tnum;?></td>
                            <?php } ?>


                        <?php } ?>

                    </tr>
                    <tr>
                        <th><?php  echo LANGUI_RPT_T18;?></th>
                        <?php $counter1=-1; if( isset($a_arr) && is_array($a_arr) && sizeof($a_arr) ) foreach( $a_arr as $key1 => $value1 ){ $counter1++; ?>

                            <?php $p =explode(' ', $value1);?>

                            <?php $deadNum = $p["2"];?>


                            <?php if( ( $deadNum <= 0 ) ){ ?>

                                <td class="none">0</td>
                            <?php }else{ ?>

                                <td><?php echo $deadNum;?></td>
                            <?php } ?>

                        <?php } ?>

                    </tr>
                </tbody>
            </table>
        </td>
    </tr>
</tbody>
</table>
<p></p>
<?php }elseif( $reportData['rpt_cat'] == 6 ){ ?>

    <table cellpadding="1" cellspacing="1" id="report_surround">
        <thead>
            <tr>
                <th>
                    <?php  echo LANGUI_RPT_T7;?> :
                </th>
                <th>
                    <?php echo $getreportactiontext;?>

                    <?php echo $reportData["from_village_name"];?>

                </th>
            </tr>
            <tr>
                <td class="sent">
                    <?php  echo LANGUI_RPT_T8;?> :
                </td>
                <td>
                    <?php  echo text_in_lang;?>

                    <?php echo $reportData["mdate"];?>

                    <span>
                        <?php  echo time_hour_lang2;?>

                        <?php echo $reportData["mtime"];?>

                    </span>
                </td>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td colspan="2" class="empty"></td>
            </tr>
            <?php if( $reportData["from_village_id"] != $reportData["to_village_id"] ){ ?>

            <tr>
                <td class="role"><?php  echo LANGUI_RPT_T25;?></td>
                <td colspan="2">
                    <a href="profile?uid=<?php echo $reportData["from_player_id"];?>">
                        <?php echo $reportData["from_player_name"];?>

                    </a>
                    <?php  echo LANGUI_RPT_T12;?>

                    <a href="village3?id=<?php echo $reportData["from_village_id"];?>">
                        <?php echo $getVillageName;?>

                    </a>
                </td>
            </tr>
            <tr>
                <td colspan="2" class="empty"></td>
            </tr>
            <?php } ?>

            <table cellpadding="1" cellspacing="1" class="defender">
                <thead>
                    <tr>
                        <td class="role"><?php  echo LANGUI_RPT_T26;?></td>
                        <td colspan="<?php if( $hasHero ){ ?>11 <?php }else{ ?> 10<?php } ?>">
                            <a href="profile?uid=<?php echo $reportData["to_player_id"];?>">
                                <?php echo $reportData["to_player_name"];?>

                            </a>
                            <?php  echo LANGUI_RPT_T12;?>

                            <a href="village3?id=<?php echo $reportData["to_village_id"];?>">
                                <?php echo $getVillageName_to;?>

                            </a>
                        </td>
                    </tr>
                </thead>
                <tbody class="units">
                    <tr>
                        <td>&nbsp;</td>
                        <?php $a_arr = explode(',', $toorp);?>

                        <?php $counter1=-1; if( isset($a_arr) && is_array($a_arr) && sizeof($a_arr) ) foreach( $a_arr as $key1 => $value1 ){ $counter1++; ?>

                            <?php $p =explode(' ', $value1);?> <?php $tid = $p["0"];?>


                            <?php if( ($tid == 0 - 1) ){ ?>

                                <?php $tid = 'hero';?>

                            <?php } ?>

                                <td>
                                    <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="unit u<?php echo $tid;?>" title="constant('troop_'.$tid )"}" alt="constant('troop_'.$tid )"}">
                                </td>
                        <?php } ?>

                    </tr>
                    <tr>
                        <th><?php  echo LANGUI_RPT_T14;?></th>
                        <?php $counter1=-1; if( isset($a_arr) && is_array($a_arr) && sizeof($a_arr) ) foreach( $a_arr as $key1 => $value1 ){ $counter1++; ?>

                            <?php $p =explode(' ', $value1);?> <?php $tnum = $p["1"];?>


                            <?php if( ( $tnum <= 0 ) ){ ?>

                                <td class="none">0</td>
                            <?php }else{ ?>

                                 <td><?php echo $tnum;?></td>
                            <?php } ?>


                        <?php } ?>

                    </tr>
                    <tr>
                        <th><?php  echo LANGUI_RPT_T18;?></th>
                        <?php $counter1=-1; if( isset($a_arr) && is_array($a_arr) && sizeof($a_arr) ) foreach( $a_arr as $key1 => $value1 ){ $counter1++; ?>

                            <?php $p =explode(' ', $value1);?>

                            <?php $deadNum = $p["2"];?>


                            <?php if( ( $deadNum <= 0 ) ){ ?>

                                <td class="none">0</td>
                            <?php }else{ ?>

                                <td><?php echo $deadNum;?></td>
                            <?php } ?>

                        <?php } ?>

                    </tr>
                </tbody>
            </table>
        </td>
    </tr>
</tbody>
</table>
<p></p>
<?php } ?>

</body>
</html>