<?php if(!class_exists('raintpl')){exit;}?><!DOCTYPE html>

<html lang="ar">

<head>

    <meta charset="UTF-8">

    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

</head>

<body>
<?php echo load_lang('ui/custbuilds'); ?>

<p></p>
<p></p>
<div id="textmenu">
    <a href="build?id=<?php echo $buildingIndex;?>" class="selected"><?php  echo LANGUI_CUSTBU_RP_p1;?></a> |
    <a href="v2v"><?php  echo LANGUI_CUSTBU_RP_p2;?></a> |
    <a href="warsm"><?php  echo LANGUI_CUSTBU_RP_p3;?></a> |
    <a href="farm"<?php if( !$data["active_plus_account"] ){ ?> onclick="return showManual(5,0);"<?php } ?>><?php  echo LANGUI_CUSTBU_RP_p4;?></a>
</div>
<div id="textmenu">
    <a href="?id=<?php echo $buildingIndex;?>" <?php if( $tap == 0 ){ ?>class="selected"<?php } ?>><?php  echo LANGUI_CUSTBU_RP_t16;?></a> |
    <a href="?id=<?php echo $buildingIndex;?>&t=1" <?php if( $tap == 1 ){ ?>class="selected"<?php } ?>><?php  echo LANGUI_CUSTBU_RP_t1;?></a> |
    <a href="?id=<?php echo $buildingIndex;?>&t=2" <?php if( $tap == 2 ){ ?>class="selected"<?php } ?>><?php  echo LANGUI_CUSTBU_RP_t9;?></a> |
    <a href="?id=<?php echo $buildingIndex;?>&t=3" <?php if( $tap == 3 ){ ?>class="selected"<?php } ?>><?php  echo LANGUI_CUSTBU_RP_t23;?></a>
</div>
<?php if( $war_to_village_size && $tap == 1 ){ ?>

    <h4>
    <?php  echo LANGUI_CUSTBU_RP_t1;?>

    </h4>
    <?php $counter1=-1; if( isset($war_to_village) && is_array($war_to_village) && sizeof($war_to_village) ) foreach( $war_to_village as $key1 => $value1 ){ $counter1++; ?>

        <table class="troop_details" cellpadding="1" cellspacing="1">
            <thead>
                <tr>
                    <td class="role">
                        <?php if( ( $value1['actionRow'] != NULL && $value1['actionRow']['player_id'] == $value1['taskTable']['player_id'] ) ){ ?>

                            <a href="village3?id=<?php echo $value1["taskTable"]["village_id"];?>"><?php echo $value1["action2"];?></a>
                        <?php }else{ ?>

                            <?php echo $value1["action2"];?>

                        <?php } ?>

                    </td>
                    <td colspan="<?php echo $value1["colspan"];?>">
                        <a href="village3?id=<?php echo $value1["taskTable"]["to_village_id"];?>"><p><?php echo $value1["action1"];?></p></a>
                    </td>
                </tr>
            </thead>
            <tbody class="units">
                <tr>
                    <th>&nbsp;</th>
                    <?php $counter2=-1; if( isset($value1["troops"]) && is_array($value1["troops"]) && sizeof($value1["troops"]) ) foreach( $value1["troops"] as $key2 => $value2 ){ $counter2++; ?>

                        <td>
                            <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="unit u<?php echo $key2;?>" title="<?php echo constant('troop_'.$key2 ); ?>" alt="<?php echo constant('troop_'.$key2 ); ?>">
                        </td>
                    <?php } ?>

                    <?php if( ($value1['hasHero'] && $value1['procType'] == QS_WAR_REINFORCE ) ){ ?>

                        <td>
                            <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="unit uhero" title="<?php  echo troop_hero;?>" alt="<?php  echo troop_hero;?>">
                        </td>
                    <?php } ?>

                    </tr>
                    <tr>
                        <th><?php  echo LANGUI_CUSTBU_RP_t6;?></th>
                        <?php $counter2=-1; if( isset($value1["troops"]) && is_array($value1["troops"]) && sizeof($value1["troops"]) ) foreach( $value1["troops"] as $key2 => $value2 ){ $counter2++; ?>

                            <?php if( $value1["procType"] != QS_WAR_REINFORCE && $artPower && $value2 > 0 ){ ?>

                                <td>?</td>
                            <?php }elseif( $value1["procType"] != QS_WAR_REINFORCE ){ ?>

                                <td class="none">?</td>
                            <?php }elseif( ( $value2 == 0 ) ){ ?>

                                <td class="none">0</td>
                            <?php }else{ ?>

                                <td>
                                    <?php echo $value2;?>

                                </td>
                            <?php } ?>

                        <?php } ?>

                        <?php if( ( $value1['hasHero'] && $value1['procType'] == QS_WAR_REINFORCE ) ){ ?>

                            <td>1</td>
                        <?php } ?>

            </tbody>
            <tbody class="infos">
                <tr>
                    <th><?php  echo LANGUI_CUSTBU_RP_t7;?></th>
                    <td colspan="<?php echo $value1["colspan"];?>">
                        <div class="in small">
                        <?php  echo text_in_lang;?>

                        <span id="timer1">
                            <?php echo secondstostring( $value1["taskTable"]["remainingSeconds"] );?>

                        </span>
                        <?php  echo time_hour_lang;?>

                        </div>
                    </td>
                </tr>
            </tbody>
            <?php if( ( $value1['resources'] != NULL ) ){ ?>

            <tbody class="infos">
                <tr>
                    <th><?php  echo LANGUI_CUSTBU_RP_t8;?></th>
                    <td colspan="<?php echo $value1["colspan"];?>">
                        <img class="r1" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo item_title_1;?>" title="<?php  echo item_title_1;?>">
                        <?php echo $value1["resources"]["0"];?>

                       |<img class="r2" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo item_title_2;?>" title="<?php  echo item_title_2;?>">
                        <?php echo $value1["resources"]["1"];?>

                       |<img class="r3" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo item_title_3;?>" title="<?php  echo item_title_3;?>">
                        <?php echo $value1["resources"]["2"];?>

                       |<img class="r4" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo item_title_4;?>" title="<?php  echo item_title_4;?>">
                        <?php echo $value1["resources"]["3"];?>

                    </td>
                </tr>
            </tbody>
            <?php } ?>

        </table>
    <?php } ?>

<?php } ?>



<?php if( $war_from_village_size && $tap == 2 ){ ?>

    <h4>
    <?php  echo LANGUI_CUSTBU_RP_t9;?>

    </h4>
    <?php $counter1=-1; if( isset($war_from_village) && is_array($war_from_village) && sizeof($war_from_village) ) foreach( $war_from_village as $key1 => $value1 ){ $counter1++; ?>

        <table class="troop_details" cellpadding="1" cellspacing="1">
            <thead>
                <tr>
                    <td class="role">
                        <a href="village3?id=<?php echo $data["selected_village_id"];?>"><?php echo $data["village_name"];?></a>
                    </td>
                    <td colspan="<?php echo $value1["colspan"];?>">
                        <a href="village3?id=<?php echo $value1["taskTable"]["to_village_id"];?>">
                            <p><?php echo $value1["action"];?></p>
                        </a>
                    </td>
                </tr>
            </thead>
            <tbody class="units">
                <tr>
                    <th>&nbsp;</th>
                    <?php $counter2=-1; if( isset($value1["troops"]) && is_array($value1["troops"]) && sizeof($value1["troops"]) ) foreach( $value1["troops"] as $key2 => $value2 ){ $counter2++; ?>

                        <td>
                            <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="unit u<?php echo $key2;?>" title="<?php echo constant('troop_'.$key2 ); ?>" alt="<?php echo constant('troop_'.$key2 ); ?>" >
                    </td>
                    <?php } ?>

                    <?php if( ( $value1['hasHero'] ) ){ ?>

                        <td>
                            <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="unit uhero" title="<?php  echo troop_hero;?>" alt="<?php  echo troop_hero;?>"></td>
                    <?php } ?>

                </tr>
                <tr>
                    <th><?php  echo LANGUI_CUSTBU_RP_t6;?></th>
                    <?php $counter2=-1; if( isset($value1["troops"]) && is_array($value1["troops"]) && sizeof($value1["troops"]) ) foreach( $value1["troops"] as $key2 => $value2 ){ $counter2++; ?>

                        <?php if( ( $value2 == 0 ) ){ ?>

                            <td class="none">0</td>
                        <?php }else{ ?>

                            <td>
                                <?php echo $value2;?>

                            </td>
                        <?php } ?>

                    <?php } ?>

                    <?php if( ( $value1['hasHero']) ){ ?>

                        <td>1</td>
                    <?php } ?>

                </tr>
            </tbody>
            <tbody class="infos">
                <tr>
                    <th><?php  echo LANGUI_CUSTBU_RP_t7;?></th>
                    <td colspan="<?php echo $value1["colspan"];?>">
                        <div class="in small">
                            <?php  echo text_in_lang;?>

                            <span id="timer1">
                                <?php echo secondstostring( $value1["remainingSeconds"] );?>

                            </span>
                            <?php  echo time_hour_lang;?>

                        </div>
                        <?php if( $value1["canCancelWarTask"] ){ ?>

                            <div class="abort">
                                <a href="build?id=39&d=<?php echo $value1["taskTable"]["id"];?>">
                                    <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="del" title="<?php  echo LANGUI_CUSTBU_RP_t27;?>" alt="<?php  echo LANGUI_CUSTBU_RP_t27;?>">
                                </a>
                            </div>
                        <?php } ?>

                        </td>
                    </tr>
                </tbody>
                <?php if( ( $value1['resources'] != NULL ) ){ ?>

                <tbody class="infos">
                    <tr>
                        <th><?php  echo LANGUI_CUSTBU_RP_t15;?></th>
                        <td colspan="<?php echo $value1["colspan"];?>">
                            <img class="r1" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo item_title_1;?>" title="<?php  echo item_title_1;?>">
                            <?php echo $value1["resources"]["0"];?>

                           |<img class="r2" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo item_title_2;?>" title="<?php  echo item_title_2;?>">
                            <?php echo $value1["resources"]["1"];?>

                           |<img class="r3" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo item_title_3;?>" title="<?php  echo item_title_3;?>">
                            <?php echo $value1["resources"]["2"];?>

                           |<img class="r4" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo item_title_4;?>" title="<?php  echo item_title_4;?>">
                            <?php echo $value1["resources"]["3"];?>

                        </td>
                    </tr>
                </tbody>
                <?php } ?>

        </table>
    <?php } ?>

<?php } ?>


<?php if( $troops_in_village_size && $tap == 0 ){ ?>

    <h4>
    <?php  echo LANGUI_CUSTBU_RP_t16;?>

    </h4>
    <?php $counter1=-1; if( isset($troops_in_village) && is_array($troops_in_village) && sizeof($troops_in_village) ) foreach( $troops_in_village as $key1 => $value1 ){ $counter1++; ?>

        <table class="troop_details" cellpadding="1" cellspacing="1">
            <thead>
                <tr>
                    <td class="role">
                        <?php if( ( 0 < intval( $value1['troopTable']['villageData']['player_id'] ) ) ){ ?>

                            <a href="village3?id=<?php echo $value1["troopTable"]["villageData"]["id"];?>"><?php echo $value1["troopTable"]["villageData"]["village_name"];?></a>
                        <?php }else{ ?>

                            <span class="none">[?]</span>
                        <?php } ?>

                    </td>
                    <td colspan="<?php echo $value1["colspan"];?>">
                    <?php if( ( 0 < intval( $value1['troopTable']['villageData']['player_id'] ) ) ){ ?>

                        <a href="profile?uid=<?php echo $value1["troopTable"]["villageData"]["player_id"];?>"><?php  echo LANGUI_CUSTBU_RP_t17;?> <?php echo $value1["troopTable"]["villageData"]["player_name"];?></a>
                        <?php }else{ ?>

                            <span class="none">[?]</span>
                        <?php } ?>

                    </td>
                </tr>
            </thead>
            <tbody class="units">
                <tr>
                    <th>&nbsp;</th>
                        <?php $counter2=-1; if( isset($value1["troopTable"]["troops"]) && is_array($value1["troopTable"]["troops"]) && sizeof($value1["troopTable"]["troops"]) ) foreach( $value1["troopTable"]["troops"] as $key2 => $value2 ){ $counter2++; ?>

                            <?php if( ( $key2 == 31 ) ){ ?>

                                <?php $value1["canBack"] = FALSE;?>

                            <?php } ?>

                            <td>
                                <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="unit u<?php echo $key2;?>" title="<?php echo constant('troop_'.$key2 ); ?>" alt="<?php echo constant('troop_'.$key2 ); ?>">
                            </td>
                        <?php } ?>

                        <?php if( ( $value1['troopTable']['hasHero'] ) ){ ?>

                            <td>
                                <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="unit uhero" title="<?php  echo troop_hero;?>" alt="<?php  echo troop_hero;?>">
                            </td>
                        <?php } ?>

                        </tr>
                        <tr>
                            <th><?php  echo LANGUI_CUSTBU_RP_t6;?></th>
                            <?php $counter2=-1; if( isset($value1["troopTable"]["troops"]) && is_array($value1["troopTable"]["troops"]) && sizeof($value1["troopTable"]["troops"]) ) foreach( $value1["troopTable"]["troops"] as $key2 => $value2 ){ $counter2++; ?>

                                <?php if( ( $value2 == 0 ) ){ ?>

                                    <td class="none">0</td>
                                <?php }else{ ?>

                                    <td>
                                        <?php echo $value2;?>

                                    </td>
                                <?php } ?>

                            <?php } ?>

                        <?php if( ( $value1['troopTable']['hasHero'] ) ){ ?>

                            <td>1</td>
                        <?php } ?>

                        </tr>
                    </tbody>
                    <tbody class="infos">
                        <tr>
                            <th><?php  echo LANGUI_CUSTBU_RP_t18;?></th>
                            <td colspan="<?php echo $value1["colspan"];?>">
                                <div class="sup">
                                    <?php echo $value1["troopTable"]["cropConsumption"];?>

                                    <img class="r4" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" title="<?php  echo item_title_4;?>" alt="<?php  echo item_title_4;?>">
                                    <?php  echo LANGUI_CUSTBU_RP_t19;?>

                                </div>
                                <?php if( ($value1['troopTable']['villageData']['id'] != $data['selected_village_id'] && $value1['canBack'] ) ){ ?>

                                    <div class="gback">
                                        <a href="v2v?d1=<?php echo $value1["troopTable"]["villageData"]["id"];?>">
                                            <?php  echo LANGUI_CUSTBU_RP_t20;?>

                                        </a>
                                    </div>
                                <?php } ?>

                        </td>
                    </tr>
                </tbody>
        </table>
    <?php } ?>


    <?php $counter1=-1; if( isset($troops_in_village_in_table) && is_array($troops_in_village_in_table) && sizeof($troops_in_village_in_table) ) foreach( $troops_in_village_in_table as $key1 => $value1 ){ $counter1++; ?>

        <table class="troop_details" cellpadding="1" cellspacing="1">
            <thead>
                <tr>
                    <td class="role">
                        <?php if( ( 0 < intval( $value1['troopTable']['villageData']['player_id'] ) ) ){ ?>

                            <a href="village3?id=<?php echo $value1["troopTable"]["villageData"]["id"];?>"><?php echo $value1["troopTable"]["villageData"]["village_name"];?></a>
                        <?php }else{ ?>

                            <span class="none">[?]</span>
                        <?php } ?>

                    </td>
                    <td colspan="<?php echo $value1["colspan"];?>">
                        <a href="profile?uid=<?php echo $value1["troopTable"]["villageData"]["player_id"];?>">
                        <?php  echo LANGUI_CUSTBU_RP_t17;?>

                        <?php if( ( 0 < intval( $value1['troopTable']['villageData']['player_id'] ) ) ){ ?>

                            <?php echo $value1["troopTable"]["villageData"]["player_name"];?>

                        <?php }else{ ?>

                            <span class="none">[?]</span>
                        <?php } ?>

                        </a>
                    </td>
                </tr>
            </thead>
            <tbody class="units">
                <tr>
                    <th>&nbsp;</th>
                        <?php $counter2=-1; if( isset($value1["troopTable"]["troops"]) && is_array($value1["troopTable"]["troops"]) && sizeof($value1["troopTable"]["troops"]) ) foreach( $value1["troopTable"]["troops"] as $key2 => $value2 ){ $counter2++; ?>

                            <td>
                                <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="unit u<?php echo $key1;?>" title="<?php echo constant('troop_'.$key1 ); ?>" alt="<?php echo constant('troop_'.$key1 ); ?>">
                            </td>
                        <?php } ?>

                        <?php if( ( $value1['troopTable']['hasHero'] ) ){ ?>

                            <td>
                                <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="unit uhero" title="<?php  echo troop_hero;?>" alt="<?php  echo troop_hero;?>">
                            </td>
                        <?php } ?>

                        </tr>
                        <tr>
                            <th><?php  echo LANGUI_CUSTBU_RP_t6;?></th>
                            <?php $counter2=-1; if( isset($value1["troopTable"]["troops"]) && is_array($value1["troopTable"]["troops"]) && sizeof($value1["troopTable"]["troops"]) ) foreach( $value1["troopTable"]["troops"] as $key2 => $value2 ){ $counter2++; ?>

                                <?php if( ( $value2 == 0 ) ){ ?>

                                    <td class="none">0</td>
                                <?php }else{ ?>

                                    <td>
                                        <?php echo $value2;?>

                                    </td>
                                <?php } ?>

                            <?php } ?>

                        <?php if( ( $value1['troopTable']['hasHero'] ) ){ ?>

                            <td>1</td>
                        <?php } ?>

                        </tr>
                    </tbody>
                    <tbody class="infos">
                        <tr>
                            <th><?php  echo LANGUI_CUSTBU_RP_t18;?></th>
                        <td colspan="<?php echo $value1["colspan"];?>">
                            <div class="sup">
                                <?php echo $value1["troopTable"]["cropConsumption"];?>

                                <img class="r4" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" title="<?php  echo item_title_4;?>" alt="<?php  echo item_title_4;?>">
                                <?php  echo LANGUI_CUSTBU_RP_t19;?>

                            </div>
                                <div class="gback">
                                    <a href="v2v?d2=<?php echo $value1["troopTable"]["villageData"]["id"];?>">
                                        <?php  echo LANGUI_CUSTBU_RP_t22;?>

                                    </a>
                                </div>
                        </td>
                    </tr>
                </tbody>
        </table>
    <?php } ?>

<?php } ?>


<?php if( $troops_out_village_size && $tap == 3 ){ ?>

    <h4>
    <?php  echo LANGUI_CUSTBU_RP_t23;?>

    </h4>
    <?php $counter1=-1; if( isset($troops_out_village) && is_array($troops_out_village) && sizeof($troops_out_village) ) foreach( $troops_out_village as $key1 => $value1 ){ $counter1++; ?>

        <table class="troop_details" cellpadding="1" cellspacing="1">
            <thead>
                <tr>
                    <td class="role">
                        <?php if( ( 0 < intval( $value1['troopTable']['villageData']['player_id'] ) ) ){ ?>

                            <a href="village3?id=<?php echo $value1["troopTable"]["villageData"]["id"];?>"><?php echo $value1["troopTable"]["villageData"]["village_name"];?></a>
                        <?php }else{ ?>

                            <span class="none">[?]</span>
                        <?php } ?>

                    </td>
                    <td colspan="<?php echo $value1["colspan"];?>">
                        <a href="profile?uid=<?php echo $value1["troopTable"]["villageData"]["player_id"];?>">
                        <?php  echo LANGUI_CUSTBU_RP_t10;?>


                        <?php if( ( 0 < intval( $value1['troopTable']['villageData']['player_id'] ) ) ){ ?>

                            <?php echo $value1["troopTable"]["villageData"]["player_name"];?>

                        <?php }else{ ?>

                            <span class="none">[?]</span>
                        <?php } ?>

                        </a>
                    </td>
                </tr>
            </thead>
            <tbody class="units">
                <tr>
                    <th>&nbsp;</th>
                        <?php $counter2=-1; if( isset($value1["troopTable"]["troops"]) && is_array($value1["troopTable"]["troops"]) && sizeof($value1["troopTable"]["troops"]) ) foreach( $value1["troopTable"]["troops"] as $key2 => $value2 ){ $counter2++; ?>

                            <td>
                                <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="unit u<?php echo $key2;?>" title="<?php echo constant('troop_'.$key2 ); ?>" alt="<?php echo constant('troop_'.$key2 ); ?>">
                            </td>
                        <?php } ?>

                        <?php if( ( $value1['troopTable']['hasHero'] ) ){ ?>

                            <td>
                                <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="unit uhero" title="<?php  echo troop_hero;?>" alt="<?php  echo troop_hero;?>">
                            </td>
                        <?php } ?>

                        </tr>
                        <tr>
                            <th><?php  echo LANGUI_CUSTBU_RP_t6;?></th>
                            <?php $counter2=-1; if( isset($value1["troopTable"]["troops"]) && is_array($value1["troopTable"]["troops"]) && sizeof($value1["troopTable"]["troops"]) ) foreach( $value1["troopTable"]["troops"] as $key2 => $value2 ){ $counter2++; ?>

                                <?php if( ( $value2 == 0 ) ){ ?>

                                    <td class="none">0</td>
                                <?php }else{ ?>

                                    <td>
                                        <?php echo $value2;?>

                                    </td>
                                <?php } ?>

                            <?php } ?>

                        <?php if( ( $value1['troopTable']['hasHero'] ) ){ ?>

                            <td>1</td>
                        <?php } ?>

                        </tr>
                    </tbody>
                    <tbody class="infos">
                        <tr>
                            <th><?php  echo LANGUI_CUSTBU_RP_t18;?></th>
                            <td colspan="<?php echo $value1["colspan"];?>">
                                <div class="sup">
                                    <?php echo $value1["troopTable"]["cropConsumption"];?>

                                    <img class="r4" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" title="<?php  echo item_title_4;?>" alt="<?php  echo item_title_4;?>">
                                    <?php  echo LANGUI_CUSTBU_RP_t19;?>

                                </div>
                                <div class="gback">
                                    <a href="v2v?d3=<?php echo $value1["troopTable"]["villageData"]["id"];?>">
                                        <?php  echo LANGUI_CUSTBU_RP_t24;?>

                                    </a>
                                </div>
                        </td>
                    </tr>
                </tbody>
            </table>
    <?php } ?>


    <?php $counter1=-1; if( isset($troops_out_village_in_table) && is_array($troops_out_village_in_table) && sizeof($troops_out_village_in_table) ) foreach( $troops_out_village_in_table as $key1 => $value1 ){ $counter1++; ?>

        <table class="troop_details" cellpadding="1" cellspacing="1">
            <thead>
                <tr>
                    <td class="role">
                        <?php if( ( 0 < intval( $value1['troopTable']['villageData']['player_id'] ) ) ){ ?>

                            <a href="village3?id=<?php echo $value1["troopTable"]["villageData"]["id"];?>"><?php echo $value1["troopTable"]["villageData"]["village_name"];?></a>
                        <?php }else{ ?>

                            <span class="none">[?]</span>
                        <?php } ?>

                    </td>
                    <td colspan="<?php echo $value1["colspan"];?>">
                        <a href="profile?uid=<?php echo $value1["troopTable"]["villageData"]["player_id"];?>">
                        <?php  echo LANGUI_CUSTBU_RP_t25;?>

                        <?php if( ( 0 < intval( $value1['troopTable']['villageData']['player_id'] ) ) ){ ?>

                            <?php echo $value1["troopTable"]["villageData"]["player_name"];?>

                        <?php }else{ ?>

                            <span class="none">[?]</span>
                        <?php } ?>

                        </a>
                    </td>
                </tr>
            </thead>
            <tbody class="units">
                <tr>
                    <th>&nbsp;</th>
                        <?php $counter2=-1; if( isset($value1["troopTable"]["troops"]) && is_array($value1["troopTable"]["troops"]) && sizeof($value1["troopTable"]["troops"]) ) foreach( $value1["troopTable"]["troops"] as $key2 => $value2 ){ $counter2++; ?>

                            <td>
                                <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="unit u<?php echo $key1;?>" title="<?php echo constant('troop_'.$key1 ); ?>" alt="<?php echo constant('troop_'.$key1 ); ?>">
                            </td>
                        <?php } ?>

                        <?php if( ( $value1['troopTable']['hasHero'] ) ){ ?>

                            <td>
                                <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="unit uhero" title="<?php  echo troop_hero;?>" alt="<?php  echo troop_hero;?>">
                            </td>
                        <?php } ?>

                        </tr>
                        <tr>
                            <th><?php  echo LANGUI_CUSTBU_RP_t6;?></th>
                            <?php $counter2=-1; if( isset($value1["troopTable"]["troops"]) && is_array($value1["troopTable"]["troops"]) && sizeof($value1["troopTable"]["troops"]) ) foreach( $value1["troopTable"]["troops"] as $key2 => $value2 ){ $counter2++; ?>

                                <?php if( ( $value2 == 0 ) ){ ?>

                                    <td class="none">0</td>
                                <?php }else{ ?>

                                    <td>
                                        <?php echo $value2;?>

                                    </td>
                                <?php } ?>

                            <?php } ?>

                        <?php if( ( $value1['troopTable']['hasHero'] ) ){ ?>

                            <td>1</td>
                        <?php } ?>

                        </tr>
                    </tbody>
                    <tbody class="infos">
                        <tr>
                        <th><?php  echo LANGUI_CUSTBU_RP_t18;?></th>
                        <td colspan="<?php echo $value1["colspan"];?>">
                            <div class="sup">
                                <?php echo $value1["troopTable"]["cropConsumption"];?>

                                <img class="r4" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" title="<?php  echo item_title_4;?>" alt="<?php  echo item_title_4;?>">
                                <?php  echo LANGUI_CUSTBU_RP_t19;?>

                            </div>
                        </td>
                    </tr>
                </tbody>
        </table>
    <?php } ?>

<?php } ?>



<?php if( $troops_in_oases_size && $tap == 0 ){ ?>

    <?php $counter1=-1; if( isset($troops_in_oases) && is_array($troops_in_oases) && sizeof($troops_in_oases) ) foreach( $troops_in_oases as $key1 => $value1 ){ $counter1++; ?>

        <br />
        <p class="info">
            <a href="village3?id=<?php echo $key1;?>"> <?php  echo LANGUI_CUSTBU_RP_t26;?>

                ( <?php echo $value1["oasisData"]["oasisRow"]["rel_x"];?>|<?php echo $value1["oasisData"]["oasisRow"]["rel_y"];?> )
            </a>
        </p>
        <?php if( ( 0 < sizeof( $value1['oasisData']['war_to'] ) ) ){ ?>

            <h4><?php  echo LANGUI_CUSTBU_RP_t1;?></h4>
            <?php $counter2=-1; if( isset($value1['war_to_oasis_data']) && is_array($value1['war_to_oasis_data']) && sizeof($value1['war_to_oasis_data']) ) foreach( $value1['war_to_oasis_data'] as $key2 => $value2 ){ $counter2++; ?>

                <table class="troop_details" cellpadding="1" cellspacing="1">
                    <thead>
                        <tr>
                            <td class="role">
                                <?php if( ( $value2["action2"] != '' ) ){ ?>

                                    <a href="village3?id=<?php echo $value2["taskTable"]["village_id"];?>">
                                        <?php echo $value2["action2"];?>

                                    </a>
                                <?php }else{ ?>

                                    <?php echo $value2["action2"];?>

                                <?php } ?>

                            </td>
                            <td colspan="<?php echo $value2["colspan"];?>">
                                <a href="village3?id=<?php echo $value2["taskTable"]["to_village_id"];?>"><p><?php echo $value2["action1"];?></p></a>
                            </td>
                        </tr>
                    </thead>
                    <tbody class="units">
                        <tr>
                            <th>&nbsp;</th>
                            <?php $counter3=-1; if( isset($value2["troops"]) && is_array($value2["troops"]) && sizeof($value2["troops"]) ) foreach( $value2["troops"] as $key3 => $value3 ){ $counter3++; ?>

                                <td>
                                    <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="unit u<?php echo $key3;?>" title="<?php echo constant('troop_'.$key3 ); ?>" alt="<?php echo constant('troop_'.$key3 ); ?>">
                                </td>
                            <?php } ?>


                            <?php if( ( $value2['hasHero'] && $value2['procType'] == QS_WAR_REINFORCE ) ){ ?>

                                <td>
                                    <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="unit uhero" title="<?php  echo troop_hero;?>" alt="<?php  echo troop_hero;?>">
                                </td>
                            <?php } ?>

                            </tr>
                            <tr>
                                <th><?php  echo LANGUI_CUSTBU_RP_t6;?></th>
                                <?php $prty = $value2['procType'];?>

                                <?php $counter3=-1; if( isset($value2["troops"]) && is_array($value2["troops"]) && sizeof($value2["troops"]) ) foreach( $value2["troops"] as $key3 => $value3 ){ $counter3++; ?>

                                    <?php if( $prty != QS_WAR_REINFORCE && $artPower && $value3 > 0 ){ ?>

                                        <td>?</td>
                                    <?php }elseif( $value2["procType"] != QS_WAR_REINFORCE ){ ?>

                                        <td class="none">?</td>
                                    <?php }elseif( ( $value3 == 0 ) ){ ?>

                                        <td class="none">0</td>
                                    <?php }else{ ?>

                                        <td><?php echo $value3;?></td>
                                    <?php } ?>

                                <?php } ?>


                                <?php if( ( $value2['hasHero'] && $value2['procType'] == QS_WAR_REINFORCE ) ){ ?>

                                    <td>1</td>
                                <?php } ?>

                                </tr>
                            </tbody>
                            <tbody class="infos">
                                <tr>
                                    <th><?php  echo LANGUI_CUSTBU_RP_t7;?></th>
                                    <td colspan="<?php echo $value2["colspan"];?>">
                                        <div class="in small">
                                            <?php  echo text_in_lang;?>

                                            <span id="timer1">
                                            <?php echo secondstostring( $value2["taskTable"]["remainingSeconds"] );?>

                                            </span>
                                            <?php  echo time_hour_lang;?>

                                        </div>
                                    </td>
                                </tr>
                            </tbody>
                </table>
            <?php } ?>

        <?php } ?>


        <?php if( ( 0 < sizeof( $value1['oasisData']['troopsTable']) ) ){ ?>

            <h4><?php  echo LANGUI_CUSTBU_RP_t16;?></h4>
            <?php $counter2=-1; if( isset($value1["troopsTable"]) && is_array($value1["troopsTable"]) && sizeof($value1["troopsTable"]) ) foreach( $value1["troopsTable"] as $key2 => $value2 ){ $counter2++; ?>

                <table class="troop_details" cellpadding="1" cellspacing="1">
                    <thead>
                        <tr>
                            <td class="role">
                                <?php if( ( 0 < intval( $value2['troopTable']['villageData']['player_id'] ) ) ){ ?>

                                    <a href="village3?id=<?php echo $value2["troopTable"]["villageData"]["id"];?>"><?php echo $value2["troopTable"]["villageData"]["village_name"];?></a>
                                <?php }else{ ?>

                                    <span class="none">[?]</span>
                                <?php } ?>

                            </td>
                            <td colspan="<?php echo $value2["colspan"];?>">
                                <a href="profile?uid=<?php echo $value2["troopTable"]["villageData"]["player_id"];?>">
                                <?php  echo LANGUI_CUSTBU_RP_t17;?>


                                <?php if( ( 0 < intval( $value2['troopTable']['villageData']['player_id'] ) ) ){ ?>

                                    <?php echo $value2["troopTable"]["villageData"]["player_name"];?>

                                <?php }else{ ?>

                                    <span class="none">[?]</span>
                                <?php } ?>

                                </a>
                            </td>
                        </tr>
                    </thead>
                    <tbody class="units">
                        <tr>
                            <th>&nbsp;</th>
                                <?php $counter3=-1; if( isset($value2["troopTable"]["troops"]) && is_array($value2["troopTable"]["troops"]) && sizeof($value2["troopTable"]["troops"]) ) foreach( $value2["troopTable"]["troops"] as $key3 => $value3 ){ $counter3++; ?>

                                    <td>
                                        <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="unit u<?php echo $key3;?>" title="<?php echo constant('troop_'.$key3 ); ?>" alt="<?php echo constant('troop_'.$key3 ); ?>">
                                    </td>
                                <?php } ?>

                                <?php if( ( $value2['troopTable']['hasHero'] ) ){ ?>

                                    <td>
                                        <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="unit uhero" title="<?php  echo troop_hero;?>" alt="<?php  echo troop_hero;?>">
                                    </td>
                                <?php } ?>

                                </tr>
                                <tr>
                                    <th><?php  echo LANGUI_CUSTBU_RP_t6;?></th>
                                    <?php $counter3=-1; if( isset($value2["troopTable"]["troops"]) && is_array($value2["troopTable"]["troops"]) && sizeof($value2["troopTable"]["troops"]) ) foreach( $value2["troopTable"]["troops"] as $key3 => $value3 ){ $counter3++; ?>

                                        <?php if( ( $value3 == 0 ) ){ ?>

                                            <td class="none">0</td>
                                        <?php }else{ ?>

                                            <td>
                                                <?php echo $value3;?>

                                            </td>
                                        <?php } ?>

                                    <?php } ?>

                                <?php if( ( $value2['troopTable']['hasHero'] ) ){ ?>

                                    <td>1</td>
                                <?php } ?>

                                </tr>
                            </tbody>
                            <tbody class="infos">
                                <tr>
                                    <th><?php  echo LANGUI_CUSTBU_RP_t18;?></th>
                                    <td colspan="<?php echo $value2["colspan"];?>">
                                        <div class="sup">
                                            <?php echo $value2["troopTable"]["cropConsumption"];?>

                                            <img class="r4" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" title="<?php  echo item_title_4;?>" alt="<?php  echo item_title_4;?>">
                                            <?php  echo LANGUI_CUSTBU_RP_t19;?>

                                        </div>
                                        <div class="gback">
                                            <a href="v2v?d1=<?php echo $value2["troopTable"]["villageData"]["id"];?>&o=<?php echo $key1;?>">
                                                <?php  echo LANGUI_CUSTBU_RP_t20;?>

                                            </a>
                                        </div>
                                </td>
                            </tr>
                        </tbody>
                </table>
            <?php } ?>

        <?php } ?>

    <?php } ?>

<?php } ?>

</body>
</html>