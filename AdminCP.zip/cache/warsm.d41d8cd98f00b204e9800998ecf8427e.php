<?php if(!class_exists('raintpl')){exit;}?><!DOCTYPE html>

<html lang="ar">

<head>

    <meta charset="UTF-8">

    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

</head>

<body>
<?php echo load_lang('ui/warsm'); ?>

  <h1><?php  echo LANGUI_WARSN_T1;?></h1>
  <form action="warsm" method="post">
  <?php if( ($showWarResult) ){ ?>

      <table class="results attacker" cellpadding="1" cellspacing="1">
        <thead>
          <tr>
            <td class="role"><?php  echo LANGUI_WARSN_T2;?></td>
            <?php $counter1=-1; if( isset($warResult['attackTroops']['troops']) && is_array($warResult['attackTroops']['troops']) && sizeof($warResult['attackTroops']['troops']) ) foreach( $warResult['attackTroops']['troops'] as $key1 => $value1 ){ $counter1++; ?>

              <td>
                <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="unit u<?php echo $key1;?>" title="<?php echo constant('troop_' . $key1); ?>" alt="<?php echo constant('troop_' . $key1); ?>">
              </td>
            <?php } ?>

          </tr>
        </thead>
        <tbody>
          <tr>
            <th><?php  echo LANGUI_WARSN_T3;?></th>
            <?php $counter1=-1; if( isset($warResult['attackTroops']['troops']) && is_array($warResult['attackTroops']['troops']) && sizeof($warResult['attackTroops']['troops']) ) foreach( $warResult['attackTroops']['troops'] as $key1 => $value1 ){ $counter1++; ?>

                <?php $num = $value1['number'];?>

                <?php if( ($num <= 0) ){ ?>

                    <td class="none">0</td>
                <?php }else{ ?>

                    <td>
                        <?php echo $num;?>

                    </td>
                <?php } ?>

            <?php } ?>

          </tr>
          <tr>
            <th><?php  echo LANGUI_WARSN_T4;?></th>
            <?php $counter1=-1; if( isset($warResult['attackTroops']['troops']) && is_array($warResult['attackTroops']['troops']) && sizeof($warResult['attackTroops']['troops']) ) foreach( $warResult['attackTroops']['troops'] as $key1 => $value1 ){ $counter1++; ?>

              <?php $num = $value1['number'] - $value1['live_number'];?>


                <?php if( ($num <= 0) ){ ?>

                    <td class="none">0</td>
                <?php }else{ ?>

                    <td>
                    <?php echo $num;?>

                    </td>
                <?php } ?>

            <?php } ?>

          </tr>
        </tbody>
      </table>

      <?php $counter1=-1; if( isset($warResult['defenseTroops']) && is_array($warResult['defenseTroops']) && sizeof($warResult['defenseTroops']) ) foreach( $warResult['defenseTroops'] as $key1 => $value1 ){ $counter1++; ?>

          <table class="results defender" cellpadding="1" cellspacing="1">
            <thead>
              <tr>
                <td class="role"><?php  echo LANGUI_WARSN_T5;?></td>
                <?php $counter2=-1; if( isset($value1['troops']) && is_array($value1['troops']) && sizeof($value1['troops']) ) foreach( $value1['troops'] as $key2 => $value2 ){ $counter2++; ?>

                <td>
                  <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="unit u<?php echo $key2;?>" title="<?php echo constant('troop_' . $key2); ?>" alt="<?php echo constant('troop_' . $key2); ?>">
                </td>
              <?php } ?>

              </tr>
            </thead>
            <tbody>
              <tr>
                <th><?php  echo LANGUI_WARSN_T3;?></th>
                <?php $counter2=-1; if( isset($value1['troops']) && is_array($value1['troops']) && sizeof($value1['troops']) ) foreach( $value1['troops'] as $key2 => $value2 ){ $counter2++; ?>

                    <?php $num = $value2['number'];?>

                    <?php if( ($num <= 0) ){ ?>

                        <td class="none">0</td>
                    <?php }else{ ?>

                        <td>
                            <?php echo $num;?>

                        </td>
                    <?php } ?>

                <?php } ?>

                </tr>
                <tr>
                  <th><?php  echo LANGUI_WARSN_T4;?></th>
                  <?php $counter2=-1; if( isset($value1['troops']) && is_array($value1['troops']) && sizeof($value1['troops']) ) foreach( $value1['troops'] as $key2 => $value2 ){ $counter2++; ?>

                    <?php $num = $value2['number'] - $value2['live_number'];?>

                      <?php if( ($num <= 0) ){ ?>

                          <td class="none">0</td>
                      <?php }else{ ?>

                          <td>
                          <?php echo $num;?>

                          </td>
                      <?php } ?>

                  <?php } ?>

                </tr>
              </tbody>
            </table>
      <?php } ?>

  <?php } ?>



  <?php if( ($showTroopsTable) ){ ?>

      <p> <?php  echo LANGUI_WARSN_T6;?>: <b>

      <?php if( intval($_POST['ktyp']) == 1 ){ ?><?php  echo LANGUI_WARSN_T7;?><?php }else{ ?><?php  echo LANGUI_WARSN_T8;?><?php } ?>

      </b></p>
      <table id="attacker" class="fill_in" cellpadding="1" cellspacing="1">
        <thead>
          <tr>
            <th><?php  echo LANGUI_WARSN_T2;?></th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <th><?php echo constant('tribe_'.$_POST['a1']); ?></th>
          </tr>
          <tr>
            <td class="details">
              <table cellpadding="1" cellspacing="1">
                <tbody>
                  <?php $tribeId = intval($_POST['a1']);?>

                  <?php $counter1=-1; if( isset($troops) && is_array($troops) && sizeof($troops) ) foreach( $troops as $key1 => $value1 ){ $counter1++; ?>

                    <tr>
                        <td class="ico">
                          <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="unit u<?php echo $key1;?>" title="<?php echo constant('troop_' . $key1); ?>" alt="<?php echo constant('troop_' . $key1); ?>">
                        </td>
                        <td class="desc">
                          <?php echo constant('troop_' . $key1); ?>

                        </td>
                        <td class="value">
                          <input class="text" type="text" name="t1[<?php echo $tribeId;?>][<?php echo $key1;?>]" value="<?php if( (isset($_POST['t1'], $_POST['t1'][$tribeId]) && isset($_POST['t1'][$tribeId][$key1]) && 0 < intval($_POST['t1'][$tribeId][$key1])) ){ ?><?php echo intval($_POST['t1'][$tribeId][$key1]); ?><?php } ?>" maxlength="10" title="<?php  echo LANGUI_WARSN_T9;?><?php echo constant('troop_' . $key1); ?>">
                        </td>
                        <td class="research">
                          <?php if( ($tribeId != 4 && $counter1 <= 7) ){ ?>

                              <input class="text" type="text" name="f1[<?php echo $tribeId;?>][<?php echo $key1;?>]" value="<?php if( (isset($_POST['f1'], $_POST['f1'][$tribeId]) && isset($_POST['f1'][$tribeId][$key1]) && 0 < intval($_POST['f1'][$tribeId][$key1])) ){ ?><?php echo intval($_POST['f1'][$tribeId][$key1]); ?><?php } ?>" maxlength="2" title="<?php  echo LANGUI_WARSN_T10;?><?php echo constant('troop_' . $key1); ?>">
                          <?php } ?>

                          </td>
                    </tr>
                  <?php } ?>

              </tbody>
            </table>
          </td>
        </tr>
      </tbody>
      <tbody>
        <tr>
          <th><?php  echo LANGUI_WARSN_T11;?></th>
        </tr>
        <tr>
          <td class="details">
            <table cellpadding="1" cellspacing="1">
              <tbody>
                <tr>
                  <td class="ico">
                    <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="unit uhab" alt="<?php  echo LANGUI_WARSN_T12;?>" title="<?php  echo LANGUI_WARSN_T12;?>">
                  </td>
                  <td class="desc"><?php  echo LANGUI_WARSN_T12;?></td>
                  <td class="value"><input class="text" type="text" name="ew1" value="<?php if( (isset($_POST['ew1']) && 0 < intval($_POST['ew1'])) ){ ?><?php echo intval($_POST['ew1']); ?><?php } ?>" maxlength="5" title="<?php  echo LANGUI_WARSN_T13;?>">
                  </td>
                  <td class="research"></td>
                </tr>
                <tr>
                  <td class="ico">
                    <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="unit uhero" title="<?php  echo troop_hero;?>" alt="<?php  echo troop_hero;?>">
                  </td>
                  <td class="desc"><?php  echo troop_hero;?> ( <?php  echo level_lang2;?> <?php  echo troop_hero;?>)</td>
                  <td class="value">
                    <input class="text" type="text" name="h_off_bonus1" value="<?php if( (isset($_POST['h_off_bonus1']) && 0 < intval($_POST['h_off_bonus1'])) ){ ?><?php echo intval($_POST['h_off_bonus1']); ?><?php } ?>" maxlength="4" title="<?php  echo troop_hero;?>( <?php  echo level_lang2;?> <?php  echo troop_hero;?>)">
                  </td>
                  <td class="research"></td>
                </tr>

                <?php if( $for_tribe_id_exists ){ ?>

                    <tr>
                      <td class="ico">
                        <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="unit ucata" alt="<?php  echo LANGUI_WARSN_T14;?>" title="<?php  echo LANGUI_WARSN_T14;?>">
                      </td>
                      <td class="desc"><?php  echo LANGUI_WARSN_T14;?></td>
                      <td class="value">
                        <input class="text" type="text" name="kata" value="<?php if( (isset($_POST['kata']) && 0 < intval($_POST['kata'])) ){ ?><?php echo intval($_POST['kata']); ?><?php } ?>" maxlength="4" title="<?php  echo LANGUI_WARSN_T14;?>">
                      </td>
                      <td class="research"></td>
                    </tr>
                <?php } ?>

            </tbody>
          </table>
        </td>
      </tr>
    </tbody>
  </table>

  <table id="defender" class="fill_in" cellpadding="1" cellspacing="1">
    <thead>
      <tr>
        <th><?php  echo LANGUI_WARSN_T5;?></th>
      </tr>
    </thead>
      <?php $counter1=-1; if( isset($_POST['a2']) && is_array($_POST['a2']) && sizeof($_POST['a2']) ) foreach( $_POST['a2'] as $key1 => $value1 ){ $counter1++; ?>

          <tbody>
            <tr>
              <th><?php echo constant('tribe_' . $key1); ?></th>
            </tr>
            <tr>
              <td class="details">
                <table cellpadding="1" cellspacing="1">
                  <tbody>
                    <?php $counter2=-1; if( isset($troops_t2) && is_array($troops_t2) && sizeof($troops_t2) ) foreach( $troops_t2 as $key2 => $value2 ){ $counter2++; ?>

                        <?php if( $key1 == $key2 ){ ?>

                          <?php $counter3=-1; if( isset($value2) && is_array($value2) && sizeof($value2) ) foreach( $value2 as $key3 => $value3 ){ $counter3++; ?>

                            <tr>
                              <td class="ico">
                                <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="unit u<?php echo $key3;?>" title="<?php echo constant('troop_' . $key3); ?>" alt="<?php echo constant('troop_' . $key3); ?>">
                              </td>
                              <td class="desc"><?php echo constant('troop_' . $key3); ?></td>
                              <td class="value">
                                <input class="text" type="text" name="t2[<?php echo $key1;?>][<?php echo $key3;?>]" value="<?php if( (isset($_POST['t2'], $_POST['t2'][$key1]) && isset($_POST['t2'][$key1][$key3]) && 0 < intval($_POST['t2'][$key1][$key3])) ){ ?><?php echo intval($_POST['t2'][$key1][$key3]); ?><?php } ?>" maxlength="10" title="<?php  echo LANGUI_WARSN_T9;?> <?php echo constant('troop_' . $key3); ?>">
                             </td>
                              <td class="research">
                            <?php if( ($key1 != 4 && $counter2 <= 7) ){ ?>

                              <input class="text" type="text" name="f2[<?php echo $key1;?>][<?php echo $key3;?>]" value="<?php if( (isset($_POST['f2'], $_POST['f2'][$key1]) && isset($_POST['f2'][$key1][$key3]) && 0 < intval($_POST['f2'][$key1][$key3])) ){ ?><?php echo intval($_POST['f2'][$key1][$key3]); ?><?php } ?>" maxlength="2" title="<?php  echo LANGUI_WARSN_T9;?> <?php echo constant('troop_' . $key3); ?>">
                            <?php } ?>

                            </td>
                          </tr>
                        <?php } ?>

                      <?php } ?>

                    <?php } ?>

                </tbody>
            </table>
        </td>
      </tr>
  </tbody>
  <?php } ?>

  <tbody>
    <tr>
      <th><?php  echo LANGUI_WARSN_T11;?></th>
    </tr>
    <tr>
      <td class="details">
        <table cellpadding="1" cellspacing="1">
          <tbody>
            <tr>
              <td class="ico">
                <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="unit uhab" alt="<?php  echo LANGUI_WARSN_T12;?>" title="<?php  echo LANGUI_WARSN_T12;?>">
              </td>
              <td class="desc"><?php  echo LANGUI_WARSN_T12;?></td>
            <td class="value">
              <input class="text" type="text" name="ew2" value="<?php if( (isset($_POST['ew2']) && 0 < intval($_POST['ew2'])) ){ ?><?php echo intval($_POST['ew2']); ?><?php } ?>" maxlength="5" title="<?php  echo LANGUI_WARSN_T13;?>">
            </td>
            <td class="research"></td>
          </tr>
          <tr>
            <td class="ico">
              <img src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" class="unit uwall" alt="<?php  echo LANGUI_WARSN_T16;?>" title="<?php  echo LANGUI_WARSN_T16;?>">
            </td>
            <td class="desc"><?php  echo LANGUI_WARSN_T16;?></td>
            <td class="value">
              <input class="text" type="text" name="wall1" value="<?php if( (isset($_POST['wall1']) && 0 < intval($_POST['wall1'])) ){ ?><?php echo intval($_POST['wall1']); ?><?php } ?>" maxlength="2" title="<?php  echo LANGUI_WARSN_T17;?>"></td>
              <td class="research"></td>
            </tr>
          </tbody>
        </table>
      </td>
    </tr>
  </tbody>
</table>
<div class="clear"></div>
<?php } ?>


  <table id="select" cellpadding="1" cellspacing="1">
    <thead>
      <tr>
        <td><?php  echo LANGUI_WARSN_T2;?></td>
        <td><?php  echo LANGUI_WARSN_T5;?></td>
        <td><?php  echo LANGUI_WARSN_T6;?></td>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>
          <label>
            <input class="radio" type="radio" name="a1" value="7" <?php if( !isset($_POST['a1']) || (isset($_POST['a1']) && intval($_POST['a1']) == 7) ){ ?>checked="" <?php } ?> >
            <?php  echo tribe_7;?>

          </label>
          <br />
          <label>
            <input class="radio" type="radio" name="a1" value="1" <?php if( (isset($_POST['a1']) && intval($_POST['a1']) == 1) ){ ?>checked=""<?php } ?>>
          <?php  echo tribe_1;?>

        </label>
        <br />
        <label>
          <input class="radio" type="radio" name="a1" value="2" <?php if( (isset($_POST['a1']) && intval($_POST['a1']) == 2) ){ ?>checked=""<?php } ?>>
          <?php  echo tribe_2;?>

        </label>
        <br />
        <label>
          <input class="radio" type="radio" name="a1" value="3" <?php if( (isset($_POST['a1']) && intval($_POST['a1']) == 3) ){ ?> checked="" <?php } ?> >
          <?php  echo tribe_3;?>

        </label>
      </td>
      <td>
         <label>
          <input class="check" type="checkbox" name="a2[7]" value="1" <?php if( !isset($_POST['a2']) || (isset($_POST['a2'], $_POST['a2'][7])) ){ ?>checked=""<?php } ?> >
          <?php  echo tribe_7;?>

        </label>
         <br />
         <label>
          <input class="check" type="checkbox" name="a2[1]" value="1"<?php if( (isset($_POST['a2'], $_POST['a2'][1])) ){ ?> checked="" <?php } ?> >
          <?php  echo tribe_1;?>

        </label>
        <br />
        <label><input class="check" type="checkbox" name="a2[2]" value="1" <?php if( (isset($_POST['a2'], $_POST['a2'][2])) ){ ?>checked=""<?php } ?> >
        <?php  echo tribe_2;?>

      </label>
      <br />
      <label>
        <input class="check" type="checkbox" name="a2[3]" value="1" <?php if( (isset($_POST['a2'], $_POST['a2'][3])) ){ ?>checked=""<?php } ?> >
        <?php  echo tribe_3;?>

      </label>
      <br />
      <label>
        <input class="check" type="checkbox" name="a2[4]" value="1" <?php if( (isset($_POST['a2'], $_POST['a2'][4])) ){ ?> checked=""<?php } ?>>
        <?php  echo tribe_4;?>

      </label>
    </td>
    <td>
      <label>
        <input class="radio" type="radio" name="ktyp" value="1" <?php if( !isset($_POST['ktyp']) || (isset($_POST['ktyp']) && intval($_POST['ktyp']) == 1) ){ ?> checked=""<?php } ?>>
        <?php  echo LANGUI_WARSN_T7;?>

      </label>
      <br />
      <label>
        <input class="radio" type="radio" name="ktyp" value="2" <?php if( (isset($_POST['ktyp']) && intval($_POST['ktyp']) == 2) ){ ?>checked=""<?php } ?> >
        <?php  echo LANGUI_WARSN_T8;?>

      </label>
       <br />
     </td>
   </tr>
 </tbody>
</table>
<p class="btn">
  <input type="image" value="ok" name="s1" id="btn_ok" class="dynamic_img" src="<?php echo add_style('x.gif', ASSETS_DIR); ?>" alt="<?php  echo text_okdone_lang;?>"></p>
  <?php if( ($errorText != '') ){ ?>

      <b><p class="error">
      <?php echo $errorText;?>

      </p></b>
  <?php } ?>

  </form>
</body>
</html>