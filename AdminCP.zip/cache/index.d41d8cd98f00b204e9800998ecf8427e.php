<?php if(!class_exists('raintpl')){exit;}?><!DOCTYPE html>

<html lang="ar">

<head>

    <meta charset="UTF-8">

    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

</head>

<body>
<!--Content-->
<?php echo load_lang('ui/index'); ?>

<div class="container-fluid section1" id="content">
    <article class="caption-block">
        <h1 class="caption-heading"><?php  echo LANGUI_INDX_T47;?></h1>
        <h2 class="caption-subtitle"><?php  echo LANGUI_INDX_T46;?></h2>
        <div class="big-button">
            <button class="btn btn-big"  data-toggle="modal" data-target="#register">
                <?php  echo CLICK_HERE;?>

            </button>
        </div>
    </article>

</div>
<div class="container-fluid section2">

    <article class="caption-block">
        <h1 class="caption-heading"><?php  echo WHAT_IS;?></h1>
        <div class="box-info about-desciption">
            <p><?php  echo GAME_DESCRIPTION;?></p>
            <p><?php  echo ABOUT1;?></p>
            <div class="container  media-container">
                <div class="row">
                    <div class='list-group parent-container'>

                        <div class='col-sm-4 col-xs-6 col-md-3 col-lg-3 list-group-element'>
                            <a class="thumbnail gallery-item"  href="<?php echo add_style('s1.png', ASSETS_DIR.'indx/images/'); ?>">
                            <img class="img-responsive" alt="" src="<?php echo add_style('s1.png', ASSETS_DIR.'indx/images/'); ?>" />

                            </a>
                            <div class='text-left screen-title'>
                                <small class='text-muted'>Image Title</small>
                            </div> <!-- text-right / end -->
                        </div> <!-- col-6 / end -->
                        <div class='col-sm-4 col-xs-6 col-md-3 col-lg-3 list-group-element'>
                            <a class="thumbnail gallery-item"  href="<?php echo add_style('s2.png', ASSETS_DIR.'indx/images/'); ?>">
                            <img class="img-responsive" alt="" src="<?php echo add_style('s2.png', ASSETS_DIR.'indx/images/'); ?>" />
                            </a>
                            <div class='text-left screen-title'>
                                <small class='text-muted'>Image Title</small>
                            </div> <!-- text-right / end -->
                        </div> <!-- col-6 / end -->
                        <div class='col-sm-4 col-xs-6 col-md-3 col-lg-3 list-group-element'>
                            <a class="thumbnail gallery-item"  href="<?php echo add_style('s3.png', ASSETS_DIR.'indx/images/'); ?>">
                            <img class="img-responsive" alt="" src="<?php echo add_style('s3.png', ASSETS_DIR.'indx/images/'); ?>" />

                            </a>
                            <div class='text-left screen-title'>
                                <small class='text-muted'>Image Title</small>
                            </div> <!-- text-right / end -->
                        </div> <!-- col-6 / end -->
                        <div class='col-sm-4 col-xs-6 col-md-3 col-lg-3 list-group-element'>
                            <a class="thumbnail gallery-item"  href="<?php echo add_style('s4.png', ASSETS_DIR.'indx/images/'); ?>">
                            <img class="img-responsive" alt="" src="<?php echo add_style('s4.png', ASSETS_DIR.'indx/images/'); ?>" />

                            </a>
                            <div class='text-left screen-title'>
                                <small class='text-muted'>Image Title</small>
                            </div> <!-- text-right / end -->
                        </div> <!-- col-6 / end -->
                    </div> <!-- list-group / end -->
                </div> <!-- row / end -->
            </div> <!-- container / end -->

        </div>
    </article>

</div>
<div class="container-fluid section3">

    <article class="caption-block">
        <h1 class="caption-heading"><?php  echo LANGUI_INDX_T48;?></h1>
        <div class="col-md-12">
            <div class="box-info">
                <div class="tab-block text-center ">
                    <div class="row ">
                        <div class=" col-xs-12 col-md-12 " role="tabpanel">
                            <div class=" col-xs-4 col-sm-12 no-padding ">
                                <!-- Nav tabs -->
                                <ul class=" nav nav-justified " id="nav-tabs" role="tablist">
                                    <li role="presentation" class="active">
                                        <a href="#dustin" aria-controls="dustin" role="tab" data-toggle="tab">
                                            <img class="img-circle" src="<?php echo add_style('tribe1-128.jpg', ASSETS_DIR.'indx/images/'); ?>" />
                                        </a>
                                    </li>
                                    <li role="presentation" class="">
                                        <a href="#daksh" aria-controls="daksh" role="tab" data-toggle="tab">
                                            <img class="img-circle" src="<?php echo add_style('roman-128.jpg', ASSETS_DIR.'indx/images/'); ?>" />
                                        </a>
                                    </li>
                                    <li role="presentation" class="">
                                        <a href="#anna" aria-controls="anna" role="tab" data-toggle="tab">
                                            <img class="img-circle" src="<?php echo add_style('gauls-128.jpg', ASSETS_DIR.'indx/images/'); ?>" />
                                        </a>
                                    </li>
                                    <li role="presentation" class="">
                                        <a href="#wafer" aria-controls="wafer" role="tab" data-toggle="tab">
                                            <img class="img-circle" src="<?php echo add_style('teutons-128.jpg', ASSETS_DIR.'indx/images/'); ?>" />
                                        </a>
                                    </li>
                                </ul>
                            </div>
                            <div class=" col-xs-8 col-sm-12 no-padding">
                                <!-- Tab panes -->
                                <div class="tab-content" id="tabs-collapse">
                                    <div role="tabpanel" class="tab-pane fade in active" id="dustin">
                                        <div class="tab-inner">
                                            <h1><strong class="text-uppercase"><?php  echo tribe_7;?></strong></h1>
                                            <hr>
                                            <p class="lead"><?php  echo LANGUI_INDX_T49;?></p>

                                        </div>
                                    </div>

                                    <div role="tabpanel" class="tab-pane fade" id="daksh">
                                        <div class="tab-inner">
                                            <h1><strong class="text-uppercase"><?php  echo tribe_1;?></strong></h1>
                                            <hr>
                                            <p class="lead"><?php  echo LANGUI_INDX_T50;?></p>
                                        </div>
                                    </div>

                                    <div role="tabpanel" class="tab-pane fade" id="anna">
                                        <div class="tab-inner">
                                            <h1><strong class="text-uppercase"><?php  echo tribe_2;?></strong></h1>
                                            <hr>
                                            <p class="lead"><?php  echo LANGUI_INDX_T51;?></p>
                                        </div>
                                    </div>

                                    <div role="tabpanel" class="tab-pane fade" id="wafer">
                                        <div class="tab-inner">
                                            <h1><strong class="text-uppercase"><?php  echo tribe_5;?></strong></h1>
                                            <hr>
                                            <p class="lead"><?php  echo LANGUI_INDX_T52;?></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </article>

</div>

<!--/Content-->
<div id="activate" class="modal fade bs-example-modal-sm"  role="dialog" aria-labelledby="mySmallModalLabel">
    <div class="modal-dialog modal-sm" role="document">
        <div class="modal-content">
            <div class="modal-header">
            </div>
            <div class="modal-body">
                <?php if( $activeStat == 1 ){ ?>

                <div class="alert alert-success" role="alert"><?php  echo LANGUI_INDX_T32;?></div>
                <?php }else{ ?>

                <div class="alert alert-danger" role="alert"><?php  echo LANGUI_INDX_T33;?></div>
                <?php } ?>

            </div>
        </div>
    </div>
</div>
</body>
</html>