<?php if(!class_exists('raintpl')){exit;}?><?php if( isset($e) ){ ?>

    <div class="alert alert-error">
        <strong>هذا اللعب ليس موجود</strong>
    </div>
<?php } ?>

<div class="row-fluid">
    <div class="span12">
        <div class="box">
            <div class="box-title">
                <h3><i class="icon-reorder"></i>البحث عن لاعب محظور</h3>
                <div class="box-tool">
                </div>
            </div>
            <div class="box-content">
                <form action="" class="form-horizontal" method="POST">

                    <div class="control-group">
                        <label class="control-label" for="username">اسم اللاعب</label>
                        <div class="controls">
                            <div class="span12">
                                <input type="text" name="username" id="username" class="input-xlarge" data-rule-required="true" />
                            </div>
                        </div>
                    </div>

                    <div class="form-actions">
                        <input type="submit" class="btn btn-primary" value="بحث">
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<div class="row-fluid">
    <div class="span12">
        <div class="box">
        <?php if( isset($status) ){ ?>

            <div class="alert alert-<?php echo $status;?>">
                <strong><?php echo $message;?></strong>
            </div>
        <?php } ?>

            <div class="box-title">
                <h3><i class="icon-reorder"></i>حظر اللاعبين</h3>
                <div class="box-tool">
                </div>
            </div>
            <div class="box-content">
                <form action="" class="form-horizontal" method="POST">

                    <div class="control-group">
                        <label class="control-label" for="name">اسم اللاعب</label>
                        <div class="controls">
                            <div class="span10">
                                <input type="text" name="name" id="name" class="input-large" data-rule-required="true" data-rule-number="true" value="<?php if( isset($b) ){ ?><?php echo $b["name"];?><?php } ?>" />
                            </div>
                        </div>
                    </div>

                    <div class="control-group">
                        <label class="control-label" for="time">عدد ساعات الحظر</label>
                        <div class="controls">
                            <div class="span10">
                                <input type="text" name="time" id="time" class="input-large" data-rule-required="true" data-rule-number="true" value="<?php if( isset($b) ){ ?><?php echo $b["blocked_hour"];?><?php } ?>" />
                            </div>
                        </div>
                    </div>

                    <div class="control-group last">
                      <label for="blocked_reason" class="control-label">سبب الحظر</label>
                      <div class="controls">
                          <textarea name="blocked_reason" id="blocked_reason" rows="5" class="input-block-level"><?php if( isset($b) ){ ?><?php echo $b["blocked_reason"];?><?php } ?></textarea>
                      </div>
                  </div>

                    <div class="form-actions">
                        <input type="submit" class="btn btn-primary" value="تعديل">
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>